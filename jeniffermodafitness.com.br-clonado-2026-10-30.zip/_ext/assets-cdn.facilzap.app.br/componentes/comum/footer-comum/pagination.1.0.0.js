const footerPaginationRuntime=window.FZFooterRuntime||{};class APIPagination{constructor(seletorContainer,endpointURL,apiToken,callbackFormatacao){this.apiToken=apiToken,this.facilzapAPI=new FacilZapAPI(apiToken),this.baseUri=footerPaginationRuntime.apiBaseUri||"",this.seletorContainer=seletorContainer,this.endpointURL=endpointURL,this.filtrosPadroes={},this.filtros={},this.dadosExtrasRequisicao={},this.camposBusca=[],this.menuQuantidadeRegistros=[15,25,50],this.callbackFormatacao=callbackFormatacao,this.callbackListagem,this.paginaAtual=1,this.registrosPorPagina=15,this.exibirPaginacao=!0,this.totalRegistros=null,this.classesAdicionaisListagem="",this.avisoSemRegistros=`
            <div class="alert alert-secondary text-center mx-auto my-2" role="alert">
            <i class="fa fa-info-circle" aria-hidden="true"></i> Nenhum registro encontrado.
            </div>
        `,this.avisoSemRegistrosFiltros=`
            <div class="alert alert-secondary text-center mx-auto my-2" role="alert">
            <i class="fa fa-info-circle" aria-hidden="true"></i> Nenhum registro encontrado para os filtros aplicados.
            </div>
        `,this.dadosMap=new Map}setarCallbackListagem(callback){this.callbackListagem=callback}setarExibirPaginacao(exibirPaginacao){this.exibirPaginacao=exibirPaginacao}setarRegistrosPorPagina(registrosPorPagina){this.registrosPorPagina=registrosPorPagina}setarAvisoSemRegistros(avisoSemRegistros){this.avisoSemRegistros=avisoSemRegistros}setarAvisoSemRegistrosFiltros(avisoSemRegistrosFiltros){this.avisoSemRegistrosFiltros=avisoSemRegistrosFiltros}setarClassesAdicionaisListagem(classesAdicionaisListagem){this.classesAdicionaisListagem=classesAdicionaisListagem}setarFiltrosPadroes(filtrosPadroes){this.filtrosPadroes=filtrosPadroes}setarFiltros(filtros,recarregar=!0){this.filtros=filtros,recarregar&&this.recarregar(!0)}setarFiltro(chave,valor,recarregar=!1){this.filtros[chave]=valor,recarregar&&this.recarregar(!0)}obterFiltros(){var filtrosFormatados={};return Object.entries(this.filtrosPadroes).forEach(([chaveFiltro,dadosFiltro])=>{this.filtros[chaveFiltro]?filtrosFormatados[chaveFiltro]=this.filtros[chaveFiltro]:dadosFiltro.valorPadrao&&(filtrosFormatados[chaveFiltro]=dadosFiltro.valorPadrao)}),filtrosFormatados}obterBusca(){return{column:$(`${this.seletorContainer} #pagination_tipo_busca`).val(),value:$(`${this.seletorContainer} #pagination_busca`).val()}}obterDadosItem(id){return this.dadosMap.get(id)}possuiFiltros(){return!!($(`${this.seletorContainer} #pagination_busca`).length&&$(`${this.seletorContainer} #pagination_busca`).val()!=""||Object.keys(this.obterFiltros()).length>0)}resetarFiltros(recarregar=!0){this.filtros={},recarregar&&this.recarregar(!0)}setarCamposBusca(camposBusca){this.camposBusca=camposBusca}setarDadosExtrasRequisicao(dadosExtrasRequisicao){this.dadosExtrasRequisicao=dadosExtrasRequisicao}setarMenuQuantidadeRegistros(menuQuantidadeRegistros){this.menuQuantidadeRegistros=menuQuantidadeRegistros}setarCallbackCarregamento(callback){$(this.seletorContainer).on("finishedLoading",()=>{callback()})}setarCallbackFormatacao(callback){this.callbackFormatacao=callback}iniciar(){$(this.seletorContainer).html(`
            <div class='ferramentas mt-0 row'></div>
            <div class='listagem ${this.classesAdicionaisListagem} mt-3'></div>
            <div class='paginacao mt-3'></div>
        `),$(`${this.seletorContainer} .paginacao`).on("click",".page-link",e=>{e.preventDefault();var pagina=$(e.currentTarget).data("pagina");pagina!=this.paginaAtual&&(this.paginaAtual=pagina,this.recarregar())}),this.iniciarMenuQuantidadeRegistros(),this.iniciarBusca(),this.listar()}buscar(termo,tipoBusca){tipoBusca!==void 0&&$(`${this.seletorContainer} #pagination_tipo_busca`).val(tipoBusca),$(`${this.seletorContainer} #pagination_busca`).val(termo),termo==""?$(`${this.seletorContainer} .btn-limpar-busca`).hide():$(`${this.seletorContainer} .btn-limpar-busca`).show(),this.recarregar(!0)}recarregar(resetarPagina){resetarPagina===!0&&(this.paginaAtual=1),this.listar()}listar(){this.facilzapAPI.setarEndpoint(this.endpointURL);var parametros={length:this.registrosPorPagina,start:(this.paginaAtual-1)*this.registrosPorPagina,filtros:this.obterFiltros(),search:this.obterBusca()};this.facilzapAPI.setarParametros(parametros),this.facilzapAPI.setarSeletorOverlay(this.seletorContainer),this.facilzapAPI.setarCallbackErro(fn=>{}),this.facilzapAPI.enviar().then(()=>{if(this.facilzapAPI.obterStatus()!="erro"){var retorno=this.facilzapAPI.obterRetorno();if(retorno.data.length==0){var mensagemSemRegistros=this.possuiFiltros()?this.avisoSemRegistrosFiltros:this.avisoSemRegistros;$(`${this.seletorContainer} .listagem`).html(mensagemSemRegistros),$(`${this.seletorContainer} .paginacao`).html("");return}$(`${this.seletorContainer} .listagem`).html("");var html=retorno.data.map(item=>(item.id&&this.dadosMap.set(item.id,item),this.callbackFormatacao(item))).join("");$(`${this.seletorContainer} .listagem`).html(html),this.totalRegistros=retorno.recordsTotal,this.recarregarPaginacao()}this.callbackListagem&&this.callbackListagem()})}recarregarPaginacao(){if(this.totalRegistros==0)var quantidadePaginas=1;else var quantidadePaginas=Math.ceil(this.totalRegistros/this.registrosPorPagina);var paginacaoPaginasHtml="",primeiraPaginaLista=1;quantidadePaginas>7&&(primeiraPaginaLista=this.paginaAtual-3,primeiraPaginaLista<1&&(primeiraPaginaLista=1));for(var ultimaPaginaLista=primeiraPaginaLista+6,i=primeiraPaginaLista;i<=ultimaPaginaLista&&!(i>quantidadePaginas);i++){var classeAtivo="";i==this.paginaAtual&&(classeAtivo="active"),paginacaoPaginasHtml+=`
                <li class="page-item ${classeAtivo}">
                    <a class="page-link" href="#" data-pagina="${i}">${i}</a>
                </li>
            `}var paginacaoHtml=`
            <nav>
                <ul class="pagination d-flex justify-content-center">
                    <li class="page-item ${this.paginaAtual==1?"disabled":""}">
                        <a class="page-link" href="#" tabindex="-1" data-pagina="${this.paginaAtual-1}">Anterior</a>
                    </li>
                    ${paginacaoPaginasHtml}
                    <li class="page-item ${this.paginaAtual==quantidadePaginas?"disabled":""}">
                        <a class="page-link" href="#" data-pagina="${this.paginaAtual+1}">Próximo</a>
                    </li>
                </ul>
            </nav>
        `;this.exibirPaginacao&&$(`${this.seletorContainer} .paginacao`).html(paginacaoHtml)}iniciarMenuQuantidadeRegistros(){if(!(!this.menuQuantidadeRegistros||this.menuQuantidadeRegistros.length==0)){var optionHtml=this.menuQuantidadeRegistros.map(item=>{var selected="";return item==this.registrosPorPagina&&(selected="selected"),`<option value="${item}" ${selected}>${item}</option>`}).join(""),html=`
        <div class="col-sm-12 col-lg-4 col-xl-6 text-center text-lg-left">
        <label><select class="form-control form-control-sm d-inline-block" id="pagination_quantidade" style="width: 55px;">${optionHtml}</select> resultados por página</label>
        </div>
        `;$(`${this.seletorContainer} .ferramentas`).append(html);var seletor_quantidade=$(`${this.seletorContainer} #pagination_quantidade`);seletor_quantidade.on("change",()=>{this.registrosPorPagina=seletor_quantidade.val(),this.recarregar(!0)})}}iniciarBusca(){if(!(!this.camposBusca||this.camposBusca.length==0)){var optionHtml=this.camposBusca.map(item=>`<option value="${item.id}">${item.nome}</option>`).join(""),html=`
        <div class="input-group mb-0 mx-auto mr-lg-0" style="max-width: 600px;">
            <div class="input-group-prepend pos-relative" style="flex-grow: 1;max-width:250px">
                <label class="pos-absolute" style="top: 0;left: 3px;z-index: 10;font-size: 9px;color: #747474;">Buscar por:</label>
                <select id="pagination_tipo_busca" class="form-control w-100 px-1" style="height: 37px;">
                    ${optionHtml}
                </select>
            </div>
            <input type="search" id="pagination_busca" class="form-control form-control-sm ml-0" placeholder="Buscar por..." style="max-width: 50vw;height: 37px;">
            <div class="input-group-append">
                <button type="button" class="btn btn-success btn-buscar" style="padding: 8px 15px;"><i class="fa fa-search m-0"></i></button>
                <button type="button" class="btn btn-danger btn-limpar-busca" style="padding: 8px 15px;display:none"><i class="fa fa-times m-0"></i></button>
            </div>
        </div>
        `;$(`${this.seletorContainer} .ferramentas`).append(html);var select_tipo_busca=$(`${this.seletorContainer} #pagination_tipo_busca`),input_busca=$(`${this.seletorContainer} #pagination_busca`),btn_busca=$(`${this.seletorContainer} .btn-buscar`),btn_limpar_busca=$(`${this.seletorContainer} .btn-limpar-busca`);select_tipo_busca.on("change",()=>{input_busca.attr("placeholder","Buscar por "+select_tipo_busca.children(":selected").text()+"...")}),btn_busca.on("click",()=>{input_busca.val()==""?$(`${this.seletorContainer} .btn-limpar-busca`).hide():$(`${this.seletorContainer} .btn-limpar-busca`).show(),this.recarregar(!0)}),btn_limpar_busca.on("click",()=>{this.buscar("")})}}}

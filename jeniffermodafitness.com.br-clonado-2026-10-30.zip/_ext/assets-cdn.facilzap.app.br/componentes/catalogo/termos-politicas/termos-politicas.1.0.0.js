if(typeof FZComponents=="undefined")var FZComponents={};const TermosPoliticasStore=Vue.reactive({visivel:!1,politicaSelecionada:null});FZComponents.TermosPoliticas={components:{"p-dialog":PrimeVue.Dialog,"p-button":PrimeVue.Button},data(){return{store:TermosPoliticasStore,dados:window.FZTermosPoliticasDados||{},ordemPoliticas:["trocas","fretes","garantia","privacidade"]}},computed:{dialogVisivel:{get(){return this.store.visivel},set(valor){this.store.visivel=!!valor,valor||(this.store.politicaSelecionada=null)}},politicas(){return this.ordemPoliticas.map(chave=>({chave,...this.dados[chave]||{}})).filter(politica=>politica.titulo&&politica.conteudo)},politicaAtual(){return this.politicas.find(politica=>politica.chave===this.store.politicaSelecionada)||null},mostrandoDetalhe(){return!!this.politicaAtual},tituloDialog(){return this.mostrandoDetalhe?this.politicaAtual.titulo:"Termos e Políticas"},subtituloDialog(){return this.mostrandoDetalhe?"Consulte os detalhes completos desta política.":"Consulte as regras e condições definidas pela loja."},labelAcaoPrincipal(){return this.mostrandoDetalhe?"Entendi":"Continuar comprando"}},methods:{abrir(chave){const politica=this.politicas.find(item=>item.chave===chave);chave&&!politica||(this.store.politicaSelecionada=politica?politica.chave:null,this.store.visivel=!0,this.rolarDetalheParaInicio())},fechar(){this.store.visivel=!1,this.store.politicaSelecionada=null},selecionarPolitica(chave){this.politicas.some(politica=>politica.chave===chave)&&(this.store.politicaSelecionada=chave,this.rolarDetalheParaInicio())},rolarDetalheParaInicio(){this.$nextTick(()=>{this.$refs.detalhe&&(this.$refs.detalhe.scrollTop=0)})},voltar(){this.store.politicaSelecionada=null},executarAcaoPrincipal(){if(this.mostrandoDetalhe){this.voltar();return}this.fechar()}},template:`
        <div class="fz-termos-politicas">
            <p-dialog
                v-model:visible="dialogVisivel"
                modal
                :draggable="false"
                :dismissable-mask="true"
                :block-scroll="true"
                :base-z-index="1000003"
                :style="{ width: 'min(900px, calc(100vw - 56px))', height: 'min(600px, calc(100vh - 56px))' }"
                :breakpoints="{ '820px': '100vw' }"
                :pt="{ root: 'fz-termos-modal', header: { class: 'fz-termos-modal__header' }, content: { class: 'fz-termos-modal__content' }, footer: { class: 'fz-termos-modal__footer' } }">
                <template #header>
                    <div class="fz-termos-modal__header-left">
                        <button
                            v-if="mostrandoDetalhe"
                            type="button"
                            class="fz-termos-modal__back"
                            aria-label="Voltar para a lista de políticas"
                            @click="voltar">
                            <i class="pi pi-angle-left" aria-hidden="true"></i>
                        </button>
                        <div class="fz-termos-modal__header-copy">
                            <strong>{{ tituloDialog }}</strong>
                        </div>
                    </div>
                </template>

                <div class="fz-termos-modal__viewport">
                    <div class="fz-termos-modal__track" :class="{ 'is-detail': mostrandoDetalhe }">
                        <section class="fz-termos-modal__screen" aria-label="Lista de termos e políticas">
                            <div class="fz-termos-modal__intro">
                                <div class="fz-termos-modal__intro-icon"><i class="pi pi-file" aria-hidden="true"></i></div>
                                <div>
                                    <strong>Central de políticas da loja</strong>
                                    <span>Selecione uma opção para consultar os termos completos.</span>
                                </div>
                            </div>

                            <div v-if="politicas.length" class="fz-termos-modal__grid">
                                <button
                                    v-for="politica in politicas"
                                    :key="politica.chave"
                                    type="button"
                                    class="fz-termos-modal__card"
                                    @click="selecionarPolitica(politica.chave)">
                                    <span class="fz-termos-modal__card-top">
                                        <span class="fz-termos-modal__card-icon"><i :class="politica.icone" aria-hidden="true"></i></span>
                                        <span class="fz-termos-modal__card-copy">
                                            <strong>{{ politica.titulo }}</strong>
                                            <span>{{ politica.descricao }}</span>
                                        </span>
                                    </span>
                                </button>
                            </div>

                            <div v-else class="fz-termos-modal__empty">
                                <i class="pi pi-file" aria-hidden="true"></i>
                                <strong>Nenhuma política disponível.</strong>
                            </div>
                        </section>

                        <section ref="detalhe" class="fz-termos-modal__screen" aria-live="polite">
                            <template v-if="politicaAtual">
                                <div class="fz-termos-modal__detail-hero">
                                    <div class="fz-termos-modal__detail-icon"><i :class="politicaAtual.icone" aria-hidden="true"></i></div>
                                    <div class="fz-termos-modal__detail-copy">
                                        <strong>{{ politicaAtual.titulo }}</strong>
                                        <span>{{ politicaAtual.descricao }}</span>
                                    </div>
                                </div>

                                <div class="fz-termos-modal__detail-content">{{ politicaAtual.conteudo }}</div>
                            </template>
                        </section>
                    </div>
                </div>

                <template #footer>
                    <div class="fz-termos-modal__footer-inner">
                        <p class="fz-termos-modal__footer-note"></p>
                        <div class="fz-termos-modal__footer-actions">
                            <p-button
                                :label="labelAcaoPrincipal"
                                :icon="mostrandoDetalhe ? undefined : 'pi pi-shopping-bag'"
                                severity="primary"
                                @click="executarAcaoPrincipal"></p-button>
                        </div>
                    </div>
                </template>
            </p-dialog>
        </div>
    `};

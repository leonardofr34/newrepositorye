if(typeof FZComponents=="undefined")var FZComponents={};FZComponents.AtendimentoFlutuante={components:{"p-inputtext":PrimeVue.InputText},data(){return{aberto:!1,rastreioAberto:!1,pedidoId:"",documento:"",erroRastreio:"",buscandoRastreio:!1,sobreposicaoAberta:!1,visivel:!0,ultimoScrollY:0,timerReexibir:null,observadorSobreposicoes:null}},computed:{configuracao(){return window.FZAtendimentoFlutuanteConfig||{}},videochamadaAtiva(){return!!this.configuracao.videochamadaAtiva},whatsappAtivo(){var _a;return!!((_a=this.configuracao.whatsapp)!=null&&_a.ativo)},chatbotExterno(){var _a;return!!((_a=this.configuracao.whatsapp)!=null&&_a.chatbotExterno)},brindesAtivos(){return!!this.configuracao.brindesAtivos},cashbackAtivo(){var _a;return!!((_a=this.configuracao.cashback)!=null&&_a.ativo)},cashbackMensagem(){const cashback=this.configuracao.cashback||{},porcentagem=this.formatarPorcentagem(cashback.porcentagem),valorMinimo=Number(cashback.valorMinimoPedido||0),regra=valorMinimo>0?`em pedidos acima de ${this.formatarMoeda(valorMinimo)}`:"na próxima compra",saldo=Number(cashback.saldoDisponivel||0);return`${cashback.clienteIdentificado?`Saldo disponível: ${this.formatarMoeda(saldo)}.`:"Identifique-se na finalização para consultar seu saldo."} Ganhe ${porcentagem}% ${regra}.`}},mounted(){this.ultimoScrollY=window.scrollY,this.sincronizarSobreposicao(),this.observarSobreposicoes(),window.addEventListener("scroll",this.aoScroll,{passive:!0}),document.addEventListener("click",this.aoCliqueFora),document.addEventListener("keydown",this.aoTecla)},beforeUnmount(){var _a;window.removeEventListener("scroll",this.aoScroll),document.removeEventListener("click",this.aoCliqueFora),document.removeEventListener("keydown",this.aoTecla),(_a=this.observadorSobreposicoes)==null||_a.disconnect(),clearTimeout(this.timerReexibir)},methods:{temSobreposicaoAtiva(){return document.querySelector([".modal.show",".p-dialog-mask",".p-drawer-mask",".swal2-container.swal2-backdrop-show","dialog[open]"].join(","))!==null},sincronizarSobreposicao(){const aberta=this.temSobreposicaoAtiva();aberta&&(this.fecharCentral(),clearTimeout(this.timerReexibir)),this.sobreposicaoAberta=aberta},observarSobreposicoes(){!window.MutationObserver||!document.body||(this.observadorSobreposicoes=new MutationObserver(()=>{this.sincronizarSobreposicao()}),this.observadorSobreposicoes.observe(document.body,{attributes:!0,attributeFilter:["aria-hidden","class","style"],childList:!0,subtree:!0}))},alternarCentral(){this.aberto=!this.aberto,this.aberto||this.fecharRastreio()},fecharCentral(){this.aberto=!1,this.fecharRastreio()},alternarRastreio(){this.rastreioAberto=!this.rastreioAberto,this.erroRastreio="",this.rastreioAberto&&this.$nextTick(()=>{var _a,_b;return(_b=(_a=this.$refs.pedidoId)==null?void 0:_a.$el)==null?void 0:_b.focus()})},fecharRastreio(){this.rastreioAberto=!1,this.erroRastreio=""},abrirPerfilLoja(){if(this.fecharCentral(),window.FacilZapPerfilLoja&&typeof window.FacilZapPerfilLoja.abrir=="function"){window.FacilZapPerfilLoja.abrir();return}window.PerfilLojaStore&&(window.PerfilLojaStore.aberto=!0)},formatarMoeda(valor){return new Intl.NumberFormat("pt-BR",{style:"currency",currency:"BRL"}).format(Number(valor)||0)},formatarPorcentagem(valor){return Number(valor||0).toLocaleString("pt-BR",{minimumFractionDigits:0,maximumFractionDigits:2})},abrirBrindes(){this.fecharCentral(),window.FacilZapBrindes&&typeof window.FacilZapBrindes.abrir=="function"&&window.FacilZapBrindes.abrir()},abrirChatbot(){var _a,_b;const widgetId=(_a=this.configuracao.whatsapp)==null?void 0:_a.widgetId,gatilho=widgetId?(_b=document.getElementById(widgetId))==null?void 0:_b.querySelector("[data-chatbot-open]"):null;gatilho&&(this.fecharCentral(),gatilho.click())},aoScroll(){const scrollY=window.scrollY,delta=scrollY-this.ultimoScrollY;this.ultimoScrollY=scrollY,!(Math.abs(delta)<10||this.aberto||this.sobreposicaoAberta)&&(this.visivel=!1,clearTimeout(this.timerReexibir),this.timerReexibir=window.setTimeout(()=>{!this.aberto&&!this.sobreposicaoAberta&&(this.visivel=!0)},2e3))},aoCliqueFora(event){this.aberto&&!this.$el.contains(event.target)&&this.fecharCentral()},aoTecla(event){if(event.key==="Escape"){if(this.rastreioAberto){this.fecharRastreio();return}this.fecharCentral()}},documentoNormalizado(){return String(this.documento||"").toUpperCase().replace(/[^A-Z0-9]/g,"").slice(0,14)},async buscarRastreio(){const pedidoId=String(this.pedidoId||"").replace(/\D/g,""),documento=this.documentoNormalizado();if(this.erroRastreio="",!pedidoId){this.erroRastreio="Informe o ID do pedido.",this.$nextTick(()=>{var _a,_b;return(_b=(_a=this.$refs.pedidoId)==null?void 0:_a.$el)==null?void 0:_b.focus()});return}if(![11,14].includes(documento.length)){this.erroRastreio="Informe um CPF ou CNPJ válido.",this.$nextTick(()=>{var _a,_b;return(_b=(_a=this.$refs.documento)==null?void 0:_a.$el)==null?void 0:_b.focus()});return}this.buscandoRastreio=!0;try{const resposta=await fetch(this.configuracao.endpoint,{method:"POST",credentials:"same-origin",headers:{"Content-Type":"application/x-www-form-urlencoded",Accept:"application/json"},body:new URLSearchParams({acao:"rastrear_pedido",pedido_id:pedidoId,cpf_cnpj:documento})}),dados=await resposta.json();if(!resposta.ok||!dados.sucesso||!dados.url)throw new Error(dados.erro||"Não foi possível localizar o rastreio deste pedido.");if(this.fecharCentral(),dados.abrirPedido){window.location.href=dados.url;return}if(typeof window.loadPageToModal=="function"){window.loadPageToModal(dados.url,"Rastreamento do Pedido","modal-lg modal-dialog-scrollable","Carregando Rastreamento...");return}window.location.href=dados.url}catch(error){this.erroRastreio=error.message||"Não foi possível localizar o rastreio deste pedido."}finally{this.buscandoRastreio=!1}}},template:`
        <section
            class="fz-atendimento-flutuante"
            :class="{
                'fz-atendimento-flutuante--aberto': aberto,
                'fz-atendimento-flutuante--oculto': !visivel,
                'fz-atendimento-flutuante--sobreposicao': sobreposicaoAberta
            }"
            aria-label="Central de atendimento"
        >
            <div class="fz-atendimento-flutuante__painel">
                <div class="fz-atendimento-flutuante__painel-interno">
                    <section class="fz-atendimento-flutuante__cartao">
                        <header class="fz-atendimento-flutuante__cabecalho">
                            <div>
                                <small class="fz-atendimento-flutuante__sobretitulo">Central da loja</small>
                                <h2>Como podemos ajudar?</h2>
                                <p>Escolha uma opção para continuar.</p>
                            </div>
                            <button class="fz-atendimento-flutuante__fechar" type="button" aria-label="Fechar central de atendimento" @click="fecharCentral">&times;</button>
                        </header>

                        <div class="fz-atendimento-flutuante__lista">
                            <button
                                v-if="videochamadaAtiva"
                                class="fz-atendimento-flutuante__item fz-atendimento-flutuante__item--video btn-videochamada-catalogo"
                                type="button"
                                @click="fecharCentral"
                            >
                                <span class="fz-atendimento-flutuante__icone"><i class="pi pi-video" aria-hidden="true"></i></span>
                                <span class="fz-atendimento-flutuante__texto"><strong>Videochamada</strong><span>Fale com a loja em tempo real.</span></span>
                                <span class="fz-atendimento-flutuante__ao-vivo">AO VIVO</span>
                            </button>

                            <button
                                v-if="whatsappAtivo && chatbotExterno"
                                class="fz-atendimento-flutuante__item fz-atendimento-flutuante__item--whatsapp"
                                type="button"
                                @click="abrirChatbot"
                            >
                                <span class="fz-atendimento-flutuante__icone"><i class="pi pi-whatsapp" aria-hidden="true"></i></span>
                                <span class="fz-atendimento-flutuante__texto"><strong>WhatsApp</strong><span>Converse diretamente com a equipe.</span></span>
                                <i class="pi pi-angle-right fz-atendimento-flutuante__seta" aria-hidden="true"></i>
                            </button>

                            <a
                                v-else-if="whatsappAtivo"
                                class="fz-atendimento-flutuante__item fz-atendimento-flutuante__item--whatsapp"
                                :href="configuracao.whatsapp.url"
                                target="_blank"
                                rel="noopener"
                                @click="fecharCentral"
                            >
                                <span class="fz-atendimento-flutuante__icone"><i class="pi pi-whatsapp" aria-hidden="true"></i></span>
                                <span class="fz-atendimento-flutuante__texto"><strong>WhatsApp</strong><span>Converse diretamente com a equipe.</span></span>
                                <i class="pi pi-angle-right fz-atendimento-flutuante__seta" aria-hidden="true"></i>
                            </a>

                            <button class="fz-atendimento-flutuante__item" type="button" :aria-expanded="String(rastreioAberto)" @click="alternarRastreio">
                                <span class="fz-atendimento-flutuante__icone"><i class="pi pi-truck" aria-hidden="true"></i></span>
                                <span class="fz-atendimento-flutuante__texto"><strong>Rastrear pedido</strong><span>Acompanhe o andamento da entrega.</span></span>
                                <i class="pi pi-angle-right fz-atendimento-flutuante__seta" aria-hidden="true"></i>
                            </button>

                            <div class="fz-atendimento-flutuante__rastreio" :class="{ 'fz-atendimento-flutuante__rastreio--aberto': rastreioAberto }" :aria-hidden="String(!rastreioAberto)">
                                <div class="fz-atendimento-flutuante__rastreio-interno">
                                    <div class="fz-atendimento-flutuante__rastreio-conteudo">
                                        <span class="fz-atendimento-flutuante__rastreio-icone"><i class="pi pi-truck" aria-hidden="true"></i></span>
                                        <form class="fz-atendimento-flutuante__formulario" @submit.prevent="buscarRastreio">
                                            <p-inputtext ref="pedidoId" v-model="pedidoId" class="fz-atendimento-flutuante__campo" inputmode="numeric" autocomplete="off" placeholder="ID do pedido" aria-label="ID do pedido"></p-inputtext>
                                            <p-inputtext ref="documento" v-model="documento" class="fz-atendimento-flutuante__campo" autocomplete="off" placeholder="CPF ou CNPJ do cliente" aria-label="CPF ou CNPJ do cliente"></p-inputtext>
                                            <p class="fz-atendimento-flutuante__erro" v-if="erroRastreio" role="alert">{{ erroRastreio }}</p>
                                            <div class="fz-atendimento-flutuante__formulario-acao">
                                                <button class="fz-atendimento-flutuante__buscar" type="submit" :disabled="buscandoRastreio">{{ buscandoRastreio ? 'Buscando...' : 'Buscar' }}</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>

                            <button v-if="brindesAtivos" class="fz-atendimento-flutuante__item" type="button" @click="abrirBrindes">
                                <span class="fz-atendimento-flutuante__icone"><i class="pi pi-gift" aria-hidden="true"></i></span>
                                <span class="fz-atendimento-flutuante__texto"><strong>Brindes</strong><span>Veja os brindes disponíveis na loja.</span></span>
                                <i class="pi pi-angle-right fz-atendimento-flutuante__seta" aria-hidden="true"></i>
                            </button>

                            <div v-if="cashbackAtivo" class="fz-atendimento-flutuante__item fz-atendimento-flutuante__item--cashback" role="status">
                                <span class="fz-atendimento-flutuante__icone"><i class="pi pi-star" aria-hidden="true"></i></span>
                                <span class="fz-atendimento-flutuante__texto"><strong>Cashback</strong><span>{{ cashbackMensagem }}</span></span>
                            </div>

                            <button class="fz-atendimento-flutuante__item" type="button" @click="abrirPerfilLoja">
                                <span class="fz-atendimento-flutuante__icone"><i class="pi pi-info-circle" aria-hidden="true"></i></span>
                                <span class="fz-atendimento-flutuante__texto"><strong>Informações da loja</strong><span>Conheça os dados e canais oficiais.</span></span>
                                <i class="pi pi-angle-right fz-atendimento-flutuante__seta" aria-hidden="true"></i>
                            </button>
                        </div>
                    </section>
                </div>
            </div>

            <button class="fz-atendimento-flutuante__gatilho" type="button" :aria-expanded="String(aberto)" :aria-label="aberto ? 'Fechar central de atendimento' : 'Abrir central de atendimento'" @click="alternarCentral">
                <span class="fz-atendimento-flutuante__gatilho-icone"><i class="pi pi-comments" aria-hidden="true"></i></span>
                <span class="fz-atendimento-flutuante__gatilho-texto">Atendimento</span>
            </button>
        </section>
    `},(function(){function montar(){if(!document.getElementById("atendimento-flutuante-app")||window.FZAtendimentoFlutuanteAppInstance||typeof Vue=="undefined")return;const app=Vue.createApp({components:{"fz-atendimento-flutuante":FZComponents.AtendimentoFlutuante}});if(typeof PrimeVue!="undefined"&&PrimeVue.Config){const opcoes=typeof lojaPreset!="undefined"?{theme:{preset:lojaPreset,options:{darkModeSelector:!1}}}:{};app.use(PrimeVue.Config,opcoes)}window.FZAtendimentoFlutuanteAppInstance=app.mount("#atendimento-flutuante-app")}if(document.readyState==="loading"){document.addEventListener("DOMContentLoaded",montar,{once:!0});return}montar()})();

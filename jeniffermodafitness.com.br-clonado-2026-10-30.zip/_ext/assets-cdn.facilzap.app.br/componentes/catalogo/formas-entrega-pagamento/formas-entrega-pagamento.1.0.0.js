if(typeof FZComponents=="undefined")var FZComponents={};const FormasEntregaPagamentoStore=Vue.reactive({entregaAberta:!1,pagamentoAberto:!1});FZComponents.FormasEntregaPagamento={components:{"p-dialog":PrimeVue.Dialog,"p-button":PrimeVue.Button},data(){return{store:FormasEntregaPagamentoStore,dados:window.FZFormasEntregaPagamentoDados||{},logosComErro:{}}},computed:{entregaVisivel:{get(){return this.store.entregaAberta},set(valor){this.store.entregaAberta=!!valor}},pagamentoVisivel:{get(){return this.store.pagamentoAberto},set(valor){this.store.pagamentoAberto=!!valor}},integracoesEntrega(){var _a,_b;return Array.isArray((_b=(_a=this.dados)==null?void 0:_a.entrega)==null?void 0:_b.integracoes)?this.dados.entrega.integracoes:[]},formasEntregaManuais(){var _a,_b;return Array.isArray((_b=(_a=this.dados)==null?void 0:_a.entrega)==null?void 0:_b.manuais)?this.dados.entrega.manuais:[]},integracoesPagamento(){var _a,_b;return Array.isArray((_b=(_a=this.dados)==null?void 0:_a.pagamento)==null?void 0:_b.integracoes)?this.dados.pagamento.integracoes:[]},formasPagamentoManuais(){var _a,_b;return Array.isArray((_b=(_a=this.dados)==null?void 0:_a.pagamento)==null?void 0:_b.manuais)?this.dados.pagamento.manuais:[]},temEntrega(){return this.integracoesEntrega.length>0||this.formasEntregaManuais.length>0},temPagamento(){return this.integracoesPagamento.length>0||this.formasPagamentoManuais.length>0}},methods:{abrirEntrega(){this.store.entregaAberta=!0},fecharEntrega(){this.store.entregaAberta=!1},abrirPagamento(){this.store.pagamentoAberto=!0},fecharPagamento(){this.store.pagamentoAberto=!1},textoContagem(quantidade,singular,plural){return quantidade+" "+(quantidade===1?singular:plural)},chaveLogo(tipo,item){return tipo+"-"+String(item.id)},logoDisponivel(tipo,item){return!!item.logo&&!this.logosComErro[this.chaveLogo(tipo,item)]},marcarLogoComErro(tipo,item){this.logosComErro[this.chaveLogo(tipo,item)]=!0}},template:`
        <div class="fz-formas-entrega-pagamento">
            <p-dialog
                v-model:visible="entregaVisivel"
                modal
                :draggable="false"
                :dismissable-mask="true"
                :block-scroll="true"
                :base-z-index="1000003"
                :style="{ width: 'min(1040px, calc(100vw - 56px))', height: 'auto' }"
                :breakpoints="{ '820px': '100vw' }"
                :pt="{ root: 'fz-formas-modal fz-formas-modal--entrega', header: { class: 'fz-formas-modal__header' }, content: { class: 'fz-formas-modal__content' }, footer: { class: 'fz-formas-modal__footer' } }">
                <template #header>
                    <div class="fz-formas-modal__header-copy">
                        <strong>Formas de Entrega</strong>
                        <span>Conheça as opções disponíveis para receber ou retirar seu pedido.</span>
                    </div>
                </template>

                <div class="fz-formas-modal__body">
                    <section v-if="integracoesEntrega.length" class="fz-formas-modal__section">
                        <div class="fz-formas-modal__section-head">
                            <div>
                                <h2 class="fz-formas-modal__section-title">
                                    <i class="pi pi-truck" aria-hidden="true"></i>
                                    Entregas integradas
                                </h2>
                            </div>
                            <span class="fz-formas-modal__count">{{ textoContagem(integracoesEntrega.length, 'integração', 'integrações') }}</span>
                        </div>

                        <div class="fz-formas-modal__gateway-grid">
                            <article v-for="integracao in integracoesEntrega" :key="integracao.id" class="fz-formas-modal__gateway">
                                <div class="fz-formas-modal__gateway-top">
                                    <div class="fz-formas-modal__gateway-logo">
                                        <img
                                            v-if="logoDisponivel('entrega', integracao)"
                                            :src="integracao.logo"
                                            :alt="integracao.nome"
                                            loading="lazy"
                                            @error="marcarLogoComErro('entrega', integracao)">
                                        <strong v-else>{{ integracao.nome }}</strong>
                                    </div>
                                    <strong class="fz-formas-modal__gateway-name">{{ integracao.nome }}</strong>
                                </div>
                            </article>
                        </div>
                    </section>

                    <section v-if="formasEntregaManuais.length" class="fz-formas-modal__section">
                        <div class="fz-formas-modal__section-head">
                            <div>
                                <h2 class="fz-formas-modal__section-title">
                                    <i class="pi pi-box" aria-hidden="true"></i>
                                    Outras formas de entrega
                                </h2>
                            </div>
                            <span class="fz-formas-modal__count">{{ textoContagem(formasEntregaManuais.length, 'opção', 'opções') }}</span>
                        </div>

                        <div class="fz-formas-modal__manual-grid">
                            <article v-for="forma in formasEntregaManuais" :key="forma.id" class="fz-formas-modal__manual">
                                <div class="fz-formas-modal__manual-icon"><i class="pi pi-box" aria-hidden="true"></i></div>
                                <div class="fz-formas-modal__manual-copy">
                                    <strong>{{ forma.nome }}</strong>
                                    <span v-if="forma.descricao">{{ forma.descricao }}</span>
                                </div>
                            </article>
                        </div>
                    </section>

                    <div v-if="!temEntrega" class="fz-formas-modal__empty">
                        <i class="pi pi-truck" aria-hidden="true"></i>
                        <strong>Nenhuma forma de entrega disponível.</strong>
                    </div>
                </div>

                <template #footer>
                    <div class="fz-formas-modal__footer-action">
                        <p-button label="Continuar comprando" icon="pi pi-shopping-bag" severity="primary" @click="fecharEntrega"></p-button>
                    </div>
                </template>
            </p-dialog>

            <p-dialog
                v-model:visible="pagamentoVisivel"
                modal
                :draggable="false"
                :dismissable-mask="true"
                :block-scroll="true"
                :base-z-index="1000003"
                :style="{ width: 'min(1040px, calc(100vw - 56px))', height: 'auto' }"
                :breakpoints="{ '820px': '100vw' }"
                :pt="{ root: 'fz-formas-modal fz-formas-modal--pagamento', header: { class: 'fz-formas-modal__header' }, content: { class: 'fz-formas-modal__content' }, footer: { class: 'fz-formas-modal__footer' } }">
                <template #header>
                    <div class="fz-formas-modal__header-copy">
                        <strong>Formas de Pagamento</strong>
                        <span>Conheça os meios disponíveis para concluir seu pedido.</span>
                    </div>
                </template>

                <div class="fz-formas-modal__body">
                    <section v-if="integracoesPagamento.length" class="fz-formas-modal__section">
                        <div class="fz-formas-modal__section-head">
                            <div>
                                <h2 class="fz-formas-modal__section-title">
                                    <i class="pi pi-credit-card" aria-hidden="true"></i>
                                    Pagamento online
                                </h2>
                            </div>
                            <span class="fz-formas-modal__count">{{ textoContagem(integracoesPagamento.length, 'integração', 'integrações') }}</span>
                        </div>

                        <div class="fz-formas-modal__gateway-grid">
                            <article v-for="integracao in integracoesPagamento" :key="integracao.id" class="fz-formas-modal__gateway">
                                <div class="fz-formas-modal__gateway-top">
                                    <div class="fz-formas-modal__gateway-logo">
                                        <img
                                            v-if="logoDisponivel('pagamento', integracao)"
                                            :src="integracao.logo"
                                            :alt="integracao.nome"
                                            loading="lazy"
                                            @error="marcarLogoComErro('pagamento', integracao)">
                                        <strong v-else>{{ integracao.nome }}</strong>
                                    </div>
                                    <strong class="fz-formas-modal__gateway-name">{{ integracao.nome }}</strong>
                                </div>
                            </article>
                        </div>
                    </section>

                    <section v-if="formasPagamentoManuais.length" class="fz-formas-modal__section">
                        <div class="fz-formas-modal__section-head">
                            <div>
                                <h2 class="fz-formas-modal__section-title">
                                    <i class="pi pi-wallet" aria-hidden="true"></i>
                                    Outras formas de pagamento
                                </h2>
                            </div>
                            <span class="fz-formas-modal__count">{{ textoContagem(formasPagamentoManuais.length, 'opção', 'opções') }}</span>
                        </div>

                        <div class="fz-formas-modal__manual-grid">
                            <article v-for="forma in formasPagamentoManuais" :key="forma.id" class="fz-formas-modal__manual">
                                <div class="fz-formas-modal__manual-icon"><i class="pi pi-wallet" aria-hidden="true"></i></div>
                                <div class="fz-formas-modal__manual-copy">
                                    <strong>{{ forma.nome }}</strong>
                                    <span v-if="forma.descricao">{{ forma.descricao }}</span>
                                </div>
                            </article>
                        </div>
                    </section>

                    <div v-if="!temPagamento" class="fz-formas-modal__empty">
                        <i class="pi pi-credit-card" aria-hidden="true"></i>
                        <strong>Nenhuma forma de pagamento disponível.</strong>
                    </div>
                </div>

                <template #footer>
                    <div class="fz-formas-modal__footer-action">
                        <p-button label="Continuar comprando" icon="pi pi-shopping-bag" severity="primary" @click="fecharPagamento"></p-button>
                    </div>
                </template>
            </p-dialog>
        </div>
    `};

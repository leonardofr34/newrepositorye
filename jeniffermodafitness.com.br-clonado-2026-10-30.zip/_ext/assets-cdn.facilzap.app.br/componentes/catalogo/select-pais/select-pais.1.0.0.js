if(typeof FZComponents=="undefined")var FZComponents={};FZComponents.SelectPais={components:{"p-select":PrimeVue.Select},props:{modelValue:{type:String,default:"BR"},selectType:{type:String,default:"full",validator:value=>["full","reduced"].includes(value)},placeholder:{type:String,default:"Selecione um país"},disabled:{type:Boolean,default:!1}},emits:["update:modelValue"],data(){return{paises:typeof listaPaises!="undefined"?listaPaises:[{id:"BR",text:"Brasil"},{id:"US",text:"Estados Unidos"},{id:"AR",text:"Argentina"},{id:"PY",text:"Paraguai"},{id:"UY",text:"Uruguai"},{id:"CL",text:"Chile"},{id:"BO",text:"Bolívia"},{id:"PE",text:"Peru"},{id:"CO",text:"Colômbia"},{id:"VE",text:"Venezuela"},{id:"EC",text:"Equador"},{id:"GY",text:"Guiana"},{id:"SR",text:"Suriname"},{id:"GF",text:"Guiana Francesa"},{id:"PT",text:"Portugal"},{id:"ES",text:"Espanha"},{id:"FR",text:"França"},{id:"IT",text:"Itália"},{id:"DE",text:"Alemanha"},{id:"GB",text:"Reino Unido"},{id:"CN",text:"China"},{id:"JP",text:"Japão"},{id:"MX",text:"México"},{id:"CA",text:"Canadá"}]}},computed:{paisSelecionado:{get(){return this.modelValue},set(value){this.$emit("update:modelValue",value)}},paisesOptions(){return this.paises.map(pais=>({value:pais.id,label:pais.text,code:pais.id}))}},methods:{paisTemplate(option){if(!option||!option.code)return"";const flagClass=`fi fi-${option.code.toLowerCase()}`;return this.selectType==="reduced"?`<span class="fz-select-pais__opcao"><span class="${flagClass}"></span> ${option.code.toUpperCase()}</span>`:`<span class="fz-select-pais__opcao"><span class="${flagClass}"></span> ${option.label}</span>`}},template:`
    <p-select
        v-model="paisSelecionado"
        :options="paisesOptions"
        option-value="value"
        option-label="label"
        :placeholder="placeholder"
        :disabled="disabled"
        class="fz-select-pais"
        :class="{'fz-select-pais--reduced': selectType === 'reduced'}"
        filter
    >
        <template #value="slotProps">
            <div v-if="slotProps.value" class="fz-select-pais__valor">
                <span :class="'fi fi-' + slotProps.value.toLowerCase()"></span>
                <span v-if="selectType === 'reduced'">{{ slotProps.value.toUpperCase() }}</span>
                <span v-else>{{ paisesOptions.find(p => p.value === slotProps.value)?.label }}</span>
            </div>
            <span v-else>{{ placeholder }}</span>
        </template>
        <template #option="slotProps">
            <div class="fz-select-pais__opcao">
                <span :class="'fi fi-' + slotProps.option.code.toLowerCase()"></span>
                <span>{{ slotProps.option.label }}</span>
            </div>
        </template>
    </p-select>
    `};

typeof window.FZComponents=="undefined"&&(window.FZComponents={}),window.FZComponents.InstalarPWA={components:{"p-button":PrimeVue.Button},data(){return{aberto:!1,ajudaAberta:!1,oculto:!1,carrinhoAberto:!1,sobreposicaoAberta:!1,visivel:!0,promptInstalacao:null,status:"",ultimoScrollY:0,timerReexibir:null,observadorSobreposicoes:null,configuracao:window.FZCatalogoRuntime&&window.FZCatalogoRuntime.instalarPwa||{}}},mounted(){var _a;this.oculto=this.estaFechado()||this.estaInstalado(),this.carrinhoAberto=!!((_a=window.FZCarrinhoDrawerStore)!=null&&_a.aberto),this.ultimoScrollY=window.scrollY,this.sincronizarSobreposicao(),this.observarSobreposicoes(),window.addEventListener("beforeinstallprompt",this.aoReceberPromptInstalacao),window.addEventListener("appinstalled",this.aoInstalarAplicativo),window.addEventListener("fz-carrinho-aberto",this.aoAbrirCarrinho),window.addEventListener("fz-carrinho-fechado",this.aoFecharCarrinho),window.addEventListener("scroll",this.aoScroll,{passive:!0}),document.addEventListener("click",this.aoCliqueExterno),document.addEventListener("keydown",this.aoPressionarTecla)},beforeUnmount(){var _a;window.removeEventListener("beforeinstallprompt",this.aoReceberPromptInstalacao),window.removeEventListener("appinstalled",this.aoInstalarAplicativo),window.removeEventListener("fz-carrinho-aberto",this.aoAbrirCarrinho),window.removeEventListener("fz-carrinho-fechado",this.aoFecharCarrinho),window.removeEventListener("scroll",this.aoScroll),document.removeEventListener("click",this.aoCliqueExterno),document.removeEventListener("keydown",this.aoPressionarTecla),(_a=this.observadorSobreposicoes)==null||_a.disconnect(),clearTimeout(this.timerReexibir)},methods:{temSobreposicaoAtiva(){return document.querySelector([".modal.show",".p-dialog-mask",".p-drawer-mask",".swal2-container.swal2-backdrop-show","dialog[open]"].join(","))!==null},sincronizarSobreposicao(){const aberta=this.temSobreposicaoAtiva();aberta&&(this.aberto=!1,this.ajudaAberta=!1,clearTimeout(this.timerReexibir)),this.sobreposicaoAberta=aberta},observarSobreposicoes(){!window.MutationObserver||!document.body||(this.observadorSobreposicoes=new MutationObserver(()=>{this.sincronizarSobreposicao()}),this.observadorSobreposicoes.observe(document.body,{attributes:!0,attributeFilter:["aria-hidden","class","style"],childList:!0,subtree:!0}))},estaInstalado(){return window.matchMedia&&window.matchMedia("(display-mode: standalone)").matches||window.navigator.standalone===!0},estaFechado(){try{return window.sessionStorage.getItem(this.configuracao.chaveFechamento)==="1"}catch(error){return!1}},fechar(){try{window.sessionStorage.setItem(this.configuracao.chaveFechamento,"1")}catch(error){}this.aberto=!1,this.oculto=!0,clearTimeout(this.timerReexibir)},alternar(){this.aberto=!this.aberto},alternarAjuda(){this.ajudaAberta=!this.ajudaAberta},aoReceberPromptInstalacao(event){event.preventDefault(),this.promptInstalacao=event},aoInstalarAplicativo(){this.fechar()},aoAbrirCarrinho(){this.carrinhoAberto=!0,this.aberto=!1,this.ajudaAberta=!1,clearTimeout(this.timerReexibir)},aoFecharCarrinho(){this.carrinhoAberto=!1},aoScroll(){const scrollY=window.scrollY,delta=scrollY-this.ultimoScrollY;this.ultimoScrollY=scrollY,!(Math.abs(delta)<10||this.aberto||this.oculto||this.carrinhoAberto||this.sobreposicaoAberta)&&(this.visivel=!1,clearTimeout(this.timerReexibir),this.timerReexibir=window.setTimeout(()=>{!this.aberto&&!this.oculto&&!this.carrinhoAberto&&!this.sobreposicaoAberta&&(this.visivel=!0)},2e3))},aoCliqueExterno(event){this.aberto&&this.$el&&!this.$el.contains(event.target)&&(this.aberto=!1)},aoPressionarTecla(event){event.key!=="Escape"||!this.aberto||(this.aberto=!1,this.$nextTick(()=>{var _a;return(_a=this.$refs.gatilho)==null?void 0:_a.focus()}))},ehIOS(){return/iphone|ipad|ipod/i.test(window.navigator.userAgent||"")},async instalar(){if(this.estaInstalado()){this.status="O aplicativo da loja já está instalado neste aparelho.";return}if(this.promptInstalacao){const prompt=this.promptInstalacao;this.promptInstalacao=null;try{await prompt.prompt();const escolha=await prompt.userChoice;this.status=escolha.outcome==="accepted"?"Instalação iniciada.":"Instalação cancelada."}catch(error){this.status="Não foi possível iniciar a instalação neste momento."}return}if(this.ehIOS()){this.status="No iPhone, toque em Compartilhar e depois em “Adicionar à Tela de Início”.";return}this.status="O seu navegador não disponibilizou a instalação automática neste momento."}},template:`
        <aside
            v-if="!oculto && !carrinhoAberto"
            class="fz-instalar-pwa"
            :class="{
                'fz-instalar-pwa--aberto': aberto,
                'fz-instalar-pwa--ajuda-aberta': ajudaAberta,
                'fz-instalar-pwa--oculto': !visivel,
                'fz-instalar-pwa--sobreposicao': sobreposicaoAberta
            }"
            aria-label="Instalação do aplicativo da loja">
            <div class="fz-instalar-pwa__panel">
                <div class="fz-instalar-pwa__panel-inner">
                    <section class="fz-instalar-pwa__card">
                        <header class="fz-instalar-pwa__header">
                            <span class="fz-instalar-pwa__icone" aria-hidden="true"><i class="pi pi-mobile"></i></span>
                            <div class="fz-instalar-pwa__copy">
                                <strong>Instale o app da loja</strong>
                                <span>Acesse esta loja mais rápido pelo seu dispositivo.</span>
                            </div>
                            <button type="button" class="fz-instalar-pwa__fechar" aria-label="Fechar instalação do aplicativo" @click="fechar"><i class="pi pi-times" aria-hidden="true"></i></button>
                        </header>

                        <div class="fz-instalar-pwa__body">
                            <p-button type="button" label="Instalar agora" class="fz-instalar-pwa__instalar" severity="primary" @click="instalar"></p-button>
                            <button type="button" class="fz-instalar-pwa__ajuda" :aria-expanded="ajudaAberta" @click="alternarAjuda">{{ ajudaAberta ? 'Ocultar instruções' : 'Não sabe instalar?' }}</button>
                        </div>

                        <div class="fz-instalar-pwa__steps">
                            <div class="fz-instalar-pwa__steps-inner">
                                <div class="fz-instalar-pwa__lista-passos">
                                    <div class="fz-instalar-pwa__step">
                                        <span class="fz-instalar-pwa__numero">1</span>
                                        <div><strong>Clique em “Instalar agora”</strong><span>O navegador exibirá a confirmação.</span></div>
                                    </div>
                                    <div class="fz-instalar-pwa__step">
                                        <span class="fz-instalar-pwa__numero">2</span>
                                        <div><strong>Confirme a instalação</strong><span>Leva apenas alguns segundos.</span></div>
                                    </div>
                                    <div class="fz-instalar-pwa__step">
                                        <span class="fz-instalar-pwa__numero">3</span>
                                        <div><strong>Pronto</strong><span>O ícone ficará na tela inicial.</span></div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <p v-if="status" class="fz-instalar-pwa__status" role="status" aria-live="polite">{{ status }}</p>
                    </section>
                </div>
            </div>

            <button ref="gatilho" type="button" class="fz-instalar-pwa__gatilho" :aria-expanded="aberto" @click="alternar">
                <span class="fz-instalar-pwa__gatilho-icone" aria-hidden="true"><i class="pi pi-mobile"></i></span>
                <span class="fz-instalar-pwa__gatilho-texto">Instale o app</span>
            </button>
        </aside>
    `},(function(){const root=document.getElementById("instalar-pwa-app");if(!root||root.dataset.vueMounted==="1")return;root.dataset.vueMounted="1";const app=Vue.createApp({components:{"fz-instalar-pwa":window.FZComponents.InstalarPWA}});app.use(PrimeVue.Config,{theme:{preset:lojaPreset,options:{darkModeSelector:!1}}}),window.FZInstalarPWAAppInstance=app.mount(root)})();

if(typeof FZComponents=="undefined")var FZComponents={};if(typeof window.PerfilLojaStore=="undefined"){var _perfilLojaStoreFallback={mostrarCard:!0,aberto:!1,expandido:!1,clienteSegueLoja:!1,dados:{}};window.PerfilLojaStore=typeof Vue!="undefined"?Vue.reactive(_perfilLojaStoreFallback):_perfilLojaStoreFallback}(function(){function _definirComponentePerfilLoja(){if(typeof Vue=="undefined"||typeof PrimeVue=="undefined"||typeof window.FZComponents=="undefined"){if(window._perfilLojaComponentPending||(window._perfilLojaComponentPending=0),window._perfilLojaComponentPending>200)return;window._perfilLojaComponentPending++,setTimeout(_definirComponentePerfilLoja,50);return}FZComponents.PerfilLoja={components:{"p-dialog":PrimeVue.Dialog,"p-button":PrimeVue.Button},inject:["configsLoja","perfilLojaStore"],props:{mostrarCard:{type:Boolean,default:!0},comDialog:{type:Boolean,default:!0}},data(){return{store:window.PerfilLojaStore,componentId:"fz-store-profile-"+Math.random().toString(36).substr(2,9),logoErro:!1}},watch:{"dados.lojaLogo"(){this.logoErro=!1}},computed:{configs(){return this.configsLoja||{}},dados(){return Object.assign({},this.store.dados||{},window.PerfilLojaDados||{})},mostrarCardLocal(){return this.mostrarCard===!0},dialogVisible:{get(){return this.store.aberto===!0},set(value){this.store.aberto=!!value}},abertoCard(){return this.store.expandido},comDialogLocal(){return this.comDialog===!0},classeHost(){return this.mostrarCardLocal?"fz-perfil-loja-host fz-perfil-loja-host--card":"fz-perfil-loja-host fz-perfil-loja-host--modal"},lojaNome(){return this.dados.lojaNome||this.configs.nomeLoja||"Loja"},lojaLogo(){const valor=this.dados.lojaLogo||this.dados.perfilFoto||"";if(!valor)return"";if(/^(https?:|data:|blob:|\/\/)/i.test(valor))return valor;const base=this.configs&&this.configs.baseUrl?String(this.configs.baseUrl).replace(/\/$/,""):"";return base?base+"/"+String(valor).replace(/^\/+/,""):valor},logoCarregouOk(){return!this.logoErro&&!!this.lojaLogo},lojaInicial(){return(this.lojaNome||"L").charAt(0).toUpperCase()},verificada(){return!!this.dados.lojaVerificada},vendedorNome(){return this.dados.vendedorNome||""},bio(){return this.dados.bio||""},totalSeguidores(){return this.dados.totalSeguidores||0},totalPedidos(){return this.dados.totalPedidos||0},totalProdutos(){return this.dados.totalProdutosAtivados||0},totalVisitas(){return this.dados.totalVisualizacoes||0},totalCurtidas(){return this.dados.totalCurtidas||0},totalPerguntas(){return this.dados.totalPerguntas||0},habilitarCurtidas(){return this.dados.habilitarCurtidas===!0},habilitarPerguntas(){return this.dados.habilitarPerguntas===!0},ocultarSeguidores(){return!!this.dados.ocultarQuantidadeSeguidores},ocultarPedidos(){return!!this.dados.ocultarQuantidadePedidos},clienteSegueLoja(){return this.store.clienteSegueLoja===!0},clienteLogado(){return this.configs.clienteLogado===!0},visitanteLogado(){return this.configs.visitanteLogado===!0},autenticidadeVisivel(){return this.dados.autenticidadeVisivel===!0},tipoDocumento(){return this.dados.tipoDocumento||""},numeroDocumento(){return this.dados.numeroDocumento||""},documentoMascarado(){return this.dados.documentoMascarado||""},linkCnpjReceita(){return this.dados.linkCnpjReceita||"#"},mostrarNumeroDocumento(){return!!(this.numeroDocumento||this.documentoMascarado)},desde(){return this.dados.criadoEmFormatado||""},endereco(){return this.dados.endereco||""},enderecoLink(){return this.dados.enderecoLink||"#"},enderecoShopping(){return this.dados.enderecoShopping||""},enderecoShoppingLink(){return this.dados.enderecoShoppingLink||"#"},whatsapp(){return this.dados.whatsapp||""},whatsappLink(){return this.dados.whatsappLink||"#"},whatsappLabel(){return this.dados.whatsappLabel||""},instagramUsuario(){return this.dados.instagramUsuario||""},instagramLink(){return this.dados.instagramLink||"#"},email(){return this.dados.email||""},emailLink(){return this.dados.emailLink||"#"},pedidoMinimoTexto(){return this.dados.pedidoMinimoTexto||""},chipValidado(){return this.autenticidadeVisivel?this.tipoDocumento==="cnpj"&&this.mostrarNumeroDocumento?"CNPJ validado":this.tipoDocumento==="cpf"&&this.mostrarNumeroDocumento?"CPF validado":"Conta validada":""},chipsExtras(){const chips=[];return this.pedidoMinimoTexto&&chips.push("Pedido mínimo: "+this.pedidoMinimoTexto),this.desde&&chips.push("Desde "+this.desde),chips},linkReputacao(){return this.dados.linkReputacaoModal||"#"},temReputacao(){return!!this.dados.mostrarIconeNivel&&!!this.iconeNivel},iconeNivel(){return this.dados.iconeNivel||""},nomeNivel(){return this.dados.nomeNivel||""},descricaoLocalizacao(){return this.dados.descricaoLocalizacao||""}},methods:{fmtNumero(valor){if(valor==null||valor==="")return"0";const num=Number(valor);if(isNaN(num)||!isFinite(num))return String(valor);try{return num.toLocaleString("pt-BR")}catch(e){return String(valor)}},abrirStories(){typeof window.abrirStories=="function"&&window.abrirStories("home")},seguirLoja(){this.clienteLogado||this.visitanteLogado?typeof window.seguirLoja=="function"&&window.seguirLoja():typeof window.abrirModalLoginVisitante=="function"&&window.abrirModalLoginVisitante("seguir")},alternarExpandido(){this.store.expandido=!this.store.expandido},abrir(){this.store.aberto=!0},fechar(){this.store.aberto=!1},abrirModal(){this.store.aberto=!0},fecharModal(){this.store.aberto=!1},abrirReputacao(){if(typeof window.$=="function")try{window.$("#reputacaoModal").modal("show")}catch(e){}}},template:`
    <div :class="classeHost">

        <!-- CARD (página) -->
        <section v-if="mostrarCardLocal" class="fz-store-profile" :class="{ 'is-open': abertoCard }" :id="componentId">

                <div class="fz-store-profile__summary">
                    <div class="fz-store-profile__logo-wrap">
                        <img v-if="logoCarregouOk" class="fz-store-profile__logo" :src="lojaLogo" :alt="lojaNome" @error="logoErro = true">
                        <span v-else class="fz-store-profile__logo fz-store-profile__logo--placeholder">{{ lojaInicial }}</span>
                        <span v-if="verificada" class="fz-store-profile__verified" title="Loja verificada">&#10003;</span>
                    </div>

                    <div class="fz-store-profile__main">
                        <div class="fz-store-profile__title-line">
                            <h2 class="fz-store-profile__name">
                                {{ lojaNome }}
                                <img v-if="temReputacao" :src="iconeNivel" :alt="nomeNivel" :title="nomeNivel" class="fz-store-profile__level-icon">
                            </h2>
                            <span v-if="verificada" class="fz-store-profile__status" title="Loja verificada">&#9679;</span>
                        </div>

                        <p v-if="descricaoLocalizacao" class="fz-store-profile__category">{{ descricaoLocalizacao }}</p>

                        <div class="fz-store-profile__quick-stats">
                            <div v-if="!ocultarSeguidores" class="fz-store-profile__quick-stat">
                                <strong>{{ fmtNumero(totalSeguidores) }}</strong>
                                <span>Seguidores</span>
                            </div>
                            <div v-if="!ocultarPedidos" class="fz-store-profile__quick-stat">
                                <strong>{{ fmtNumero(totalPedidos) }}</strong>
                                <span>Pedidos</span>
                            </div>
                            <div class="fz-store-profile__quick-stat">
                                <strong>{{ fmtNumero(totalVisitas) }}</strong>
                                <span>Visitas</span>
                            </div>
                        </div>
                    </div>

                    <button
                        type="button"
                        class="fz-store-profile__follow"
                        :class="{ 'is-following': clienteSegueLoja }"
                        :aria-pressed="clienteSegueLoja ? 'true' : 'false'"
                        @click="seguirLoja">
                        <span aria-hidden="true">{{ clienteSegueLoja ? '✓' : '+' }}</span>
                        <span class="fz-store-profile__follow-text">{{ clienteSegueLoja ? 'Seguindo' : 'Seguir' }}</span>
                    </button>
                </div>

                <div class="fz-store-profile__trust">
                    <div class="fz-store-profile__trust-list">
                        <span v-if="chipValidado" class="fz-store-profile__chip fz-store-profile__chip--success">
                            ✓ {{ chipValidado }}
                        </span>
                        <span v-for="chip in chipsExtras" :key="chip" class="fz-store-profile__chip">
                            {{ chip }}
                        </span>
                    </div>

                    <button
                        type="button"
                        class="fz-store-profile__toggle"
                        :aria-expanded="abertoCard ? 'true' : 'false'"
                        :aria-controls="componentId + '-details'"
                        :aria-label="abertoCard ? 'Ocultar informações completas da loja' : 'Mostrar informações completas da loja'"
                        @click="alternarExpandido">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="m6 9 6 6 6-6"/>
                        </svg>
                    </button>
                </div>

                <div class="fz-store-profile__details" :id="componentId + '-details'">
                    <div class="fz-store-profile__details-inner">

                        <div class="fz-store-profile__details-head">
                            <div>
                                <strong>Informações da loja</strong>
                                <span>Dados comerciais e canais oficiais do lojista.</span>
                            </div>
                            <span v-if="verificada" class="fz-store-profile__badge">Loja verificada</span>
                        </div>

                        <div class="fz-store-profile__data-grid">
                            <div v-if="endereco" class="fz-store-profile__data fz-store-profile__data--wide">
                                <span class="fz-store-profile__data-label">
                                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
                                        <path d="M12 21s7-4.7 7-11a7 7 0 1 0-14 0c0 6.3 7 11 7 11Z"/>
                                        <circle cx="12" cy="10" r="2.3"/>
                                    </svg>
                                    Endereço
                                </span>
                                <span class="fz-store-profile__data-value">
                                    <a :href="enderecoLink" target="_blank" rel="noopener">{{ endereco }}</a>
                                </span>
                            </div>

                            <div v-if="enderecoShopping" class="fz-store-profile__data fz-store-profile__data--wide">
                                <span class="fz-store-profile__data-label">
                                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
                                        <path d="M4 7h16v11H4z"/>
                                        <path d="M8 4h8v3"/>
                                    </svg>
                                    Shopping
                                </span>
                                <span class="fz-store-profile__data-value">
                                    <a :href="enderecoShoppingLink" target="_blank" rel="noopener">{{ enderecoShopping }}</a>
                                </span>
                            </div>

                            <div v-if="whatsapp" class="fz-store-profile__data">
                                <span class="fz-store-profile__data-label">
                                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
                                        <path d="M7 3h10v18H7z"/>
                                        <path d="M10 6h4M10 18h4"/>
                                    </svg>
                                    WhatsApp
                                </span>
                                <span class="fz-store-profile__data-value">
                                    <a :href="whatsappLink" target="_blank" rel="noopener">{{ whatsappLabel }}</a>
                                </span>
                            </div>

                            <div v-if="email" class="fz-store-profile__data">
                                <span class="fz-store-profile__data-label">
                                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
                                        <rect x="3" y="5" width="18" height="14" rx="2"/>
                                        <path d="M4 7l8 6 8-6"/>
                                    </svg>
                                    E-mail
                                </span>
                                <span class="fz-store-profile__data-value">
                                    <a :href="emailLink">{{ email }}</a>
                                </span>
                            </div>

                            <div v-if="autenticidadeVisivel && mostrarNumeroDocumento" class="fz-store-profile__data">
                                <span class="fz-store-profile__data-label">
                                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
                                        <rect x="3" y="5" width="18" height="14" rx="2"/>
                                        <path d="M7 9h4M7 13h7"/>
                                    </svg>
                                    {{ tipoDocumento === 'cnpj' ? 'CNPJ' : 'CPF' }}
                                </span>
                                <span class="fz-store-profile__data-value">
                                    <a v-if="tipoDocumento === 'cnpj'" :href="linkCnpjReceita" target="_blank" rel="noopener">{{ numeroDocumento }} ✓</a>
                                    <template v-else>{{ documentoMascarado }} ✓</template>
                                </span>
                            </div>

                            <div v-if="desde" class="fz-store-profile__data">
                                <span class="fz-store-profile__data-label">
                                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
                                        <circle cx="12" cy="12" r="8.5"/>
                                        <path d="M12 7.5v5l3 2"/>
                                    </svg>
                                    Na plataforma
                                </span>
                                <span class="fz-store-profile__data-value">Desde {{ desde }}</span>
                            </div>

                            <div v-if="pedidoMinimoTexto" class="fz-store-profile__data">
                                <span class="fz-store-profile__data-label">
                                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
                                        <path d="M4 7h16v11H4z"/>
                                        <path d="M8 4h8v3"/>
                                    </svg>
                                    Pedido mínimo
                                </span>
                                <span class="fz-store-profile__data-value">{{ pedidoMinimoTexto }}</span>
                            </div>
                        </div>

                        <div class="fz-store-profile__metrics">
                            <div v-if="habilitarCurtidas" class="fz-store-profile__metric">
                                <strong>{{ fmtNumero(totalCurtidas) }}</strong>
                                <span>Curtidas</span>
                            </div>
                            <div v-if="habilitarPerguntas" class="fz-store-profile__metric">
                                <strong>{{ fmtNumero(totalPerguntas) }}</strong>
                                <span>Perguntas</span>
                            </div>
                            <div class="fz-store-profile__metric">
                                <strong>{{ fmtNumero(totalProdutos) }}</strong>
                                <span>Produtos</span>
                            </div>
                        </div>

                        <div class="fz-store-profile__actions">
                            <a v-if="instagramLink && instagramLink !== '#'"
                                class="fz-store-profile__action fz-store-profile__action--primary"
                                :href="instagramLink"
                                target="_blank"
                                rel="noopener">
                                Instagram
                            </a>

                            <a v-if="whatsappLink && whatsappLink !== '#'"
                                class="fz-store-profile__action fz-store-profile__action--secondary"
                                :href="whatsappLink"
                                target="_blank"
                                rel="noopener">
                                WhatsApp
                            </a>
                        </div>
                    </div>
                </div>
            </section>

        <!-- DIALOG (disponível quando comDialog=true) -->
        <p-dialog v-if="comDialogLocal"
                v-model:visible="dialogVisible"
                modal
                :draggable="false"
                :dismissableMask="true"
                :base-z-index="20000"
                :style="{ width: 'min(980px, 100%)' }"
                :breakpoints="{ '800px': '94vw' }"
                :pt="{ root: 'fz-store-modal-dialog', header: { class: 'fz-store-modal__header' }, content: { class: 'fz-store-modal__body' } }">
                <template #header>
                    <div class="fz-store-modal__header-copy">
                        <strong>Informações da Loja</strong>
                        <span>Conheça os dados comerciais e canais oficiais do lojista.</span>
                    </div>
                </template>

                <section class="fz-store-modal__dialog-inner">
                    <section class="fz-store-modal__hero">
                        <div class="fz-store-modal__logo-wrap">
                            <img v-if="logoCarregouOk" class="fz-store-modal__logo" :src="lojaLogo" :alt="lojaNome" @error="logoErro = true">
                            <span v-else class="fz-store-modal__logo fz-store-modal__logo--placeholder">{{ lojaInicial }}</span>
                            <span v-if="verificada" class="fz-store-modal__verified">&#10003;</span>
                        </div>

                        <div class="fz-store-modal__identity">
                            <div class="fz-store-modal__identity-top">
                                <h2 class="fz-store-modal__name">
                                    {{ lojaNome }}
                                    <img v-if="temReputacao" :src="iconeNivel" :alt="nomeNivel" :title="nomeNivel" class="fz-store-modal__level-icon">
                                </h2>
                            </div>

                            <p v-if="descricaoLocalizacao" class="fz-store-modal__category">{{ descricaoLocalizacao }}</p>

                            <div class="fz-store-modal__chips">
                                <span v-if="chipValidado" class="fz-store-modal__chip fz-store-modal__chip--success">
                                    ✓ {{ chipValidado }}
                                </span>
                                <span v-for="chip in chipsExtras" :key="chip" class="fz-store-modal__chip">{{ chip }}</span>
                            </div>
                        </div>

                        <button
                            type="button"
                            class="fz-store-modal__follow"
                            :class="{ 'is-following': clienteSegueLoja }"
                            :aria-pressed="clienteSegueLoja ? 'true' : 'false'"
                            @click="seguirLoja">
                            <span aria-hidden="true">{{ clienteSegueLoja ? '✓' : '+' }}</span>
                            <span>{{ clienteSegueLoja ? 'Seguindo' : 'Seguir' }}</span>
                        </button>
                    </section>

                    <div class="fz-store-modal__stats">
                        <div v-if="!ocultarSeguidores" class="fz-store-modal__stat">
                            <strong>{{ fmtNumero(totalSeguidores) }}</strong>
                            <span>Seguidores</span>
                        </div>
                        <div v-if="!ocultarPedidos" class="fz-store-modal__stat">
                            <strong>{{ fmtNumero(totalPedidos) }}</strong>
                            <span>Pedidos</span>
                        </div>
                        <div class="fz-store-modal__stat">
                            <strong>{{ fmtNumero(totalVisitas) }}</strong>
                            <span>Visitas</span>
                        </div>
                    </div>

                    <section class="fz-store-modal__section">
                        <h3 class="fz-store-modal__section-title">Dados comerciais</h3>

                        <div class="fz-store-modal__info-grid">
                            <div v-if="endereco" class="fz-store-modal__info fz-store-modal__info--wide">
                                <span class="fz-store-modal__info-label">
                                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
                                        <path d="M12 21s7-4.7 7-11a7 7 0 1 0-14 0c0 6.3 7 11 7 11Z"/>
                                        <circle cx="12" cy="10" r="2.3"/>
                                    </svg>
                                    Endereço
                                </span>
                                <span class="fz-store-modal__info-value">
                                    <a :href="enderecoLink" target="_blank" rel="noopener">{{ endereco }}</a>
                                </span>
                            </div>

                            <div v-if="enderecoShopping" class="fz-store-modal__info fz-store-modal__info--wide">
                                <span class="fz-store-modal__info-label">
                                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
                                        <path d="M4 7h16v11H4z"/>
                                        <path d="M8 4h8v3"/>
                                    </svg>
                                    Shopping
                                </span>
                                <span class="fz-store-modal__info-value">
                                    <a :href="enderecoShoppingLink" target="_blank" rel="noopener">{{ enderecoShopping }}</a>
                                </span>
                            </div>

                            <div v-if="whatsapp" class="fz-store-modal__info">
                                <span class="fz-store-modal__info-label">
                                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
                                        <path d="M7 3h10v18H7z"/>
                                        <path d="M10 6h4M10 18h4"/>
                                    </svg>
                                    WhatsApp
                                </span>
                                <span class="fz-store-modal__info-value">
                                    <a :href="whatsappLink" target="_blank" rel="noopener">{{ whatsappLabel }}</a>
                                </span>
                            </div>

                            <div v-if="email" class="fz-store-modal__info">
                                <span class="fz-store-modal__info-label">
                                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
                                        <rect x="3" y="5" width="18" height="14" rx="2"/>
                                        <path d="M4 7l8 6 8-6"/>
                                    </svg>
                                    E-mail
                                </span>
                                <span class="fz-store-modal__info-value">
                                    <a :href="emailLink">{{ email }}</a>
                                </span>
                            </div>

                            <div v-if="autenticidadeVisivel && mostrarNumeroDocumento" class="fz-store-modal__info">
                                <span class="fz-store-modal__info-label">
                                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
                                        <rect x="3" y="5" width="18" height="14" rx="2"/>
                                        <path d="M7 9h4M7 13h7"/>
                                    </svg>
                                    {{ tipoDocumento === 'cnpj' ? 'CNPJ' : 'CPF' }}
                                </span>
                                <span class="fz-store-modal__info-value">
                                    <a v-if="tipoDocumento === 'cnpj'" :href="linkCnpjReceita" target="_blank" rel="noopener">{{ numeroDocumento }} ✓</a>
                                    <template v-else>{{ documentoMascarado }} ✓</template>
                                </span>
                            </div>

                            <div v-if="desde" class="fz-store-modal__info">
                                <span class="fz-store-modal__info-label">
                                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
                                        <circle cx="12" cy="12" r="8.5"/>
                                        <path d="M12 7.5v5l3 2"/>
                                    </svg>
                                    Na plataforma
                                </span>
                                <span class="fz-store-modal__info-value">Desde {{ desde }}</span>
                            </div>

                            <div v-if="pedidoMinimoTexto" class="fz-store-modal__info">
                                <span class="fz-store-modal__info-label">
                                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
                                        <path d="M4 7h16v11H4z"/>
                                        <path d="M8 4h8v3"/>
                                    </svg>
                                    Pedido mínimo
                                </span>
                                <span class="fz-store-modal__info-value">{{ pedidoMinimoTexto }}</span>
                            </div>
                        </div>

                        <div class="fz-store-modal__extra">
                            <div v-if="habilitarCurtidas" class="fz-store-modal__extra-card">
                                <strong>{{ fmtNumero(totalCurtidas) }}</strong>
                                <span>Curtidas</span>
                            </div>
                            <div v-if="habilitarPerguntas" class="fz-store-modal__extra-card">
                                <strong>{{ fmtNumero(totalPerguntas) }}</strong>
                                <span>Perguntas</span>
                            </div>
                            <div class="fz-store-modal__extra-card">
                                <strong>{{ fmtNumero(totalProdutos) }}</strong>
                                <span>Produtos</span>
                            </div>
                        </div>
                    </section>
                </section>

                <template #footer>
                    <div class="fz-store-modal__footer">
                        <div class="fz-store-modal__actions">
                            <p-button v-if="instagramLink && instagramLink !== '#'"
                                as="a"
                                class="fz-store-modal__action"
                                severity="secondary"
                                outlined
                                :href="instagramLink"
                                target="_blank"
                                rel="noopener"
                                icon="pi pi-instagram"
                                label="Instagram"></p-button>
                            <p-button v-if="whatsappLink && whatsappLink !== '#'"
                                as="a"
                                class="fz-store-modal__action"
                                :href="whatsappLink"
                                target="_blank"
                                rel="noopener"
                                icon="pi pi-whatsapp"
                                severity="primary"
                                label="WhatsApp"></p-button>
                        </div>
                    </div>
                </template>
            </p-dialog>
    </div>
    `},typeof window.dispatchEvent=="function"&&window.dispatchEvent(new CustomEvent("fz-perfil-loja-component-ready"))}_definirComponentePerfilLoja()})(),typeof window.FacilZapPerfilLoja=="undefined"&&(window.FacilZapPerfilLoja={abrir:function(){window.PerfilLojaStore.aberto=!0},fechar:function(){window.PerfilLojaStore.aberto=!1},alternar:function(){window.PerfilLojaStore.aberto=!window.PerfilLojaStore.aberto}});

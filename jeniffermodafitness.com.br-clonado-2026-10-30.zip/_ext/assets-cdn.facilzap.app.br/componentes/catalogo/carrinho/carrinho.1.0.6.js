if(typeof FZComponents=="undefined")var FZComponents={};const CarrinhoDrawerStore=Vue.reactive({aberto:!1,carregando:!1,salvando:!1,erro:"",estado:null,entregaAberta:!1,cupomAberto:!1,cep:"",pais:"BR",versaoEntrega:0});if(FZComponents.CarrinhoCupons={components:{"p-button":PrimeVue.Button,"p-dialog":PrimeVue.Dialog},props:{cupons:{type:Array,default:()=>[]},categorias:{type:Array,default:()=>[]}},data(){return{codigoCopiado:null,timeoutCopiado:null,cuponsExpandidos:!1,cupomSelecionado:null,dialogRegrasVisivel:!1}},computed:{cuponsExibiveis(){return Array.isArray(this.cupons)?this.cupons.filter(cupom=>(cupom==null?void 0:cupom.codigo)&&this.cupomCompativelComCarrinho(cupom)):[]},cuponsVisiveis(){return this.cuponsExpandidos?this.cuponsExibiveis:this.cuponsExibiveis.slice(0,1)},exibirToggleCupons(){return this.cuponsExibiveis.length>1}},beforeUnmount(){this.timeoutCopiado&&clearTimeout(this.timeoutCopiado)},methods:{obterIdsCategorias(valor){return valor==null||valor===""?[]:Array.isArray(valor)?valor.flatMap(item=>this.obterIdsCategorias(item)):typeof valor=="object"?Object.entries(valor).flatMap(([id,subcategorias])=>[String(id),...this.obterIdsCategorias(subcategorias)]):String(valor).split(",").map(id=>id.trim()).filter(Boolean)},cupomCompativelComCarrinho(cupom){const categoriasCupom=this.obterIdsCategorias(cupom.categorias);if(categoriasCupom.length===0||this.categorias.length===0)return!0;const categoriasCarrinho=new Set(this.obterIdsCategorias(this.categorias));return categoriasCupom.some(categoria=>categoriasCarrinho.has(categoria))},cupomTemCatalogoRestrito(cupom){return this.obterIdsCategorias(cupom.catalogos).length>0},regrasCupom(cupom){const regras=[];if(!cupom)return regras;const valorMinimo=Number(cupom.valor_minimo_pedido||0),limiteUsoTotal=parseInt(cupom.limite_uso_total,10)||0,limiteUsoIndividual=parseInt(cupom.limite_uso_individual,10)||0,quantidadePedidos=parseInt(cupom.valor_quantidade_pedidos,10)||0;valorMinimo>0&&regras.push(`Pedido mínimo de R$ ${this.formatarPreco(valorMinimo)}`),cupom.tipo_quantidade_pedidos==="nenhum"?regras.push("Válido para a primeira compra"):cupom.tipo_quantidade_pedidos==="minimo"&&quantidadePedidos>0?regras.push(`Válido para clientes com no mínimo ${quantidadePedidos} pedido(s)`):cupom.tipo_quantidade_pedidos==="maximo"&&quantidadePedidos>=0&&regras.push(`Válido para clientes com no máximo ${quantidadePedidos} pedido(s)`),this.obterIdsCategorias(cupom.categorias).length>0&&regras.push("Válido para categorias selecionadas");const diasSemana=this.obterIdsCategorias(cupom.dias_semana);if(diasSemana.length>0){const nomesDias={1:"segunda-feira",2:"terça-feira",3:"quarta-feira",4:"quinta-feira",5:"sexta-feira",6:"sábado",7:"domingo"};regras.push(`Válido ${diasSemana.map(dia=>nomesDias[dia]).filter(Boolean).join(", ")}`)}const estados=this.obterIdsCategorias(cupom.estados);return estados.length>0&&regras.push(`Entrega válida para: ${estados.join(", ")}`),this.cupomTemCatalogoRestrito(cupom)&&regras.push("Válido neste catálogo"),limiteUsoTotal>0&&regras.push(`Limite de ${limiteUsoTotal} uso(s)`),limiteUsoIndividual>0&&regras.push(`Limite de ${limiteUsoIndividual} uso(s) por cliente`),cupom.limite_data_termino&&regras.push(`Válido até ${cupom.limite_data_termino}`),regras},abrirDialogRegras(cupom){this.cupomSelecionado=cupom,this.dialogRegrasVisivel=!0},formatarPreco(valor){return new Intl.NumberFormat("pt-BR",{minimumFractionDigits:2,maximumFractionDigits:2}).format(Number(valor)||0)},descricaoCupom(cupom){return cupom.descricao?cupom.descricao:cupom.tipo_valor==="porcentagem"?`${Number(cupom.valor||0)}% OFF`:cupom.tipo_valor==="fixo"?`R$ ${this.formatarPreco(cupom.valor)} OFF`:cupom.tipo_valor==="frete_gratis"?"Frete grátis":cupom.tipo_valor==="fixo_frete"?`R$ ${this.formatarPreco(cupom.valor)} OFF no frete`:cupom.tipo_valor==="porcentagem_frete"?`${Number(cupom.valor||0)}% OFF no frete`:"Desconto especial"},labelCupom(cupom){return cupom.tipo_quantidade_pedidos==="nenhum"?"CUPOM PRIMEIRA COMPRA":"CUPOM DE DESCONTO"},async copiarCodigo(codigo){var _a;const codigoCupom=String(codigo);try{(_a=navigator.clipboard)!=null&&_a.writeText?await navigator.clipboard.writeText(codigoCupom):this.copiarCodigoLegado(codigoCupom)}catch(error){try{this.copiarCodigoLegado(codigoCupom)}catch(fallbackError){console.error("Erro ao copiar cupom:",fallbackError);return}}this.codigoCopiado=codigoCupom,clearTimeout(this.timeoutCopiado),this.timeoutCopiado=setTimeout(()=>{this.codigoCopiado=null},1800)},copiarCodigoLegado(codigo){const input=document.createElement("textarea");input.value=codigo,input.setAttribute("readonly",""),input.style.position="fixed",input.style.opacity="0",document.body.appendChild(input),input.select();const copiado=document.execCommand("copy");if(input.remove(),!copiado)throw new Error("Não foi possível copiar o cupom")}},template:`
    <section v-if="cuponsExibiveis.length" class="fz-carrinho-cupons" aria-label="Cupons disponíveis">
        <transition-group name="fz-carrinho-cupons" tag="div" class="fz-carrinho-cupons__lista">
            <article v-for="(cupom, indice) in cuponsVisiveis" :key="cupom.codigo + indice" class="fz-carrinho-cupom">
                <div class="fz-carrinho-cupom__info">
                    <span class="fz-carrinho-cupom__icone" aria-hidden="true">
                        <svg viewBox="0 0 64 64" focusable="false">
                            <path d="M14 14h36a4 4 0 0 1 4 4v7.2c-3.7.7-6.5 3.9-6.5 7.8s2.8 7.1 6.5 7.8V46a4 4 0 0 1-4 4H14a4 4 0 0 1-4-4v-5.2c3.7-.7 6.5-3.9 6.5-7.8S13.7 25.9 10 25.2V18a4 4 0 0 1 4-4Z"/>
                            <path d="M32 17v30" stroke-dasharray="4 4"/>
                            <circle cx="24.5" cy="25.5" r="3.2"/>
                            <circle cx="39.5" cy="38.5" r="3.2"/>
                            <path d="M22 41.5 42 21.5"/>
                        </svg>
                    </span>
                    <div class="fz-carrinho-cupom__texto">
                        <span class="fz-carrinho-cupom__label">{{ labelCupom(cupom) }}</span>
                        <strong class="fz-carrinho-cupom__beneficio">{{ descricaoCupom(cupom) }}</strong>
                        <button
                            v-if="regrasCupom(cupom).length"
                            type="button"
                            class="fz-carrinho-cupom__regras-link"
                            aria-haspopup="dialog"
                            @click="abrirDialogRegras(cupom)">
                            Regras de Uso
                        </button>
                    </div>
                </div>

                <button
                    type="button"
                    class="fz-carrinho-cupom__copiar"
                    :class="{ 'fz-carrinho-cupom__copiar--copiado': codigoCopiado === cupom.codigo }"
                    :aria-label="'Copiar cupom ' + cupom.codigo"
                    @click="copiarCodigo(cupom.codigo)">
                    <span class="fz-carrinho-cupom__codigo">{{ cupom.codigo }}</span>
                    <span class="fz-carrinho-cupom__acao">
                        <i class="pi pi-copy" aria-hidden="true"></i>
                        <span>{{ codigoCopiado === cupom.codigo ? 'Copiado' : 'Copiar' }}</span>
                    </span>
                </button>
            </article>
        </transition-group>
        <p-button
            v-if="exibirToggleCupons"
            type="button"
            :label="cuponsExpandidos ? 'Ver menos cupons' : 'Ver mais cupons'"
            :icon="cuponsExpandidos ? 'pi pi-chevron-up' : 'pi pi-chevron-down'"
            outlined
            severity="primary"
            class="fz-carrinho-cupons__toggle"
            :aria-expanded="cuponsExpandidos"
            @click="cuponsExpandidos = !cuponsExpandidos"
        ></p-button>
        <p-dialog
            v-model:visible="dialogRegrasVisivel"
            modal
            :draggable="false"
            :dismissableMask="true"
            header="Regras de Uso"
            :style="{ width: '90vw', maxWidth: '460px' }"
            class="fz-carrinho-dialog-regras-cupom"
            :pt="{ header: 'pb-2', content: 'pt-0' }">
            <div v-if="cupomSelecionado" class="fz-carrinho-dialog-regras-cupom__conteudo">
                <div class="fz-carrinho-dialog-regras-cupom__cabecalho">
                    <span class="fz-carrinho-dialog-regras-cupom__label">{{ labelCupom(cupomSelecionado) }}</span>
                    <strong>{{ descricaoCupom(cupomSelecionado) }}</strong>
                    <span class="fz-carrinho-dialog-regras-cupom__codigo">Cupom: {{ cupomSelecionado.codigo }}</span>
                </div>
                <ul v-if="regrasCupom(cupomSelecionado).length" class="fz-carrinho-dialog-regras-cupom__lista">
                    <li v-for="regra in regrasCupom(cupomSelecionado)" :key="regra">{{ regra }}</li>
                </ul>
                <p v-else class="fz-carrinho-dialog-regras-cupom__sem-regras">
                    Este cupom não possui condições adicionais cadastradas.
                </p>
            </div>
        </p-dialog>
        <span class="sr-only" aria-live="polite">{{ codigoCopiado ? 'Cupom ' + codigoCopiado + ' copiado.' : '' }}</span>
    </section>
    `},FZComponents.CarrinhoDrawer={components:{"p-drawer":PrimeVue.Drawer,"p-button":PrimeVue.Button,"p-inputmask":PrimeVue.InputMask,"p-inputtext":PrimeVue.InputText,"p-progressbar":PrimeVue.ProgressBar,"p-skeleton":PrimeVue.Skeleton,"fz-select-pais":FZComponents.SelectPais,"fz-carrinho-cupons":FZComponents.CarrinhoCupons},inject:["configsLoja"],data(){return{store:CarrinhoDrawerStore,codigoCupom:"",ultimoEstado:null,estimativaRef:null,estimativaPadrao:{dados:null,visivel:!1,local:"Estimativa para sua cidade",prazo:"Calculando estimativa...",observacao:"Aguarde enquanto calculamos o prazo de entrega."}}},computed:{estimativa(){return this.estimativaRef||this.estimativaPadrao},visible:{get(){return this.store.aberto},set(value){value||this.fechar()}},estado(){return this.store.estado||{}},itens(){return this.estado.itens_detalhados||[]},brindes(){return this.estado.brindes||[]},categoriasCupons(){const itens=this.estado.lista_itens_categorias;return Array.isArray(itens)?[...new Set(itens.flatMap(item=>{var _a;return(_a=item==null?void 0:item.categorias)!=null?_a:[]}))]:[]},resumo(){return this.estado.resumo||{subtotal:0,desconto_cupom:0,desconto_total:0,total_sem_frete:0}},cupom(){return this.estado.cupom||!1},carrinhoVazio(){return!this.store.carregando&&this.itens.length===0},cepMask(){return this.store.pais==="BR"?"99999-999":null},entregaSelecionada(){this.store.versaoEntrega;const chave=`forma_entrega_pre_selecionada_${this.configsLoja.catalogoId}`,valor=localStorage.getItem(chave);if(!valor)return null;try{return JSON.parse(valor)}catch(error){return localStorage.removeItem(chave),null}},freteGratisElegivel(){var _a;return this.store.versaoEntrega,!this.configsLoja.freteGratisAtivado||((_a=this.cupom)==null?void 0:_a.tipo_valor)==="frete_gratis"||this.store.pais!=="BR"||!this.validarFaixasCep(this.cepLimpo,this.configsLoja.faixasCepGratis)?!1:this.configsLoja.freteGratisSomentePrimeiraCompra?sessionStorage.getItem("frete_gratis_elegivel")==="1":!0},progressoFrete(){const meta=Number(this.configsLoja.freteGratisValorMinimo)||0,porQuantidade=this.configsLoja.freteGratisCondicao==="qtd_itens",atual=Number(porQuantidade?this.estado.itens||0:this.resumo.total_sem_frete||0),restante=Math.max(0,meta-atual),percentual=meta>0?Math.min(100,Math.round(atual/meta*100)):100;return{meta,atual,restante,percentual,porQuantidade}},exibirProgressoFrete(){return this.freteGratisElegivel&&this.progressoFrete.meta>0},textoProgressoFrete(){if(this.progressoFrete.restante<=0)return"Parabéns! Você ganhou frete grátis";if(this.progressoFrete.porQuantidade){const unidade=this.progressoFrete.restante===1?"item":"itens";return`Faltam ${this.progressoFrete.restante} ${unidade} para frete grátis`}return`Faltam ${this.moeda(this.progressoFrete.restante)} para frete grátis`},cepLimpo(){return String(this.store.cep||"").replace(/\D/g,"")},podeCalcularFrete(){return!this.configsLoja.habilitarSimuladorFreteCarrinho||!this.itens.length?!1:this.store.pais==="BR"?this.cepLimpo.length===8:!!String(this.store.cep||"").trim()},textoEntrega(){var _a;return(_a=this.entregaSelecionada)!=null&&_a.nome?this.entregaSelecionada.nome:"Calcule pelo CEP e escolha a entrega"},textoResumoEntrega(){const entrega=this.entregaSelecionada;if(!entrega)return"A calcular";const valor=entrega.valor;return valor==null||valor===""||!Number.isFinite(Number(valor))?"A combinar":Number(valor)===0?"Grátis":this.moeda(valor)},valorEntregaSelecionada(){var _a;const valor=(_a=this.entregaSelecionada)==null?void 0:_a.valor;return valor==null||valor===""||!Number.isFinite(Number(valor))?0:Number(valor)},totalComEntrega(){return Number(this.resumo.total_sem_frete||0)+this.valorEntregaSelecionada},textoAcaoFinalizar(){return this.configsLoja.somenteOrcamentos?"Finalizar orçamento":"Finalizar pedido"}},watch:{"store.pais"(pais){pais!=="BR"&&(this.store.cep=String(this.store.cep||"").replace(/\D/g,""))},"store.cep"(novoCep){if(this.store.pais!=="BR"||!this.store.aberto||!this.configsLoja.freteFacilAtivado)return;const cepLimpo=String(novoCep||"").replace(/\D/g,"");if(cepLimpo.length===8){if(this.estimativaRef&&typeof window.FacilZapEstimativaPrazo!="undefined"){window.FacilZapEstimativaPrazo.notificarCep(cepLimpo,"carrinho");return}this.iniciarEstimativa()}}},mounted(){this.store.cep=localStorage.getItem("cliente_cep")||this.configsLoja.cepClienteLogado||"",this.store.pais=this.obterPaisAtual(),window.addEventListener("hashchange",this.aoAlterarHash),window.addEventListener("fz-carrinho-atualizado",this.aoAtualizarCarrinho),window.addEventListener("fz-frete-atualizado",this.aoAtualizarFrete),window.location.hash==="#carrinho"&&this.abrir({atualizarHash:!1})},beforeUnmount(){window.removeEventListener("hashchange",this.aoAlterarHash),window.removeEventListener("fz-carrinho-atualizado",this.aoAtualizarCarrinho),window.removeEventListener("fz-frete-atualizado",this.aoAtualizarFrete)},methods:{moeda(valor){return new Intl.NumberFormat("pt-BR",{style:"currency",currency:"BRL"}).format(Number(valor)||0)},formatarNumero(valor){return new Intl.NumberFormat("pt-BR").format(Number(valor)||0)},obterPaisAtual(){return typeof SimuladorFreteStore!="undefined"&&SimuladorFreteStore.paisAtual?SimuladorFreteStore.paisAtual:"BR"},validarFaixasCep(cep,faixasCep){return!faixasCep||Array.isArray(faixasCep)?!0:Object.values(faixasCep).some(faixa=>{const inicio=Number(String(faixa.inicio||"").replace(/\D/g,"")),termino=Number(String(faixa.termino||"").replace(/\D/g,"")),cepNumero=Number(cep);return cepNumero>=inicio&&cepNumero<=termino})},async abrir(opcoes={}){if(!(this.store.carregando||this.store.aberto&&!opcoes.recarregar)){this.store.aberto=!0,this.store.carregando=!0,window.dispatchEvent(new CustomEvent("fz-carrinho-aberto")),opcoes.atualizarHash!==!1&&window.location.hash!=="#carrinho"&&(window.location.hash="carrinho"),this.store.erro="",this.store.entregaAberta=!!opcoes.abrirEntrega;try{await this.sincronizarAlteracoesProduto(),await this.carregarEstado(!0),this.iniciarEstimativa()}catch(error){console.error("Erro ao abrir o carrinho:",error),this.store.erro="Não foi possível carregar seu carrinho. Tente novamente.",this.store.carregando=!1}if(opcoes.abrirEntrega){await Vue.nextTick();const secao=document.querySelector("[data-fz-carrinho-entrega]");secao&&secao.scrollIntoView({behavior:"smooth",block:"nearest"})}}},fechar(){this.store.aberto=!1,window.dispatchEvent(new CustomEvent("fz-carrinho-fechado")),window.location.hash==="#carrinho"&&history.replaceState("",document.title,`${window.location.pathname}${window.location.search}`)},iniciarEstimativa(){if(this.store.pais!=="BR"||!this.configsLoja.freteFacilAtivado||typeof window.FacilZapEstimativaPrazo=="undefined")return;const cep=this.cepLimpo.length===8?this.cepLimpo:null,contexto=this.obterContextoEstimativa();if(!this.estimativaRef){this.estimativaRef=window.FacilZapEstimativaPrazo.iniciar("carrinho",this.configsLoja,contexto);return}typeof window.FacilZapEstimativaPrazo.atualizarContexto=="function"?window.FacilZapEstimativaPrazo.atualizarContexto("carrinho",contexto):window.FacilZapEstimativaPrazo.consultar(cep,"carrinho")},obterContextoEstimativa(){const carrinho=this.estado.carrinho||{},assinatura=Object.keys(carrinho).sort().map(produtoId=>{const variacoes=carrinho[produtoId]||{};return[String(produtoId),Object.keys(variacoes).sort().map(variacaoId=>[String(variacaoId),Number(variacoes[variacaoId])||0])]});return{tipo:"carrinho",assinatura:JSON.stringify(assinatura)}},atualizarContextoEstimativa(){!this.estimativaRef||typeof window.FacilZapEstimativaPrazo=="undefined"||typeof window.FacilZapEstimativaPrazo.atualizarContexto!="function"||window.FacilZapEstimativaPrazo.atualizarContexto("carrinho",this.obterContextoEstimativa())},aoAlterarHash(){if(window.location.hash==="#carrinho"){this.abrir({atualizarHash:!1});return}this.store.aberto=!1,window.dispatchEvent(new CustomEvent("fz-carrinho-fechado"))},aoAtualizarCarrinho(event){var _a;event.detail!==this.ultimoEstado&&(_a=event.detail)!=null&&_a.itens_detalhados&&this.aplicarEstado(event.detail,!1)},aoAtualizarFrete(event){const dados=event.detail||{},entregaSelecionada=this.entregaSelecionada,cep=String(dados.cep||""),pais=String(dados.pais||"BR");entregaSelecionada&&(String(entregaSelecionada.cep||"")!==cep||String(entregaSelecionada.pais||"BR")!==pais)&&this.limparEntregaPreSelecionada(!1),dados.cep&&(this.store.cep=dados.cep),dados.pais&&(this.store.pais=dados.pais),this.store.versaoEntrega++,this.store.entregaAberta=!1,this.store.estado&&this.atualizarCabecalho(this.store.estado)},async sincronizarAlteracoesProduto(){typeof CarrinhoManager=="undefined"||typeof CarrinhoManager.flush!="function"||await CarrinhoManager.flush(this.configsLoja)},async carregarEstado(registrarVisualizacao=!1){this.store.carregando=!0;try{const estado=await this.requisitar("estado_carrinho",{registrar_visualizacao:registrarVisualizacao?"1":"0"});this.aplicarEstado(estado)}catch(error){console.error("Erro ao carregar o carrinho:",error),this.store.erro="Não foi possível carregar seu carrinho. Tente novamente."}finally{this.store.carregando=!1}},async requisitar(acao,dados={}){const body=new URLSearchParams({acao,...dados}),response=await fetch(this.configsLoja.urlCatalogo,{method:"POST",headers:{"Content-Type":"application/x-www-form-urlencoded"},body});if(!response.ok)throw new Error(`Resposta inválida: ${response.status}`);return response.json()},aplicarEstado(estado,emitirEvento=!0){!estado||typeof estado!="object"||(this.ultimoEstado=estado,this.store.estado=estado,this.store.erro="",this.sincronizarStoreGlobal(estado),this.atualizarCabecalho(estado),typeof window.aplicarEstadoCarrinho=="function"&&window.aplicarEstadoCarrinho(estado,!1),this.atualizarContextoEstimativa(),emitirEvento&&window.dispatchEvent(new CustomEvent("fz-carrinho-atualizado",{detail:estado})))},sincronizarStoreGlobal(estado){this.configsLoja.carrinho||(this.configsLoja.carrinho={}),Object.keys(this.configsLoja.carrinho).forEach(chave=>delete this.configsLoja.carrinho[chave]),Object.assign(this.configsLoja.carrinho,estado.carrinho||{})},atualizarCabecalho(estado){const itens=document.getElementById("total_carrinho_itens");itens&&(itens.textContent=estado.itens||0);const total=document.getElementById("total_carrinho");total&&!this.configsLoja.somenteOrcamentos&&!this.configsLoja.precosRestritos&&(total.textContent=this.moeda(this.totalComEntrega)),document.querySelectorAll(".btn-simular-frete").forEach(botao=>{botao.style.display=Number(estado.itens||0)>0?"":"none"})},quantidadeProdutoExceto(item){return this.itens.reduce((total,outroItem)=>String(outroItem.produto_id)!==String(item.produto_id)||outroItem.chave===item.chave?total:total+(Number(outroItem.quantidade)||0),0)},quantidadeValidada(item,quantidade){let valor=Math.max(0,Number(quantidade)||0);const multiplicador=Math.max(1,Number(item.multiplicador)||1),minimo=item.regra_quantidade_geral?0:Number(item.minimo||0);valor>0&&valor<minimo&&(valor=minimo),multiplicador>1&&valor>0&&(valor=Math.round(valor/multiplicador)*multiplicador);let limite=Number(item.maximo||0);if(item.regra_quantidade_geral){const maximoGeral=Number(item.maximo_geral||0);limite=maximoGeral>0?Math.max(0,maximoGeral-this.quantidadeProdutoExceto(item)):0}if(item.controlar_estoque){const estoque=Number(item.estoque||0);limite=limite>0?Math.min(limite,estoque):estoque}return limite>0&&valor>limite&&(valor=limite,multiplicador>1&&(valor=Math.floor(valor/multiplicador)*multiplicador),this.notificarMaximo(limite)),Math.max(0,valor)},notificarMaximo(limite){if(typeof showNotification=="function"){const unidade=Number(limite)===1?"unidade":"unidades";showNotification("Quantidade máxima atingida",`O máximo permitido é ${limite} ${unidade}.`,"info")}},alterarQuantidade(item,quantidade){const valor=this.quantidadeValidada(item,quantidade);valor!==Number(item.quantidade)&&this.salvarQuantidade(item,valor)},diminuirQuantidade(item){const proximaQuantidade=Number(item.quantidade)-Number(item.multiplicador||1),minimo=item.regra_quantidade_geral?0:Number(item.minimo||0);if(proximaQuantidade<minimo){this.salvarQuantidade(item,0);return}this.alterarQuantidade(item,proximaQuantidade)},editarQuantidade(item,event){this.alterarQuantidade(item,event.target.value)},async salvarQuantidade(item,quantidade){if(!this.store.salvando){if(this.configsLoja.carrinhoAbandonadoAtivo&&this.configsLoja.carrinhoAbandonadoSolicitarLoginVisitante&&!this.configsLoja.clienteLogado&&!this.configsLoja.visitanteLogado&&typeof abrirModalLoginVisitante=="function"){abrirModalLoginVisitante(null,()=>this.salvarQuantidade(item,quantidade));return}this.store.salvando=!0;try{const resposta=await this.requisitar("atualizar_carrinho",{formato:"json",pid:item.produto_id,vid:item.variacao_id,qtd:String(quantidade)});if(!resposta.sucesso||!resposta.estado_carrinho)throw new Error("Não foi possível atualizar o item.");this.limparEntregaPreSelecionada(),this.aplicarEstado(resposta.estado_carrinho),this.rastrearAlteracao(item,quantidade)}catch(error){console.error("Erro ao atualizar quantidade:",error),this.notificarErro("Tivemos um problema ao atualizar seu carrinho."),await this.carregarEstado()}finally{this.store.salvando=!1}}},removerItem(item){const remover=()=>this.salvarQuantidade(item,0);if(typeof showConfirmation=="function"){showConfirmation("Remover do carrinho","Você tem certeza que deseja remover este produto?",remover);return}window.confirm("Você tem certeza que deseja remover este produto?")&&remover()},rastrearAlteracao(item,quantidade){typeof facilZapEventos!="undefined"&&(Number(quantidade)===0&&typeof facilZapEventos.removerDoCarrinho=="function"?facilZapEventos.removerDoCarrinho(item.produto_id,item.nome,item.preco):Number(quantidade)>Number(item.quantidade)&&typeof facilZapEventos.adicionarAoCarrinho=="function"&&facilZapEventos.adicionarAoCarrinho(item.produto_id,item.nome,item.preco))},async aplicarCupom(){const codigo=String(this.codigoCupom||"").trim();if(!codigo){this.notificarErro("Informe um cupom de desconto.");return}this.store.salvando=!0;try{const resposta=await this.requisitar("aplicar_cupom",{formato:"json",cupom:codigo});if(!resposta.cupom_valido||!resposta.estado_carrinho)throw new Error(resposta.msg||"Cupom inválido.");this.codigoCupom="",this.store.cupomAberto=!1,this.limparEntregaPreSelecionada(),this.aplicarEstado(resposta.estado_carrinho),this.notificarSucesso("Cupom aplicado com sucesso.")}catch(error){this.notificarErro(error.message||"Não foi possível aplicar o cupom.")}finally{this.store.salvando=!1}},async removerCupom(){this.store.salvando=!0;try{const resposta=await this.requisitar("remover_cupom",{formato:"json"});if(!resposta.sucesso||!resposta.estado_carrinho)throw new Error("Não foi possível remover o cupom.");this.limparEntregaPreSelecionada(),this.aplicarEstado(resposta.estado_carrinho)}catch(error){this.notificarErro(error.message||"Não foi possível remover o cupom.")}finally{this.store.salvando=!1}},abrirFrete(){if(!this.podeCalcularFrete||typeof window.abrirSimuladorFrete!="function"){this.notificarErro("Informe um CEP válido para calcular a entrega.");return}const cep=this.store.pais==="BR"?this.cepLimpo:String(this.store.cep||"").trim();localStorage.setItem("cliente_cep",cep),localStorage.setItem("entrega_brasil",this.store.pais==="BR"),window.abrirSimuladorFrete(cep,this.store.pais,null,Number(this.estado.itens||0),Number(this.resumo.total_sem_frete||0))},limparEntregaPreSelecionada(atualizarVersao=!0){localStorage.removeItem(`forma_entrega_pre_selecionada_${this.configsLoja.catalogoId}`),atualizarVersao&&this.store.versaoEntrega++},abrirImagem(url){!url||typeof loadImageToModal!="function"||(this.store.aberto=!1,$("#imageZoomModal").one("hidden.bs.modal",()=>{this.store.aberto=!0}),loadImageToModal(url,"Imagem do Produto","modal-lg"))},iniciarFinalizacao(){if(!(this.store.salvando||this.carrinhoVazio)){if(window.FacilZapBarraFinalizacao&&typeof window.FacilZapBarraFinalizacao.finalizar=="function"){this.fechar(),window.FacilZapBarraFinalizacao.finalizar();return}this.notificarErro("Não foi possível iniciar a finalização. Atualize a página e tente novamente.")}},notificarErro(mensagem){if(typeof showNotification=="function"){showNotification("Ops!",mensagem,"error");return}window.alert(mensagem)},notificarSucesso(mensagem){typeof showNotification=="function"&&showNotification("",mensagem,"success")},textoDesconto(progresso){const regra=progresso.regra||{},valor=Number(regra.valor_desconto||0);let desconto=this.moeda(valor);regra.tipo_desconto==="porcentagem"&&(desconto=`${valor}%`),regra.tipo_desconto==="por_peca"&&(desconto=`${this.moeda(valor)} por item`);const categorias=this.formatarCategorias(progresso.categorias_nomes||[]),contexto=categorias==="todas"?"em todo o catálogo":`na${(progresso.categorias_nomes||[]).length>1?"s":""} categoria${(progresso.categorias_nomes||[]).length>1?"s":""} ${categorias}`;return`Ganhe ${desconto} de desconto ${contexto}`},textoFaltanteDesconto(progresso){const regra=progresso.regra||{},faltante=Number(regra.quantidade_faltante||0);if(progresso.tipo_regra==="valor")return`Adicione mais ${this.moeda(faltante)} em produtos elegíveis`;const quantidade=Math.ceil(faltante);return`Adicione mais ${quantidade} ${quantidade===1?"item":"itens"} elegíveis`},percentualDesconto(progresso){const regra=progresso.regra||{},meta=Number(regra.itens_minimo||0),atual=Math.max(0,meta-Number(regra.quantidade_faltante||0));return meta>0?Math.min(100,Math.round(atual/meta*100)):0},formatarCategorias(categorias){return categorias.length?categorias.length===1?categorias[0]:categorias.length===2?`${categorias[0]} e ${categorias[1]}`:`${categorias.slice(0,-1).join(", ")} e ${categorias[categorias.length-1]}`:"selecionada"}},template:`
    <p-drawer
        v-model:visible="visible"
        position="right"
        :dismissable="true"
        :closable="false"
        :block-scroll="true"
        :base-z-index="1000002"
        class="fz-carrinho-drawer"
        :style="{ width: 'min(520px, 100vw)' }"
    >
        <template #container>
            <section class="fz-carrinho-drawer__container" aria-labelledby="fz-carrinho-titulo">
                <header class="fz-carrinho-drawer__cabecalho">
                    <div>
                        <h2 id="fz-carrinho-titulo">Sua compra</h2>
                        <span>{{ formatarNumero(estado.itens || 0) }} {{ Number(estado.itens || 0) === 1 ? 'item' : 'itens' }}<template v-if="!configsLoja.somenteOrcamentos && !configsLoja.precosRestritos"> · {{ moeda(totalComEntrega) }}</template></span>
                    </div>
                    <button type="button" class="fz-carrinho-drawer__fechar" @click="fechar" aria-label="Fechar carrinho">
                        <i class="pi pi-times"></i>
                    </button>
                </header>

                <main class="fz-carrinho-drawer__corpo">
                    <div class="fz-carrinho-drawer__etapas" aria-label="Progresso da compra">
                        <span class="is-complete"><i class="pi pi-check" aria-hidden="true"></i>Produtos</span>
                        <span :class="{ 'is-complete': entregaSelecionada, 'is-active': !entregaSelecionada }"><i class="pi pi-check" aria-hidden="true"></i>Entrega</span>
                        <span><i class="pi pi-check" aria-hidden="true"></i>Pagamento</span>
                    </div>

                    <p v-if="store.erro" class="fz-carrinho-drawer__erro">{{ store.erro }}</p>

                    <div v-if="store.carregando" class="fz-carrinho-drawer__skeletons" aria-live="polite" aria-busy="true">
                        <div class="fz-carrinho-skeleton__etapas">
                            <p-skeleton v-for="indice in 3" :key="'etapa-' + indice" height="10px"></p-skeleton>
                        </div>
                        <article v-for="indice in 2" :key="'item-' + indice" class="fz-carrinho-skeleton__item">
                            <div class="fz-carrinho-skeleton__imagem">
                                <p-skeleton width="100%" height="100%"></p-skeleton>
                            </div>
                            <div class="fz-carrinho-skeleton__conteudo">
                                <p-skeleton width="75%" height="14px"></p-skeleton>
                                <p-skeleton width="45%" height="11px"></p-skeleton>
                                <div class="fz-carrinho-skeleton__rodape">
                                    <p-skeleton width="62px" height="18px"></p-skeleton>
                                    <p-skeleton width="106px" height="36px" border-radius="11px"></p-skeleton>
                                </div>
                            </div>
                        </article>
                        <div class="fz-carrinho-skeleton__secao">
                            <p-skeleton width="32%" height="14px"></p-skeleton>
                            <p-skeleton width="58%" height="11px"></p-skeleton>
                            <p-skeleton width="100%" height="42px" border-radius="10px"></p-skeleton>
                        </div>
                        <div class="fz-carrinho-skeleton__resumo">
                            <p-skeleton width="100%" height="14px"></p-skeleton>
                            <p-skeleton width="100%" height="14px"></p-skeleton>
                            <p-skeleton width="100%" height="28px"></p-skeleton>
                        </div>
                    </div>

                    <template v-else>
                        <div v-if="carrinhoVazio" class="fz-carrinho-drawer__vazio">
                            <i class="pi pi-shopping-cart"></i>
                            <h3>Seu carrinho está vazio</h3>
                            <p>Adicione produtos para continuar sua compra.</p>
                        </div>

                        <div v-else class="fz-carrinho-drawer__itens">
                            <article v-for="item in itens" :key="item.chave" class="fz-carrinho-item">
                                <button type="button" class="fz-carrinho-item__imagem" :class="{ 'is-empty': !item.imagem_url }" @click="abrirImagem(item.imagem_original_url)" :aria-label="'Ampliar imagem de ' + item.nome">
                                    <img v-if="item.imagem_url" :src="item.imagem_url" :alt="item.nome">
                                    <i v-else class="pi pi-image"></i>
                                </button>
                                <div class="fz-carrinho-item__conteudo">
                                    <div class="fz-carrinho-item__topo">
                                        <div>
                                            <strong>{{ item.nome }}</strong>
                                            <small v-if="item.variacao_nome">{{ item.grade ? item.variacao_nome : 'Variação: ' + item.variacao_nome }}</small>
                                        </div>
                                        <button type="button" class="fz-carrinho-item__remover" @click="removerItem(item)" :disabled="store.salvando" :aria-label="'Remover ' + item.nome">
                                            <i class="pi pi-trash"></i>
                                        </button>
                                    </div>
                                    <div class="fz-carrinho-item__rodape">
                                        <div v-if="!configsLoja.somenteOrcamentos && !configsLoja.precosRestritos" class="fz-carrinho-item__preco">
                                            <del v-if="item.preco_original">{{ moeda(item.preco_original) }}</del>
                                            <strong>{{ moeda(item.preco) }}</strong>
                                        </div>
                                        <div class="fz-carrinho-item__quantidade">
                                            <button type="button" @click="diminuirQuantidade(item)" :disabled="store.salvando" aria-label="Diminuir quantidade"><i class="pi pi-minus"></i></button>
                                            <input :value="item.quantidade" type="number" inputmode="numeric" :min="item.minimo || 0" :max="item.maximo || null" @change="editarQuantidade(item, $event)" :disabled="store.salvando" :aria-label="'Quantidade de ' + item.nome">
                                            <button type="button" @click="alterarQuantidade(item, Number(item.quantidade) + Number(item.multiplicador || 1))" :disabled="store.salvando" aria-label="Aumentar quantidade"><i class="pi pi-plus"></i></button>
                                        </div>
                                    </div>
                                </div>
                            </article>

                            <article v-for="brinde in brindes" :key="'brinde-' + brinde.id" class="fz-carrinho-item fz-carrinho-item--brinde">
                                <button type="button" class="fz-carrinho-item__imagem" :class="{ 'is-empty': !brinde.imagem_url }" @click="abrirImagem(brinde.imagem_url)" :aria-label="'Ampliar imagem de ' + brinde.nome">
                                    <img v-if="brinde.imagem_url" :src="brinde.imagem_url" :alt="brinde.nome">
                                    <i v-else class="pi pi-gift"></i>
                                </button>
                                <div class="fz-carrinho-item__conteudo">
                                    <div class="fz-carrinho-item__topo">
                                        <div>
                                            <strong>{{ brinde.nome }}</strong>
                                            <small><i class="pi pi-gift"></i> Brinde</small>
                                        </div>
                                        <span class="fz-carrinho-item__qtd-brinde">{{ brinde.quantidade }}x</span>
                                    </div>
                                </div>
                            </article>
                         </div>

                         <section v-if="exibirProgressoFrete && !carrinhoVazio" class="fz-carrinho-progresso fz-carrinho-progresso--frete" :class="{ 'is-complete': progressoFrete.restante <= 0 }">
                            <div class="fz-carrinho-progresso__topo">
                                <div>
                                    <strong>{{ textoProgressoFrete }}</strong>
                                    <span v-if="progressoFrete.restante > 0">Você está quase lá.</span>
                                    <span v-else>O benefício será aplicado na entrega elegível.</span>
                                </div>
                                <b>{{ progressoFrete.percentual }}%</b>
                            </div>
                            <p-progressbar :value="progressoFrete.percentual" :show-value="false"></p-progressbar>
                        </section>

                        <section v-for="(progresso, indice) in estado.proximas_regras_desconto || []" :key="'desconto-' + indice" class="fz-carrinho-progresso" :class="{ 'is-complete': percentualDesconto(progresso) >= 100 }">
                            <div class="fz-carrinho-progresso__topo">
                                <div>
                                    <strong>{{ textoDesconto(progresso) }}</strong>
                                    <span>{{ textoFaltanteDesconto(progresso) }}</span>
                                </div>
                                <b>{{ percentualDesconto(progresso) }}%</b>
                            </div>
                            <p-progressbar :value="percentualDesconto(progresso)" :show-value="false"></p-progressbar>
                        </section>

                        <section v-if="configsLoja.habilitarSimuladorFreteCarrinho && !carrinhoVazio" class="fz-carrinho-secao" :class="{ 'is-open': store.entregaAberta }" data-fz-carrinho-entrega>
                            <button type="button" class="fz-carrinho-secao__toggle" @click="store.entregaAberta = !store.entregaAberta">
                                <span>
                                    <strong>Entrega</strong>
                                    <small>{{ textoEntrega }}</small>
                                </span>
                                <i class="pi pi-chevron-down"></i>
                            </button>
                            <div v-if="store.entregaAberta" class="fz-carrinho-secao__conteudo">
                                <div class="fz-carrinho-entrega__campos" :class="{ 'fz-carrinho-entrega__campos--com-pais': configsLoja.permitirEntregaInternacional }">
                                    <fz-select-pais v-if="configsLoja.permitirEntregaInternacional" v-model="store.pais" select-type="reduced"></fz-select-pais>
                                    <p-inputmask v-if="store.pais === 'BR'" v-model="store.cep" mask="99999-999" placeholder="Digite seu CEP" inputmode="numeric" @keydown.enter="abrirFrete"></p-inputmask>
                                    <p-inputtext v-else v-model="store.cep" placeholder="Código postal" @keydown.enter="abrirFrete"></p-inputtext>
                                    <p-button label="Calcular" severity="primary" :disabled="!podeCalcularFrete" @click="abrirFrete"></p-button>
                                </div>

                                <div v-if="store.pais === 'BR' && configsLoja.freteFacilAtivado"
                                     class="fz-estimativa-prazo"
                                     v-show="estimativa.visivel"
                                     data-fz-estimativa-prazo="carrinho">
                                    <div class="fz-estimativa-prazo__icone" aria-hidden="true">
                                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
                                            <circle cx="12" cy="12" r="8.5"/>
                                            <path d="M12 7.5v5"/>
                                            <path d="M12 12.5l3 2"/>
                                        </svg>
                                    </div>
                                    <div>
                                        <span class="fz-estimativa-prazo__local">{{ estimativa.local }}</span>
                                        <p class="fz-estimativa-prazo__prazo">{{ estimativa.prazo }}</p>
                                        <p class="fz-estimativa-prazo__observacao">{{ estimativa.observacao }}</p>
                                    </div>
                                </div>

                                <p v-if="entregaSelecionada" class="fz-carrinho-entrega__aviso">Entrega pré-selecionada. A confirmação acontece na finalização.</p>
                            </div>
                        </section>

                        <section v-if="configsLoja.habilitarCuponsDesconto && !carrinhoVazio" class="fz-carrinho-secao" :class="{ 'is-open': store.cupomAberto || cupom }">
                            <button type="button" class="fz-carrinho-secao__toggle" @click="store.cupomAberto = !store.cupomAberto">
                                <span>
                                    <strong>Tem cupom de desconto?</strong>
                                    <small v-if="cupom">{{ cupom.codigo }} {{ cupom.tipo_valor === 'frete_gratis' ? '· Frete grátis' : cupom.tipo_valor === 'fixo_frete' ? '· ' + moeda(cupom.valor) + ' no frete' : cupom.tipo_valor === 'porcentagem_frete' ? '· ' + Number(cupom.valor || 0) + '% no frete' : '· ' + moeda(cupom.valor) }}</small>
                                    <small v-else>Adicione somente se tiver um código</small>
                                </span>
                                <i class="pi pi-chevron-down"></i>
                            </button>
                            <div v-if="store.cupomAberto || cupom" class="fz-carrinho-secao__conteudo">
                                <div v-if="cupom" class="fz-carrinho-cupom-aplicado">
                                    <span><i class="pi pi-tag"></i> {{ cupom.codigo }}</span>
                                    <button type="button" @click="removerCupom" :disabled="store.salvando">Remover</button>
                                </div>
                                <div v-else class="fz-carrinho-cupom__campos">
                                    <p-inputtext v-model="codigoCupom" placeholder="Digite seu cupom" @keydown.enter="aplicarCupom"></p-inputtext>
                                    <p-button label="Aplicar" severity="primary" :loading="store.salvando" @click="aplicarCupom"></p-button>
                                </div>
                            </div>
                        </section>

                         <fz-carrinho-cupons
                             v-if="configsLoja.habilitarCuponsDesconto && !carrinhoVazio"
                             :cupons="configsLoja.cuponsDivulgaveis"
                             :categorias="categoriasCupons"
                         ></fz-carrinho-cupons>

                        <section v-if="!carrinhoVazio && !configsLoja.somenteOrcamentos && !configsLoja.precosRestritos" class="fz-carrinho-incentivos">
                            <p><i class="pi pi-check" aria-hidden="true"></i><span>Compra protegida com revisão antes do envio.</span></p>
                            <p><i class="pi pi-check" aria-hidden="true"></i><span>Você economiza ao escolher a melhor entrega.</span></p>
                            <p><i class="pi pi-check" aria-hidden="true"></i><span>Pagamento seguro e dados protegidos.</span></p>
                        </section>

                        <section v-if="!carrinhoVazio && !configsLoja.somenteOrcamentos && !configsLoja.precosRestritos" class="fz-carrinho-resumo">
                            <div><span>Subtotal</span><strong>{{ moeda(resumo.subtotal) }}</strong></div>
                            <div><span>Entrega</span><strong>{{ textoResumoEntrega }}</strong></div>
                            <div v-if="resumo.desconto_total > 0"><span>Economia</span><strong>- {{ moeda(resumo.desconto_total) }}</strong></div>
                            <div class="fz-carrinho-resumo__total"><span>Total</span><strong>{{ moeda(totalComEntrega) }}</strong></div>
                        </section>
                    </template>
                </main>

                <footer v-if="store.carregando" class="fz-carrinho-drawer__rodape fz-carrinho-drawer__rodape--skeleton" aria-hidden="true">
                    <div class="fz-carrinho-drawer__acao">
                        <div>
                            <p-skeleton width="40px" height="10px"></p-skeleton>
                            <p-skeleton width="92px" height="22px"></p-skeleton>
                        </div>
                        <div class="fz-carrinho-skeleton__botao">
                            <p-skeleton width="100%" height="100%" border-radius="12px"></p-skeleton>
                        </div>
                    </div>
                </footer>
                <footer v-else-if="!carrinhoVazio" class="fz-carrinho-drawer__rodape">
                    <div class="fz-carrinho-drawer__acao" :class="{ 'fz-carrinho-drawer__acao--sem-total': configsLoja.somenteOrcamentos || configsLoja.precosRestritos }">
                        <div v-if="!configsLoja.somenteOrcamentos && !configsLoja.precosRestritos">
                            <span>Total</span>
                            <strong>{{ moeda(totalComEntrega) }}</strong>
                        </div>
                        <p-button type="button" :label="textoAcaoFinalizar + ' →'" severity="primary" :loading="store.salvando" :disabled="store.carregando" @click="iniciarFinalizacao"></p-button>
                    </div>
                    <div v-if="!configsLoja.somenteOrcamentos && !configsLoja.precosRestritos" class="fz-carrinho-drawer__confianca">
                        <span><i class="pi pi-lock" aria-hidden="true"></i>Compra segura</span>
                        <span><i class="pi pi-check" aria-hidden="true"></i>Revisão antes do envio</span>
                        <span><i class="pi pi-check" aria-hidden="true"></i>Dados protegidos</span>
                    </div>
                </footer>
            </section>
        </template>
    </p-drawer>
    `},document.getElementById("catalogo-overlays-app")&&!window.FZCatalogoOverlaysAppInstance){const FZCatalogoOverlaysApp=Vue.createApp({components:{"fz-barra-finalizacao":FZComponents.BarraFinalizacao,"fz-carrinho-drawer":FZComponents.CarrinhoDrawer,"fz-simulador-frete-dialog":FZComponents.SimuladorFreteDialog,"fz-formas-entrega-pagamento":FZComponents.FormasEntregaPagamento,"fz-termos-politicas":FZComponents.TermosPoliticas,"fz-conta-visitante-popover":FZComponents.ContaVisitantePopover}});FZCatalogoOverlaysApp.use(PrimeVue.Config,{theme:{preset:lojaPreset,options:{darkModeSelector:!1}}}),FZCatalogoOverlaysApp.provide("configsLoja",configsLoja),FZCatalogoOverlaysApp.provide("baseUrlCatalogo",baseUrlCatalogo),FZCatalogoOverlaysApp.provide("obterURLImageTransform",obterURLImageTransform),window.FZCatalogoOverlaysAppInstance=FZCatalogoOverlaysApp.mount("#catalogo-overlays-app"),window.FZCarrinhoDrawerStore=CarrinhoDrawerStore,window.FacilZapBarraFinalizacao={abrirAutenticacao:function(retorno,callback){const barra=window.FZCatalogoOverlaysAppInstance.$refs.barraFinalizacao;return barra?(barra.abrirAutenticacao(retorno,callback),!0):!1},finalizar:function(){const barra=window.FZCatalogoOverlaysAppInstance.$refs.barraFinalizacao;return barra?(barra.solicitarFinalizacao(),!0):!1}},window.abrirCarrinhoVue=function(opcoes){const carrinho=window.FZCatalogoOverlaysAppInstance.$refs.carrinho;if(carrinho)return carrinho.abrir(opcoes||{})},window.verCarrinho=function(opcoes){return window.abrirCarrinhoVue(opcoes||{})},window.FacilZapFormasEntrega={abrir:function(){const formas=window.FZCatalogoOverlaysAppInstance.$refs.formasEntregaPagamento;formas&&formas.abrirEntrega()},fechar:function(){const formas=window.FZCatalogoOverlaysAppInstance.$refs.formasEntregaPagamento;formas&&formas.fecharEntrega()}},window.FacilZapFormasPagamento={abrir:function(){const formas=window.FZCatalogoOverlaysAppInstance.$refs.formasEntregaPagamento;formas&&formas.abrirPagamento()},fechar:function(){const formas=window.FZCatalogoOverlaysAppInstance.$refs.formasEntregaPagamento;formas&&formas.fecharPagamento()}},window.FacilZapTermosPoliticas={abrir:function(){const termosPoliticas=window.FZCatalogoOverlaysAppInstance.$refs.termosPoliticas;termosPoliticas&&termosPoliticas.abrir()},fechar:function(){const termosPoliticas=window.FZCatalogoOverlaysAppInstance.$refs.termosPoliticas;termosPoliticas&&termosPoliticas.fechar()},abrirPolitica:function(chave){const termosPoliticas=window.FZCatalogoOverlaysAppInstance.$refs.termosPoliticas;termosPoliticas&&termosPoliticas.abrir(chave)}},window.FacilZapContaVisitantePopover={abrir:function(elemento){const contaVisitantePopover=window.FZCatalogoOverlaysAppInstance.$refs.contaVisitantePopover;return contaVisitantePopover?contaVisitantePopover.abrir(elemento):!1},fechar:function(){const contaVisitantePopover=window.FZCatalogoOverlaysAppInstance.$refs.contaVisitantePopover;contaVisitantePopover&&contaVisitantePopover.fechar()}}}

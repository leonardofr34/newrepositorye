if(typeof FZComponents=="undefined")var FZComponents={};FZComponents.FiltrosCatalogo={components:{"p-drawer":PrimeVue.Drawer},props:{grupos:{type:Array,default:function(){return[]}},variacoesAtivas:{type:Array,default:function(){return[]}},mostrarCategorias:{type:Boolean,default:!1}},data:function(){var idsDisponiveis=new Set;this.grupos.forEach(function(grupo){(grupo.variacoes||[]).forEach(function(variacao){idsDisponiveis.add(String(variacao.id))})});var selecionadas=Array.from(new Set((this.variacoesAtivas||[]).map(String))).filter(function(id){return idsDisponiveis.has(id)});return{aberto:!1,buscaGlobal:"",buscasGrupo:{},selecionadas,selecionadasIniciais:selecionadas.slice(),grupoAtivo:""}},computed:{gruposNormalizados:function(){return(this.grupos||[]).map(function(grupo,indice){return{chave:"grupo-"+indice,id:String(grupo.id||indice),nome:String(grupo.nome||"Variações"),variacoes:(grupo.variacoes||[]).map(function(variacao){return{id:String(variacao.id),nome:String(variacao.nome||""),totalProdutos:Number(variacao.total_produtos||0)}}).filter(function(variacao){return variacao.id&&variacao.nome})}}).filter(function(grupo){return grupo.variacoes.length>0})},gruposVisiveis:function(){var self=this,termoGlobal=this.normalizarTexto(this.buscaGlobal);return this.gruposNormalizados.map(function(grupo){var termoGrupo=self.normalizarTexto(self.buscasGrupo[grupo.chave]||""),nomeGrupoCorresponde=!termoGlobal||self.normalizarTexto(grupo.nome).includes(termoGlobal),variacoesBuscaGlobal=grupo.variacoes.filter(function(variacao){var correspondeBuscaGlobal=!termoGlobal||nomeGrupoCorresponde||self.normalizarTexto(variacao.nome).includes(termoGlobal);return correspondeBuscaGlobal}),variacoes=variacoesBuscaGlobal.filter(function(variacao){return!termoGrupo||self.normalizarTexto(variacao.nome).includes(termoGrupo)});return Object.assign({},grupo,{possuiResultadoBuscaGlobal:variacoesBuscaGlobal.length>0,variacoesVisiveis:variacoes})}).filter(function(grupo){return grupo.possuiResultadoBuscaGlobal})},selecionadasDetalhes:function(){var self=this,selecionadas=[];return this.gruposNormalizados.forEach(function(grupo){grupo.variacoes.forEach(function(variacao){self.selecionadas.includes(variacao.id)&&selecionadas.push({id:variacao.id,nome:variacao.nome,grupo:grupo.nome})})}),selecionadas},temSelecoes:function(){return this.selecionadas.length>0},temAlteracoes:function(){return this.chaveSelecao(this.selecionadas)!==this.chaveSelecao(this.selecionadasIniciais)},exibirRodape:function(){return this.temSelecoes||this.temAlteracoes},textoSelecionados:function(){var quantidade=this.selecionadas.length;return quantidade+" varia"+(quantidade===1?"ção selecionada":"ções selecionadas")}},watch:{aberto:function(aberto){var self=this;aberto&&this.$nextTick(function(){!self.grupoAtivo&&self.gruposVisiveis.length>0&&(self.grupoAtivo=self.gruposVisiveis[0].chave)})},gruposVisiveis:function(grupos){grupos.some(function(grupo){return grupo.chave===this.grupoAtivo},this)||(this.grupoAtivo=grupos.length>0?grupos[0].chave:"")}},methods:{normalizarTexto:function(valor){return String(valor||"").normalize("NFD").replace(/[\u0300-\u036f]/g,"").toLocaleLowerCase("pt-BR")},chaveSelecao:function(ids){return ids.slice().sort().join(",")},abrir:function(){this.aberto=!0},fechar:function(){this.aberto=!1},variacaoSelecionada:function(id){return this.selecionadas.includes(String(id))},alternarVariacao:function(id){if(id=String(id),this.variacaoSelecionada(id)){this.selecionadas=this.selecionadas.filter(function(variacaoId){return variacaoId!==id});return}this.selecionadas.push(id)},removerVariacao:function(id){id=String(id),this.selecionadas=this.selecionadas.filter(function(variacaoId){return variacaoId!==id})},limpar:function(){this.selecionadas=[]},quantidadeSelecionadaGrupo:function(grupo){var self=this;return grupo.variacoes.filter(function(variacao){return self.variacaoSelecionada(variacao.id)}).length},textoAtalhoGrupo:function(grupo){var selecionadas=this.quantidadeSelecionadaGrupo(grupo);return selecionadas?selecionadas+"/"+grupo.variacoes.length:grupo.variacoes.length},rolarParaGrupo:function(grupo){var self=this;this.grupoAtivo=grupo.chave,this.$nextTick(function(){var corpo=self.$refs.corpo;if(corpo){var secao=corpo.querySelector('[data-fz-filtro-grupo="'+grupo.chave+'"]');if(secao){var corpoRect=corpo.getBoundingClientRect(),secaoRect=secao.getBoundingClientRect();corpo.scrollTo({top:Math.max(0,corpo.scrollTop+secaoRect.top-corpoRect.top-8),behavior:"smooth"})}}})},atualizarGrupoAtivo:function(){var corpo=this.$refs.corpo;if(corpo){var corpoRect=corpo.getBoundingClientRect(),secoes=Array.prototype.slice.call(corpo.querySelectorAll("[data-fz-filtro-grupo]")),secaoAtual=null,menorDistancia=1/0;secoes.forEach(function(secao){var distancia=Math.abs(secao.getBoundingClientRect().top-corpoRect.top-8);distancia<menorDistancia&&(menorDistancia=distancia,secaoAtual=secao)}),secaoAtual&&(this.grupoAtivo=secaoAtual.getAttribute("data-fz-filtro-grupo"))}},abrirCategorias:function(){this.fechar(),window.setTimeout(function(){var botaoMenu=document.querySelector(".btn-abrir-menu-mobile");botaoMenu&&botaoMenu.click()},250)},aplicar:function(){var url=new URL(window.location.href);this.selecionadas.length>0?url.searchParams.set("variacoes",this.selecionadas.join(",")):url.searchParams.delete("variacoes"),window.location.assign(url.toString())},textoDisponibilidade:function(totalProdutos){return"Disponível em "+totalProdutos+" "+(totalProdutos===1?"produto":"produtos")}},template:`
        <div class="fz-filtros-catalogo">
            <button type="button" class="fz-filtros-catalogo__gatilho" @click="abrir" aria-label="Abrir filtros">
                <span>Filtrar</span>
                <span v-if="temSelecoes" class="fz-filtros-catalogo__contador">{{ selecionadas.length }}</span>
                <i class="pi pi-filter" aria-hidden="true"></i>
            </button>

            <p-drawer
                v-model:visible="aberto"
                position="right"
                :dismissable="true"
                :closable="false"
                :block-scroll="true"
                :base-z-index="1000102"
                :style="{ width: 'min(480px, 100vw)' }"
                class="fz-filtros-catalogo-drawer"
            >
                <template #container>
                    <section class="fz-filtros-catalogo__drawer" aria-labelledby="fz-filtros-catalogo-titulo">
                        <header class="fz-filtros-catalogo__cabecalho">
                            <div class="fz-filtros-catalogo__cabecalho-topo">
                                <div>
                                    <h2 id="fz-filtros-catalogo-titulo" class="fz-filtros-catalogo__titulo">Filtros</h2>
                                    <p class="fz-filtros-catalogo__descricao">Selecione tamanhos, cores ou outras opções dos produtos.</p>
                                </div>
                                <div class="fz-filtros-catalogo__acoes-cabecalho">
                                    <button
                                        v-if="mostrarCategorias"
                                        type="button"
                                        class="fz-filtros-catalogo__botao-icone fz-filtros-catalogo__botao-categorias"
                                        aria-label="Abrir categorias"
                                        title="Categorias"
                                        @click="abrirCategorias"
                                    >
                                        <i class="pi pi-list" aria-hidden="true"></i>
                                    </button>
                                    <button type="button" class="fz-filtros-catalogo__botao-icone" aria-label="Fechar filtros" @click="fechar">
                                        <i class="pi pi-times" aria-hidden="true"></i>
                                    </button>
                                </div>
                            </div>

                            <label class="fz-filtros-catalogo__busca-global">
                                <i class="pi pi-search" aria-hidden="true"></i>
                                <input ref="buscaGlobal" v-model="buscaGlobal" class="fz-filtros-catalogo__campo-busca" type="search" placeholder="Pesquisar grupo ou variação" aria-label="Pesquisar grupo ou variação">
                            </label>

                            <section v-if="temSelecoes" class="fz-filtros-catalogo__selecionados" aria-label="Variações selecionadas">
                                <div class="fz-filtros-catalogo__selecionados-cabecalho">
                                    <strong>{{ textoSelecionados }}</strong>
                                    <button type="button" class="fz-filtros-catalogo__limpar-texto" @click="limpar">Limpar tudo</button>
                                </div>
                                <div class="fz-filtros-catalogo__chips">
                                    <span v-for="variacao in selecionadasDetalhes" :key="variacao.id" class="fz-filtros-catalogo__chip">
                                        <span>{{ variacao.nome }}</span>
                                        <button type="button" :aria-label="'Remover ' + variacao.nome" @click="removerVariacao(variacao.id)">
                                            <i class="pi pi-times" aria-hidden="true"></i>
                                        </button>
                                    </span>
                                </div>
                            </section>

                            <nav v-if="gruposVisiveis.length > 0" class="fz-filtros-catalogo__navegacao-grupos" aria-label="Grupos de variações">
                                <h3>Grupos encontrados</h3>
                                <div class="fz-filtros-catalogo__lista-grupos">
                                    <button
                                        v-for="grupo in gruposVisiveis"
                                        :key="grupo.chave"
                                        type="button"
                                        class="fz-filtros-catalogo__atalho-grupo"
                                        :class="{ 'is-ativo': grupoAtivo === grupo.chave }"
                                        @click="rolarParaGrupo(grupo)"
                                    >
                                        <strong>{{ grupo.nome }}</strong>
                                        <span>{{ textoAtalhoGrupo(grupo) }}</span>
                                    </button>
                                </div>
                            </nav>
                        </header>

                        <main ref="corpo" class="fz-filtros-catalogo__corpo" @scroll="atualizarGrupoAtivo">
                            <template v-if="gruposVisiveis.length > 0">
                                <section
                                    v-for="grupo in gruposVisiveis"
                                    :key="grupo.chave"
                                    class="fz-filtros-catalogo__grupo"
                                    :data-fz-filtro-grupo="grupo.chave"
                                >
                                    <div class="fz-filtros-catalogo__titulo-grupo">
                                        <h3>{{ grupo.nome }}</h3>
                                        <span v-if="quantidadeSelecionadaGrupo(grupo) > 0">{{ quantidadeSelecionadaGrupo(grupo) }} selecionada{{ quantidadeSelecionadaGrupo(grupo) > 1 ? 's' : '' }}</span>
                                    </div>

                                    <input
                                        v-model="buscasGrupo[grupo.chave]"
                                        class="fz-filtros-catalogo__busca-grupo"
                                        type="search"
                                        placeholder="Pesquisar neste grupo"
                                        :aria-label="'Pesquisar em ' + grupo.nome"
                                    >

                                    <div v-if="grupo.variacoesVisiveis.length > 0" class="fz-filtros-catalogo__opcoes">
                                        <button
                                            v-for="variacao in grupo.variacoesVisiveis"
                                            :key="variacao.id"
                                            type="button"
                                            class="fz-filtros-catalogo__opcao"
                                            :class="{ 'is-selecionada': variacaoSelecionada(variacao.id) }"
                                            :aria-pressed="variacaoSelecionada(variacao.id)"
                                            @click="alternarVariacao(variacao.id)"
                                        >
                                            <span class="fz-filtros-catalogo__opcao-esquerda">
                                                <span class="fz-filtros-catalogo__check"><i class="pi pi-check" aria-hidden="true"></i></span>
                                                <span class="fz-filtros-catalogo__opcao-texto">
                                                    <strong>{{ variacao.nome }}</strong>
                                                    <span>{{ textoDisponibilidade(variacao.totalProdutos) }}</span>
                                                </span>
                                            </span>
                                            <span class="fz-filtros-catalogo__quantidade-opcao">{{ variacao.totalProdutos }} {{ variacao.totalProdutos === 1 ? 'produto' : 'produtos' }}</span>
                                        </button>
                                    </div>
                                    <p v-else class="fz-filtros-catalogo__vazio fz-filtros-catalogo__vazio--grupo">Nenhuma variação encontrada neste grupo.</p>
                                </section>
                            </template>
                            <p v-else class="fz-filtros-catalogo__vazio">Nenhuma variação encontrada.</p>
                        </main>

                        <footer v-if="exibirRodape" class="fz-filtros-catalogo__rodape">
                            <button type="button" class="fz-filtros-catalogo__botao-rodape fz-filtros-catalogo__botao-rodape--limpar" @click="limpar">Limpar</button>
                            <button type="button" class="fz-filtros-catalogo__botao-rodape fz-filtros-catalogo__botao-rodape--aplicar" @click="aplicar">Aplicar filtros</button>
                        </footer>
                    </section>
                </template>
            </p-drawer>
        </div>
    `},(function(){var runtime=window.FZCatalogoRuntime&&window.FZCatalogoRuntime.filtrosCatalogo||{},root=document.getElementById("catalogo-filtros-app");if(!(!root||window.FZCatalogoFiltrosAppInstance||typeof Vue=="undefined"||typeof PrimeVue=="undefined")){var app=Vue.createApp({components:{"fz-filtros-catalogo":FZComponents.FiltrosCatalogo},data:function(){return{runtime}},template:`
            <fz-filtros-catalogo
                :grupos="runtime.grupos || []"
                :variacoes-ativas="runtime.variacoesAtivas || []"
                :mostrar-categorias="Boolean(runtime.mostrarCategorias)"
            ></fz-filtros-catalogo>
        `}),configuracaoPrimeVue={theme:{options:{darkModeSelector:!1}}};typeof lojaPreset!="undefined"&&(configuracaoPrimeVue.theme.preset=lojaPreset),app.use(PrimeVue.Config,configuracaoPrimeVue),window.FZCatalogoFiltrosAppInstance=app.mount(root),window.FacilZapFiltrosCatalogo={abrir:function(){window.FZCatalogoFiltrosAppInstance.abrir()},fechar:function(){window.FZCatalogoFiltrosAppInstance.fechar()}}}})();

if(typeof FZComponents=="undefined")var FZComponents={};FZComponents.CarrosselCategorias={components:{"fz-titulo-secao":FZComponents.TituloSecao},props:{titulo:String,corTitulo:String,margemSuperior:Number,margemInferior:Number,estilo:{type:String,default:"circulos",validator:value=>["circulos","arredondado","quadrado"].includes(value)},tamanho:{type:String,default:"medio",validator:value=>["pequeno","medio","grande"].includes(value)},bordas:{type:Boolean,default:!0}},inject:["categoriasAtivasCatalogo","baseUrlCatalogo"],data(){return{swiperInstance:null,componentId:"carrossel-categorias-"+Math.random().toString(36).substr(2,9)}},computed:{estiloMargens(){var _a,_b;const margemSup=(_a=this.margemSuperior)!=null?_a:20,margemInf=(_b=this.margemInferior)!=null?_b:20;return`margin-top: ${margemSup}px; margin-bottom: ${margemInf}px;`},categorias(){return(this.categoriasAtivasCatalogo||[]).filter(categoria=>categoria.id)},classeEstilo(){return`estilo-${this.estilo}`},classeTamanho(){return`tamanho-${this.tamanho}`},classeBordas(){return this.bordas?"com-bordas":"sem-bordas"},swiperConfig(){const configMedio={desktop:{base:8.5,breakpoint1400:8.5,breakpoint1200:7.5},tablet:{breakpoint992:5.5,breakpoint768:5.5},mobile:{breakpoint480:4.5,breakpoint320:3.5}};let fator=1;this.tamanho==="pequeno"?fator=96/72:this.tamanho==="grande"&&(fator=96/150);const aplicarFator=valor=>Math.floor(valor*fator)+.5;return{slidesPerView:aplicarFator(configMedio.desktop.base),spaceBetween:5,breakpoints:{320:{slidesPerView:aplicarFator(configMedio.mobile.breakpoint320),spaceBetween:3},480:{slidesPerView:aplicarFator(configMedio.mobile.breakpoint480),spaceBetween:3},768:{slidesPerView:aplicarFator(configMedio.tablet.breakpoint768),spaceBetween:3},992:{slidesPerView:aplicarFator(configMedio.tablet.breakpoint992),spaceBetween:3},1200:{slidesPerView:aplicarFator(configMedio.desktop.breakpoint1200),spaceBetween:5},1400:{slidesPerView:aplicarFator(configMedio.desktop.breakpoint1400),spaceBetween:5}}}}},mounted(){this.$nextTick(()=>{this.initSwiper()})},beforeUnmount(){this.swiperInstance&&this.swiperInstance.destroy(!0,!0)},methods:{getInicialCategoria(nome){return nome?nome.charAt(0).toUpperCase():"?"},getLinkCategoria(categoria){return this.baseUrlCatalogo.replace("{PATH}","categoria/"+categoria.id)},initSwiper(){if(typeof Swiper!="undefined"&&this.categorias.length>0){const config=this.swiperConfig;this.swiperInstance=new Swiper(`#${this.componentId}`,{slidesPerView:config.slidesPerView,spaceBetween:config.spaceBetween,touchAngle:20,centeredSlides:!1,centerInsufficientSlides:!0,watchSlidesProgress:!0,autoplay:{delay:3500,disableOnInteraction:!0},pagination:{el:`#${this.componentId} .swiper-pagination`,clickable:!0},navigation:{nextEl:`#${this.componentId} .swiper-button-next`,prevEl:`#${this.componentId} .swiper-button-prev`},breakpoints:config.breakpoints})}}},template:`
    <div class="fz-carrossel-categorias" :style="estiloMargens">
        <fz-titulo-secao :titulo="titulo" :cor="corTitulo"></fz-titulo-secao>
        <div class="container-fluid">
            <div class="swiper" :id="componentId">
                <div class="swiper-wrapper">
                    <div 
                        v-for="categoria in categorias" 
                        :key="categoria.id" 
                        class="swiper-slide">
                        <a :href="getLinkCategoria(categoria)" class="categoria-item link-categoria" :data-categoria-id="categoria.id" :data-categoria-nome="categoria.nome">
                            <div 
                                class="categoria-circulo"
                                :class="[classeEstilo, classeTamanho, classeBordas]"
                                :style="categoria.imagem ? { backgroundImage: 'url(' + categoria.imagem + ')' } : {}">
                                <span v-if="!categoria.imagem" class="categoria-inicial">
                                    {{ getInicialCategoria(categoria.nome) }}
                                </span>
                            </div>
                            <div class="categoria-nome">{{ categoria.nome }}</div>
                        </a>
                    </div>
                </div>
                <div class="swiper-pagination d-block d-lg-none"></div>
                <div class="swiper-button-prev fz-seta-slider small d-none d-lg-flex"></div>
                <div class="swiper-button-next fz-seta-slider small d-none d-lg-flex"></div>
            </div>
        </div>
    </div>
    `};

if(typeof FZComponents=="undefined")var FZComponents={};(function(){if(typeof Vue=="undefined"||typeof PrimeVue=="undefined")return;var BrindesDisponiveisStore=window.FZBrindesDisponiveisStore||Vue.reactive({visivel:!1,estadoCarrinho:null});window.FZBrindesDisponiveisStore=BrindesDisponiveisStore,FZComponents.BrindesDisponiveis={components:{"p-drawer":PrimeVue.Drawer},data:function(){return{store:BrindesDisponiveisStore,dados:window.FZBrindesDisponiveisDados||{},ehMobile:!1}},computed:{dialogVisivel:{get:function(){return this.store.visivel},set:function(valor){this.store.visivel=!!valor}},tipoRegra:function(){return this.dados.tipoRegraEtapas==="qtd_itens"?"qtd_itens":"valor_pedido"},acumularBrindes:function(){return this.dados.acumular===!0},valorAtual:function(){var _a;var estado=this.store.estadoCarrinho||{};return this.tipoRegra==="qtd_itens"?Math.max(0,Number(estado.itens)||0):Math.max(0,Number((_a=estado.resumo)==null?void 0:_a.subtotal)||0)},posicaoDrawer:function(){return this.ehMobile?"bottom":"right"},estiloDrawer:function(){return this.ehMobile?{width:"100vw",height:"88dvh"}:{width:"min(560px, 95vw)"}},etapas:function(){var etapas=Array.isArray(this.dados.etapas)?this.dados.etapas:[],indiceMaiorEtapaAtingida=-1,valorAtual=this.valorAtual;etapas.forEach(function(etapa,indice){var meta=Math.max(0,Number(etapa.valor)||0);valorAtual>=meta&&(indiceMaiorEtapaAtingida=indice)});var indiceProximaEtapa=indiceMaiorEtapaAtingida+1;return etapas.map(function(etapa,indice){var meta=Math.max(0,Number(etapa.valor)||0),atingida=valorAtual>=meta,conquistada=atingida&&(this.acumularBrindes||indice===indiceMaiorEtapaAtingida),restante=Math.max(0,meta-valorAtual),percentual=meta>0?Math.min(100,valorAtual/meta*100):100,status=conquistada?"conquistado":atingida?"superado":"em-andamento";return Object.assign({},etapa,{indice:indice+1,meta,atingida,conquistada,restante,percentual,status,proximaEtapa:indice===indiceProximaEtapa})},this)}},watch:{dialogVisivel:function(visivel){visivel&&this.atualizarEstadoCarrinho()}},mounted:function(){this.atualizarViewport(),this.receberAtualizacaoCarrinho=this.receberAtualizacaoCarrinho.bind(this),this.atualizarViewport=this.atualizarViewport.bind(this),window.addEventListener("fz-carrinho-atualizado",this.receberAtualizacaoCarrinho),window.addEventListener("resize",this.atualizarViewport,{passive:!0}),window.FZCarrinhoDrawerStore&&window.FZCarrinhoDrawerStore.estado&&(this.store.estadoCarrinho=window.FZCarrinhoDrawerStore.estado)},beforeUnmount:function(){window.removeEventListener("fz-carrinho-atualizado",this.receberAtualizacaoCarrinho),window.removeEventListener("resize",this.atualizarViewport)},methods:{atualizarViewport:function(){this.ehMobile=window.matchMedia("(max-width: 760px)").matches},receberAtualizacaoCarrinho:function(evento){evento.detail&&typeof evento.detail=="object"&&(this.store.estadoCarrinho=evento.detail)},atualizarEstadoCarrinho:function(){window.FZCarrinhoDrawerStore&&window.FZCarrinhoDrawerStore.estado&&(this.store.estadoCarrinho=window.FZCarrinhoDrawerStore.estado),typeof window.totalCarrinho=="function"&&window.totalCarrinho()},abrir:function(){this.dialogVisivel=!0},fechar:function(){this.dialogVisivel=!1},formatarMoeda:function(valor){return new Intl.NumberFormat("pt-BR",{style:"currency",currency:"BRL"}).format(Number(valor)||0)},formatarQuantidade:function(valor){return new Intl.NumberFormat("pt-BR",{maximumFractionDigits:2}).format(Number(valor)||0)},formatarMeta:function(valor){return this.tipoRegra==="qtd_itens"?this.formatarQuantidade(valor)+" "+(Number(valor)===1?"item":"itens"):this.formatarMoeda(valor)},tituloEtapa:function(etapa){return etapa.meta<=0?this.tipoRegra==="qtd_itens"?"Compras sem quantidade mínima":"Compras sem valor mínimo":"Compras acima de "+this.formatarMeta(etapa.meta)},subtituloEtapa:function(etapa){return etapa.conquistada?"Você já atingiu o valor mínimo desta etapa.":etapa.atingida?"Você atingiu uma etapa superior da campanha.":"Você desbloqueia este brinde ao atingir o valor."},rotuloStatus:function(etapa){return etapa.conquistada?"Brinde conquistado":etapa.atingida?"Meta superada":etapa.proximaEtapa?etapa.percentual>=60?"Falta pouco":"Próximo brinde":"Continue comprando"},descricaoBrinde:function(brinde){return brinde.descricao||""},textoProgresso:function(etapa){return this.formatarMeta(this.valorAtual)+" / "+this.formatarMeta(etapa.meta)},textoRestante:function(etapa){return this.tipoRegra==="qtd_itens"?this.formatarQuantidade(etapa.restante)+" "+(etapa.restante===1?"item":"itens"):this.formatarMoeda(etapa.restante)},textoBrindes:function(etapa){return(etapa.brindes||[]).length===1?"este brinde":"estes brindes"}},template:`
            <p-drawer
                v-model:visible="dialogVisivel"
                :position="posicaoDrawer"
                :style="estiloDrawer"
                :base-z-index="1000003"
                :dismissable="true"
                :closable="false"
                :block-scroll="true"
                modal
                class="fz-brindes-drawer"
            >
                <template #container>
                    <aside class="fz-brindes-drawer__container" aria-labelledby="fz-brindes-titulo">
                        <div class="fz-brindes-drawer__handle" aria-hidden="true"></div>

                        <header class="fz-brindes-drawer__cabecalho">
                            <div class="fz-brindes-drawer__titulo">
                                <span class="fz-brindes-drawer__icone"><i class="pi pi-gift" aria-hidden="true"></i></span>
                                <div>
                                    <h2 id="fz-brindes-titulo">Brindes disponíveis</h2>
                                    <p>Ganhe brindes conforme a sua compra.</p>
                                </div>
                            </div>
                            <button class="fz-brindes-drawer__fechar" type="button" aria-label="Fechar brindes disponíveis" @click="fechar">
                                <i class="pi pi-times" aria-hidden="true"></i>
                            </button>
                        </header>

                        <main class="fz-brindes-drawer__lista">
                            <article
                                v-for="etapa in etapas"
                                :key="etapa.indice"
                                class="fz-brindes-etapa"
                                :class="'fz-brindes-etapa--' + etapa.status"
                            >
                                <div class="fz-brindes-etapa__topo">
                                    <div class="fz-brindes-etapa__meta">
                                        <span class="fz-brindes-etapa__indice">{{ etapa.indice }}</span>
                                        <div>
                                            <strong>{{ tituloEtapa(etapa) }}</strong>
                                            <small>{{ subtituloEtapa(etapa) }}</small>
                                        </div>
                                    </div>
                                    <span class="fz-brindes-etapa__status">{{ rotuloStatus(etapa) }}</span>
                                </div>

                                <div class="fz-brindes-etapa__produtos">
                                    <article v-for="brinde in etapa.brindes || []" :key="brinde.id" class="fz-brindes-produto">
                                        <div class="fz-brindes-produto__imagem" :class="{ 'is-empty': !brinde.imagem }">
                                            <img v-if="brinde.imagem" :src="brinde.imagem" :alt="brinde.nome" @error="brinde.imagem = ''">
                                            <i v-else class="pi pi-image" aria-hidden="true"></i>
                                        </div>
                                        <div class="fz-brindes-produto__conteudo">
                                            <h3>{{ brinde.nome }}</h3>
                                            <p>{{ descricaoBrinde(brinde) }}</p>
                                        </div>
                                    </article>
                                </div>

                                <section class="fz-brindes-progresso" :class="{ 'is-conquistado': etapa.conquistada, 'is-superado': etapa.atingida && !etapa.conquistada }">
                                    <div class="fz-brindes-progresso__cabecalho">
                                        <strong>Seu progresso</strong>
                                        <span>{{ textoProgresso(etapa) }}</span>
                                    </div>
                                    <div class="fz-brindes-progresso__barra" role="progressbar" :aria-valuenow="Math.round(etapa.percentual)" aria-valuemin="0" aria-valuemax="100">
                                        <span :style="{ width: etapa.percentual + '%' }"></span>
                                    </div>
                                    <p v-if="etapa.conquistada" class="fz-brindes-progresso__nota fz-brindes-progresso__nota--conquistado">
                                        <i class="pi pi-check" aria-hidden="true"></i> Você ganhou {{ textoBrindes(etapa) }}!
                                    </p>
                                    <p v-else-if="etapa.atingida" class="fz-brindes-progresso__nota">
                                        Você receberá os brindes da maior etapa atingida.
                                    </p>
                                    <p v-else class="fz-brindes-progresso__nota">
                                        Faltam <b>{{ textoRestante(etapa) }}</b> para ganhar {{ textoBrindes(etapa) }}.
                                    </p>
                                </section>
                            </article>
                        </main>

                        <footer class="fz-brindes-drawer__rodape">
                            <p><i class="pi pi-shield" aria-hidden="true"></i><span>Os brindes são definidos pela loja e podem variar conforme disponibilidade, valor do pedido e regras da campanha.</span></p>
                        </footer>
                    </aside>
                </template>
            </p-drawer>
        `},window.FacilZapBrindes={abrir:function(){BrindesDisponiveisStore.visivel=!0},fechar:function(){BrindesDisponiveisStore.visivel=!1}};function montar(){var elemento=document.getElementById("brindes-disponiveis-app");if(!(!elemento||window.FZBrindesDisponiveisAppInstance)){var app=Vue.createApp({components:{"fz-brindes-disponiveis":FZComponents.BrindesDisponiveis}});app.use(PrimeVue.Config,{theme:{preset:typeof lojaPreset!="undefined"?lojaPreset:PrimeVue.Themes.FacilZap,options:{darkModeSelector:!1}}}),window.FZBrindesDisponiveisAppInstance=app.mount("#brindes-disponiveis-app")}}if(document.readyState==="loading"){document.addEventListener("DOMContentLoaded",montar,{once:!0});return}montar()})();

if(typeof FZComponents=="undefined")var FZComponents={};const SimuladorParcelasStore=Vue.reactive({visible:!1,produto:null});FZComponents.DialogSimuladorParcelas={components:{"p-dialog":PrimeVue.Dialog,"p-message":PrimeVue.Message,"p-tabs":PrimeVue.Tabs,"p-tablist":PrimeVue.TabList,"p-tab":PrimeVue.Tab,"p-tabpanels":PrimeVue.TabPanels,"p-tabpanel":PrimeVue.TabPanel,"p-datatable":PrimeVue.DataTable,"p-column":PrimeVue.Column},inject:["configsLoja"],data(){return{store:SimuladorParcelasStore}},computed:{visible:{get(){return this.store.visible},set(value){this.store.visible=value,value||setTimeout(()=>{this.store.produto=null},300)}},produto(){return this.store.produto},simulacao(){var _a;return(_a=this.produto)==null?void 0:_a.simulacao_parcelas},temSimulacao(){return this.simulacao&&this.simulacao.exibir_simulador},formasPagamento(){var _a;return(_a=this.simulacao)!=null&&_a.formas_pagamento?Object.entries(this.simulacao.formas_pagamento).map(([id,forma])=>{var _a2,_b;return{id,nome:((_a2=forma.info)==null?void 0:_a2.nome)||id,icone:((_b=forma.info)==null?void 0:_b.icone)||null,dados:forma}}).sort((a,b)=>{const aIsNumeric=/^\d+$/.test(a.id),bIsNumeric=/^\d+$/.test(b.id);return aIsNumeric&&!bIsNumeric?1:!aIsNumeric&&bIsNumeric?-1:0}):[]},integracoesInformativas(){var _a;return(_a=this.simulacao)!=null&&_a.integracoes_informativas?Object.entries(this.simulacao.integracoes_informativas).map(([id,info])=>({id,nome:(info==null?void 0:info.nome)||id,icone:(info==null?void 0:info.icone)||null})):[]},temIntegracoesInformativas(){return this.integracoesInformativas.length>0}},methods:{formatarPreco(valor){if(!valor)return"0,00";const num=parseFloat(valor);return isNaN(num)?"0,00":num.toFixed(2).replace(".",",")},obterURLAssets(arquivo){return`${(window.FZCatalogoRuntime&&window.FZCatalogoRuntime.assetsBaseUrl||"https://assets.facilzap.app.br").replace(/\/$/,"")}/${arquivo}`},temMetodo(forma,metodo){return forma.dados[metodo]!==void 0},fecharDialog(){this.visible=!1}},template:`
    <p-dialog
        v-model:visible="visible"
        modal
        :draggable="false"
        :dismissableMask="true"
        header="Formas de Pagamento"
        :base-z-index="20000"
        :style="{ width: '90vw', maxWidth: '700px' }"
        class="fz-dialog-simulador-parcelas"
        :pt="{header: 'pb-2', content: 'pt-0'}"
    >
        <div v-if="!temSimulacao" class="fz-dialog-simulador-parcelas__sem-dados p-4 text-center">
            <p-message severity="info" :closable="false">
                Não há informações de parcelamento disponíveis para este produto.
            </p-message>
        </div>
        
        <div v-if="temSimulacao"  class="fz-dialog-simulador-parcelas__aviso px-3 mb-1">
            <p-message size="small" severity="warn" icon="pi pi-exclamation-triangle" :closable="false">
               Os valores abaixo são uma simulação das condições de pagamento ofertadas pela loja, 
                podendo haver variação no momento da finalização do pedido devido ao valor total da compra e o valor do frete.
            </p-message>
        </div>
        
        <div v-if="temSimulacao" class="fz-dialog-simulador-parcelas__conteudo">
            <p-tabs v-if="formasPagamento.length > 0 || temIntegracoesInformativas" value="0" scrollable>
                <p-tablist>
                    <p-tab v-for="(forma, index) in formasPagamento" :key="forma.id" :value="String(index)">
                        <div class="d-flex align-items-center gap-2">
                            <img
                                v-if="forma.icone"
                                :src="obterURLAssets(forma.icone)"
                                loading="lazy"
                                style="max-height: 20px;"
                                :alt="forma.nome"
                            />
                            <span v-else>{{ forma.nome }}</span>
                        </div>
                    </p-tab>
                    <p-tab
                        v-for="(info, index) in integracoesInformativas"
                        :key="'info-' + info.id"
                        :value="String(formasPagamento.length + index)"
                    >
                        <div class="d-flex align-items-center gap-2">
                            <img
                                v-if="info.icone"
                                :src="obterURLAssets(info.icone)"
                                loading="lazy"
                                style="max-height: 20px;"
                                :alt="info.nome"
                            />
                            <span v-else>{{ info.nome }}</span>
                        </div>
                    </p-tab>
                </p-tablist>
                <p-tabpanels>
                    <p-tabpanel v-for="(forma, index) in formasPagamento" :key="forma.id" :value="String(index)">
                    
                    <!-- Conteúdo da aba PIX (standalone) -->
                    <div v-if="forma.id === 'pix'" class="fz-dialog-simulador-parcelas__pix">
                        <p class="fz-dialog-simulador-parcelas__pix-valor f-16 mb-2">
                            <img 
                                :src="obterURLAssets('logo-pix-64.png')" 
                                loading="lazy" 
                                style="width:34px" 
                                alt="PIX" 
                            />
                            <s v-if="forma.dados.desconto > 0">
                                R$ {{ formatarPreco(forma.dados.preco) }}
                            </s>
                            <b>R$ {{ formatarPreco(forma.dados.preco_final) }}</b> no <b>PIX</b>
                            <span v-if="forma.dados.desconto > 0">
                                com <b>{{ formatarPreco(forma.dados.desconto_porcentagem) }}%</b> de desconto
                            </span>
                        </p>
                    </div>

                    <!-- Conteúdo da aba NowPayments (Criptomoedas) -->
                    <div v-else-if="forma.id === 'nowpayments'" class="fz-dialog-simulador-parcelas__forma">
                        <div class="fz-dialog-simulador-parcelas__crypto">
                            <p class="font-weight-bold f-16 mb-2">Criptomoedas Aceitas</p>
                            <div v-if="forma.dados.moedas && forma.dados.moedas.length > 0" class="fz-dialog-simulador-parcelas__moedas d-flex gap-3 flex-wrap">
                                <div v-for="moeda in forma.dados.moedas" :key="moeda.id" class="fz-dialog-simulador-parcelas__moeda d-flex align-items-center gap-2">
                                    <img v-if="moeda.imagem" :src="moeda.imagem" loading="lazy" style="width:28px" :alt="moeda.nome" />
                                    <span>{{ moeda.nome }}</span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Conteúdo de outras formas de pagamento -->
                    <div v-else class="fz-dialog-simulador-parcelas__forma">
                        <!-- Cartão de Crédito -->
                        <div v-if="temMetodo(forma, 'cartao_credito')" class="fz-dialog-simulador-parcelas__cartao mb-4">
                            <p class="font-weight-bold f-16 mb-2">
                                <img 
                                    :src="obterURLAssets('logo-cartao-64.png')" 
                                    loading="lazy" 
                                    style="width:34px" 
                                    alt="Cartão de Crédito" 
                                /> 
                                Cartão de Crédito
                            </p>
                            
                            <p-datatable 
                                :value="forma.dados.cartao_credito.parcelas"
                                striped
                                size="small"
                                class="fz-dialog-simulador-parcelas__tabela"
                            >
                                <p-column field="parcela" header="Parcelas">
                                    <template #body="slotProps">
                                        <b>{{ slotProps.data.parcela }}x</b> de 
                                        <b>R$ {{ formatarPreco(slotProps.data.valor_parcela) }}</b>
                                    </template>
                                </p-column>
                                <p-column field="total" header="Total" class="text-right">
                                    <template #body="slotProps">
                                        R$ {{ formatarPreco(slotProps.data.total) }}
                                    </template>
                                </p-column>
                            </p-datatable>
                        </div>
                        
                        <!-- Forma Manual -->
                        <div v-if="temMetodo(forma, 'manual')" class="fz-dialog-simulador-parcelas__manual mb-4">
                            <p-datatable 
                                :value="forma.dados.manual.parcelas"
                                striped
                                size="small"
                                class="fz-dialog-simulador-parcelas__tabela"
                            >
                                <p-column field="parcela" header="Parcelas">
                                    <template #body="slotProps">
                                        <b>{{ slotProps.data.parcela }}x</b> de 
                                        <b>R$ {{ formatarPreco(slotProps.data.valor_parcela) }}</b>
                                    </template>
                                </p-column>
                                <p-column field="total" header="Total" class="text-right">
                                    <template #body="slotProps">
                                        R$ {{ formatarPreco(slotProps.data.total) }}
                                    </template>
                                </p-column>
                            </p-datatable>
                        </div>
                        
                        <!-- PIX (dentro de outra forma) -->
                        <div v-if="temMetodo(forma, 'pix')" class="fz-dialog-simulador-parcelas__pix-opcional mb-4">
                            <p class="f-16 mb-0">
                                <img 
                                    :src="obterURLAssets('logo-pix-64.png')" 
                                    loading="lazy" 
                                    style="width:34px" 
                                    alt="PIX" 
                                />
                                <s v-if="forma.dados.pix.desconto > 0">
                                    R$ {{ formatarPreco(forma.dados.pix.preco) }}
                                </s>
                                <b>R$ {{ formatarPreco(forma.dados.pix.preco_final) }}</b> no <b>PIX</b>
                                <span v-if="forma.dados.pix.desconto > 0">
                                    com <b>{{ formatarPreco(forma.dados.pix.desconto_porcentagem) }}%</b> de desconto
                                </span>
                            </p>
                        </div>
                        
                        <!-- Boleto -->
                        <div v-if="temMetodo(forma, 'boleto')" class="fz-dialog-simulador-parcelas__boleto mb-4">
                            <p class="f-16 mb-0">
                                <img 
                                    :src="obterURLAssets('logo-boleto-86.png')" 
                                    loading="lazy" 
                                    style="width:34px" 
                                    alt="Boleto" 
                                />
                                <s v-if="forma.dados.boleto.desconto > 0">
                                    R$ {{ formatarPreco(forma.dados.boleto.preco) }}
                                </s>
                                <b>R$ {{ formatarPreco(forma.dados.boleto.preco_final) }}</b> no <b>Boleto</b>
                                <span v-if="forma.dados.boleto.desconto > 0">
                                    com <b>{{ formatarPreco(forma.dados.boleto.desconto_porcentagem) }}%</b> de desconto
                                </span>
                            </p>
                        </div>
                    </div>
                    </p-tabpanel>
                </p-tabpanels>
            </p-tabs>
        </div>
    </p-dialog>
    `};

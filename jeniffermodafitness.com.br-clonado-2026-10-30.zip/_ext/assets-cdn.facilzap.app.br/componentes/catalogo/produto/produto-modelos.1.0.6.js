FZComponents.ProdutoConteudoModelo1={components:{"p-message":PrimeVue.Message,"fz-produto-modal-skeleton":FZComponents.ProdutoModalSkeleton,"fz-produto-modal-skeleton-detalhes":FZComponents.ProdutoModalSkeletonDetalhes,"fz-produto-modal-carousel":FZComponents.ProdutoModalCarousel,"fz-produto-modal-header":FZComponents.ProdutoModalHeader,"fz-produto-modal-audio-descricao":FZComponents.ProdutoModalAudioDescricao,"fz-variacao-sem-variacao":FZComponents.VariacaoSemVariacao,"fz-variacao-com-variacao":FZComponents.VariacaoComVariacao,"fz-variacao-com-subgrupos-variacao":FZComponents.VariacaoComSubgruposVariacao,"fz-variacao-com-grade":FZComponents.VariacaoComGrade,"fz-variacao-grade-com-abas":FZComponents.VariacaoGradeComAbas,"fz-produto-modal-footer":FZComponents.ProdutoModalFooter,"fz-produto-modal-descricao":FZComponents.ProdutoModalDescricao,"fz-produto-modal-guia-medidas":FZComponents.ProdutoModalGuiaMedidas,"fz-produto-modal-widgets":FZComponents.ProdutoModalWidgets,"fz-produto-modal-produtos-relacionados":FZComponents.ProdutoModalProdutosRelacionados,"fz-produto-modal-comentarios":FZComponents.ProdutoModalComentarios,"fz-produto-modal-avise-me-form":FZComponents.ProdutoModalAviseMeForm,"fz-produto-modal-simulador-frete":FZComponents.ProdutoModalSimuladorFrete,"fz-produto-cupons":FZComponents.ProdutoCupons,"fz-produto-kit-componentes":FZComponents.ProdutoKitComponentes,"fz-dialog-regras-precos":FZComponents.DialogRegrasPrecos,"fz-dialog-video-externo":FZComponents.DialogVideoExterno,"fz-produto-preco":FZComponents.ProdutoPreco,"fz-simulador-parcelas-melhor-parcelamento":FZComponents.SimuladorParcelasMelhorParcelamento,"fz-simulador-frete-formulario":FZComponents.SimuladorFreteFormulario,"fz-produto-acoes":FZComponents.ProdutoAcoes,"fz-produto-avaliacoes":FZComponents.ProdutoAvaliacoes},mixins:[ProdutoConteudoMixin],props:{produtoInicial:{type:Object,required:!0},carregarDadosCompletos:{type:Boolean,default:!0},contexto:{type:String,default:"dialog-drawer",validator:value=>["dialog-drawer","pagina"].includes(value)}},emits:["produto-carregado","erro-carregamento","estatistica-enviada","voltar"],data(){return{store:ProdutoConteudoStore,tabAtivaSubgrupos:null}},computed:{produto(){return this.store.dadosCompletos||this.produtoInicial},produtoSomenteId(){const produto=this.produtoInicial;if(!produto)return!1;const keys=Object.keys(produto);return keys.length===1&&keys[0]==="id"},carregandoDados(){return this.store.carregando&&!this.store.dadosCompletos},dadosCompletos(){return!!this.store.dadosCompletos},produtoIndisponivelEstoque(){return this.produto?this.produto.controlar_estoque!="1"?!1:this.produto.total_estoque<=0?!0:!!this.produto.grade_quebrada&&!this.produto.grade_permitir_individual:!0},exibirAviseMeForm(){return this.produtoIndisponivelEstoque&&this.configsLoja.habilitarAviseMeQuandoChegar}},watch:{produtoInicial:{handler(newProduto,oldProduto){newProduto&&newProduto.id&&(!oldProduto||newProduto.id!==oldProduto.id)&&this.inicializarProduto()},immediate:!0},"store.dadosCompletos"(newValue,oldValue){var _a;newValue===null&&oldValue!==null&&((_a=this.produtoInicial)!=null&&_a.id)&&this.inicializarProduto()}},mounted(){this.hidratarKitSelecoesStore(),AudioManager.init(this.configsLoja)},methods:{async inicializarProduto(){var _a;if(!((_a=this.produtoInicial)!=null&&_a.id))return;const produtoId=this.produtoInicial.id;if(this.store.produtoId=produtoId,this.store.produtoInicial=this.produtoInicial,this.store.tempoAberto=Date.now(),this.store.estatisticaEnviada=!1,typeof facilZapEventos!="undefined"&&facilZapEventos.verProduto&&facilZapEventos.verProduto(produtoId,this.produtoInicial.nome,this.produtoInicial.preco),this.store.cacheProdutos[produtoId])this.store.dadosCompletos=this.store.cacheProdutos[produtoId],this.$emit("produto-carregado",this.store.dadosCompletos);else{const keys=Object.keys(this.produtoInicial);keys.length===1&&keys[0]==="id"?await this.carregarDadosCompletosAPI():(this.store.dadosCompletos=this.produtoInicial,this.store.cacheProdutos[produtoId]=this.produtoInicial,this.$emit("produto-carregado",this.produtoInicial))}setTimeout(()=>{this.enviarEstatistica()},2e3)},async carregarDadosCompletosAPI(){var _a;if(!((_a=this.produtoInicial)!=null&&_a.id))return;const produtoId=this.produtoInicial.id;if(this.store.cacheProdutos[produtoId]){this.store.dadosCompletos=this.store.cacheProdutos[produtoId],this.$emit("produto-carregado",this.store.dadosCompletos);return}this.store.carregando=!0,this.store.erro=null;try{const url=this.obterLinkCatalogo(`produto/${produtoId}`)+"?ajax=ajax",response=await fetch(url);if(!response.ok)throw new Error("Erro ao carregar produto");const data=await response.json();this.store.cacheProdutos[produtoId]=data,this.store.dadosCompletos=data,this.$emit("produto-carregado",data)}catch(error){console.error("Erro ao carregar dados do produto:",error),this.store.erro="Erro ao carregar informações do produto",this.$emit("erro-carregamento",error)}finally{this.store.carregando=!1}},async enviarEstatistica(){var _a;if(this.store.estatisticaEnviada||!((_a=this.produto)!=null&&_a.id)||Date.now()-this.store.tempoAberto<2e3)return;const produtoId=Number(this.produto.id);if(this.store.estatisticasEnviadas.has(produtoId)){this.store.estatisticaEnviada=!0;return}try{const url=this.obterLinkCatalogo(`produto/${produtoId}`)+"?estatisticas&ajax=ajax";await fetch(url),this.store.estatisticasEnviadas.add(produtoId),this.store.estatisticaEnviada=!0,this.$emit("estatistica-enviada",produtoId)}catch(error){console.error("Erro ao enviar estatística:",error)}},handleVoltar(){this.$emit("voltar")},handleSlideChange(payload){var _a;if(payload.tipo==="video"||!payload.imagem||!((_a=this.produto)!=null&&_a.subgrupos_variacoes)||this.isEmpty(this.produto.subgrupos_variacoes))return;const imagensVariacoes=this.produto.imagens_variacoes||{},variacaoIdsDaFoto=Object.entries(imagensVariacoes).filter(([,caminho])=>caminho===payload.imagem).map(([id])=>String(id));if(variacaoIdsDaFoto.length===0)return;let indiceDisponivel=0;for(const[nomeSubgrupo,variacoes]of Object.entries(this.produto.subgrupos_variacoes)){if(!variacoes.some(v=>{var _a2,_b;if(((_a2=this.produto.disponibilidade)==null?void 0:_a2[v.id])!="1")return!1;const estoque=parseInt((_b=this.produto.estoque)==null?void 0:_b[v.id])||0,qtdMinima=this.obterQtdMinimaVariacao(v.id,this.produto,this.configsLoja.catalogoId);return!(this.produto.controlar_estoque=="1"&&(estoque<=0||estoque<qtdMinima))}))continue;if(variacoes.some(v=>variacaoIdsDaFoto.includes(String(v.id)))){const novaTab=String(indiceDisponivel);this.tabAtivaSubgrupos=null,this.$nextTick(()=>{this.tabAtivaSubgrupos=novaTab});return}indiceDisponivel++}}},template:`
    <div class="fz-produto-conteudo">
        <!-- Error State -->
        <div v-if="store.erro" class="fz-produto-conteudo__erro p-4">
            <p-message severity="error" :closable="false">
                {{ store.erro }}
            </p-message>
        </div>

        <!-- Loading Skeleton - Full (when product has only ID) -->
        <div v-else-if="produtoSomenteId && carregandoDados" class="fz-produto-conteudo__container container-fluid p-4">
            <fz-produto-modal-skeleton></fz-produto-modal-skeleton>
        </div>

        <!-- Product Content -->
        <div v-else-if="produto" class="fz-produto-conteudo__container container-fluid p-4">
            <div class="row">
                <!-- Left Column - Images -->
                <div class="fz-produto-conteudo__coluna-esquerda col-12 col-lg-7 mb-4 mb-lg-0">
                    <fz-produto-modal-carousel
                        :produto="produto"
                        @slide-change="handleSlideChange"
                    ></fz-produto-modal-carousel>
                </div>

                <!-- Right Column - Details -->
                <div class="fz-produto-conteudo__coluna-direita col-12 col-lg-5">
                    <fz-produto-modal-header
                        :produto="produto"
                    ></fz-produto-modal-header>

                    <fz-produto-modal-audio-descricao
                        v-if="dadosCompletos && produto.audio_descricao"
                        :audio-path="produto.audio_descricao"
                        :produto-id="produto.id"
                        :vendedor-nome="configsLoja.vendedorNome || ''"
                        :vendedor-foto="configsLoja.vendedorFoto || ''"
                        :total-plays="produto.total_plays_audio || 0"
                    ></fz-produto-modal-audio-descricao>

                    <!-- Skeleton for data that needs complete fetch -->
                    <fz-produto-modal-skeleton-detalhes v-if="carregandoDados"></fz-produto-modal-skeleton-detalhes>

                    <!-- Complete data content -->
                    <div v-else class="fz-produto-conteudo__dados-completos">
                        <!-- Pricing & Simulator -->
                        <div v-if="!configsLoja.somenteOrcamentos && !configsLoja.precosRestritos" class="fz-produto-conteudo__preco-simulador py-2">
                            <div class="d-flex justify-content-between align-items-start flex-wrap" style="gap: 1rem;">
                                <div class="fz-produto-conteudo__preco flex-grow-0">
                                    <fz-produto-preco
                                        :produto="produto"
                                        :somente-orcamentos="configsLoja.somenteOrcamentos"
                                        :precos-restritos="configsLoja.precosRestritos"
                                        :pagina-live="false"
                                        :ativar-simulador-parcelas="configsLoja.ativarSimuladorParcelas"
                                        alinhamento="esquerda"
                                    ></fz-produto-preco>
                                </div>

                                <div v-if="configsLoja.ativarSimuladorParcelas && !produto.venda_externa" class="fz-produto-conteudo__simulador-parcelamento flex-shrink-0 text-right">
                                    <fz-simulador-parcelas-melhor-parcelamento
                                        :produto="produto"
                                        :simulacao="produto.simulacao_parcelas"
                                        :abrir-modal="true"
                                        alinhamento="modal"
                                    ></fz-simulador-parcelas-melhor-parcelamento>
                                </div>
                            </div>
                        </div>

                        <!-- Avise-me Form (if out of stock) -->
                        <div v-if="exibirAviseMeForm" class="fz-produto-conteudo__avise-me-container py-3">
                            <fz-produto-modal-avise-me-form
                                :produto="produto"
                            ></fz-produto-modal-avise-me-form>
                        </div>

                        <!-- Variations / Quantity (if in stock) -->
                        <div v-else-if="!produto.venda_externa && !configsLoja.precosRestritos" class="fz-produto-conteudo__variacoes-container">
                            <fz-produto-kit-componentes
                                v-if="produto.is_kit || produto.tipo_produto === 'kit'"
                                :produto="produto"
                            ></fz-produto-kit-componentes>

                            <!-- Venda em Grade (exclusiva ou híbrida com abas Grade|Individual) -->
                            <template v-if="produto.grade && !isEmpty(produto.grade) && produto.grade_permitir_individual && !produto.grade_quebrada">
                                <fz-variacao-grade-com-abas
                                    :produto="produto"
                                    :catalogo-id="configsLoja.catalogoId"
                                    :carrinho="configsLoja.carrinho || {}"
                                    :configs-loja="configsLoja"
                                    :somente-orcamentos="configsLoja.somenteOrcamentos"
                                    :precos-restritos="configsLoja.precosRestritos"
                                    :exibir-preco="true"
                                    :exibir-sku="true"
                                    :exibir-divisoria="true"
                                    :exibir-descontos="true"
                                    :video-ativo="!isEmpty(produto.video)"
                                    :variacoes-isoladas="false"
                                    :tab-ativa="tabAtivaSubgrupos"
                                    :variacoes-destaque="typeof variacoesDestaque !== 'undefined' ? variacoesDestaque : []"
                                ></fz-variacao-grade-com-abas>
                            </template>
                            <template v-else-if="produto.grade && !isEmpty(produto.grade) && !produto.grade_quebrada">
                                <fz-variacao-com-grade
                                    :produto="produto"
                                    :catalogo-id="configsLoja.catalogoId"
                                    :carrinho="configsLoja.carrinho || {}"
                                    :exibir-sku="true"
                                    :exibir-descontos="true"
                                    :video-ativo="!isEmpty(produto.video)"
                                    :variacoes-isoladas="false"
                                ></fz-variacao-com-grade>
                            </template>

                            <!-- Produto com subgrupos de variações -->
                            <template v-else-if="produto.subgrupos_variacoes && !isEmpty(produto.subgrupos_variacoes)">
                                <fz-variacao-com-subgrupos-variacao
                                    :produto="produto"
                                    :catalogo-id="configsLoja.catalogoId"
                                    :carrinho="configsLoja.carrinho || {}"
                                    :somente-orcamentos="configsLoja.somenteOrcamentos"
                                    :precos-restritos="configsLoja.precosRestritos"
                                    :exibir-preco="true"
                                    :exibir-sku="true"
                                    :exibir-divisoria="true"
                                    :exibir-descontos="true"
                                    :video-ativo="!isEmpty(produto.video)"
                                    :variacoes-isoladas="false"
                                    :tab-ativa="tabAtivaSubgrupos"
                                ></fz-variacao-com-subgrupos-variacao>
                            </template>

                            <!-- Produto com variações simples -->
                            <template v-else-if="produto.variacoes && !isEmpty(produto.variacoes)">
                                <fz-variacao-com-variacao
                                    :produto="produto"
                                    :catalogo-id="configsLoja.catalogoId"
                                    :carrinho="configsLoja.carrinho || {}"
                                    :somente-orcamentos="configsLoja.somenteOrcamentos"
                                    :precos-restritos="configsLoja.precosRestritos"
                                    :exibir-preco="true"
                                    :exibir-sku="true"
                                    :exibir-divisoria="true"
                                    :exibir-descontos="true"
                                    :video-ativo="!isEmpty(produto.video)"
                                ></fz-variacao-com-variacao>
                            </template>

                            <!-- Produto sem variações -->
                            <template v-else>
                                <fz-variacao-sem-variacao
                                    :produto="produto"
                                    :catalogo-id="configsLoja.catalogoId"
                                    :carrinho="configsLoja.carrinho || {}"
                                    :exibir-sku="true"
                                    :exibir-descontos="true"
                                ></fz-variacao-sem-variacao>
                            </template>
                        </div>

                        <!-- Simulators -->
                        <div v-if="!produtoIndisponivelEstoque" class="fz-produto-conteudo__simuladores">
                            <!-- Shipping Simulator -->
                            <fz-produto-modal-simulador-frete
                                v-if="configsLoja.habilitarSimuladorFreteProduto"
                                :produto="produto"
                            ></fz-produto-modal-simulador-frete>
                        </div>

                        <fz-produto-cupons
                            :cupons="configsLoja.cuponsDivulgaveis"
                            :produto="produto"
                        ></fz-produto-cupons>

                        <!-- Action Buttons Footer -->
                        <fz-produto-modal-footer
                            :contexto="contexto"
                            :produto="produto"
                        ></fz-produto-modal-footer>
                    </div>
                </div>
            </div>

            <!-- Additional Content Sections -->
            <div class="fz-produto-conteudo__secoes-adicionais row">
                <div class="col-12">
                    <fz-produto-modal-descricao
                        v-if="dadosCompletos && produto.descricao"
                        :descricao="produto.descricao"
                        :produto-id="produto.id"
                    ></fz-produto-modal-descricao>

                    <fz-produto-modal-guia-medidas
                        v-if="dadosCompletos && obterDescricaoGuiaMedidas(produto)"
                        :produto="produto"
                    ></fz-produto-modal-guia-medidas>

                    <fz-produto-modal-widgets
                        v-if="dadosCompletos && obterWidgetsProduto(produto).length"
                        :produto="produto"
                    ></fz-produto-modal-widgets>

                    <fz-produto-modal-produtos-relacionados
                        v-if="dadosCompletos && configsLoja.exibirProdutosRelacionadosTelaProduto"
                        :produto="produto"
                        :abrir-link-direto="contexto === 'pagina'"
                    ></fz-produto-modal-produtos-relacionados>

                    <fz-produto-modal-comentarios
                        v-if="dadosCompletos && configsLoja.exibirComentariosTelaProduto"
                        :produto="produto"
                    ></fz-produto-modal-comentarios>

                    <fz-produto-avaliacoes
                        v-if="dadosCompletos"
                        :produto="produto"
                    ></fz-produto-avaliacoes>
                </div>
            </div>
        </div>

        <!-- Loading Skeleton -->
        <div v-else-if="carregandoDados" class="p-4">
            <fz-produto-modal-skeleton></fz-produto-modal-skeleton>
        </div>

        <!-- Dialog de Regras de Preços -->
        <fz-dialog-regras-precos></fz-dialog-regras-precos>

        <!-- Dialog de Vídeo Externo -->
        <fz-dialog-video-externo></fz-dialog-video-externo>
    </div>
    `},FZComponents.ProdutoModelo2Resumo={components:{"fz-produto-preco":FZComponents.ProdutoPreco,"fz-simulador-parcelas-melhor-parcelamento":FZComponents.SimuladorParcelasMelhorParcelamento},mixins:[ProdutoConteudoMixin],props:{produto:{type:Object,required:!0}},computed:{exibirAvaliacoes(){return this.produto.total_avaliacoes>0},exibirVisualizacoes(){return this.produto.total_visualizacoes>0},exibirVendas(){return this.configsLoja.mostrarQuantidadeVenda&&this.produto.total_vendas>0},exibirProvaSocial(){return this.exibirVisualizacoes||this.exibirVendas},exibirEstoque(){return this.configsLoja.mostrarQuantidadeEstoque&&this.produto.controlar_estoque=="1"&&this.produto.total_estoque>0},categorias(){return!this.produto.categorias||!this.configsLoja.categorias?this.produto.categoria_nome?[this.produto.categoria_nome]:[]:Object.keys(this.produto.categorias).map(id=>{var _a;return(_a=this.configsLoja.categorias[id])==null?void 0:_a.nome}).filter(Boolean)},avaliacaoFormatada(){return Number(this.produto.media_avaliacoes||0).toFixed(1).replace(".",",")},estrelasAvaliacao(){const nota=Math.round(Number(this.produto.media_avaliacoes)||0);return Array.from({length:5},(_,indice)=>indice<nota)},visualizacoesFormatadas(){return new Intl.NumberFormat("pt-BR",{notation:"compact",maximumFractionDigits:1}).format(this.produto.total_visualizacoes)},vendasFormatadas(){return new Intl.NumberFormat("pt-BR",{notation:"compact",maximumFractionDigits:1}).format(this.produto.total_vendas)},temVideoExterno(){var _a,_b,_c,_d;return((_b=(_a=this.produto)==null?void 0:_a.video_externo)==null?void 0:_b.id)&&((_d=(_c=this.produto)==null?void 0:_c.video_externo)==null?void 0:_d.service)}},methods:{irParaAvaliacoes(){var _a;const avaliacoes=(_a=this.$el.closest(".fz-produto-conteudo"))==null?void 0:_a.querySelector(".fz-produto-avaliacoes");avaliacoes&&avaliacoes.scrollIntoView({behavior:"smooth",block:"start"})},abrirVideoExterno(){this.abrirDialogVideoExterno(this.produto)}},template:`
    <div class="fz-produto-modelo-2__resumo">
        <div v-if="exibirAvaliacoes" class="fz-produto-modelo-2__linha-avaliacao" @click="irParaAvaliacoes" style="cursor: pointer; width: fit-content;">
            <span class="fz-produto-modelo-2__estrelas" :aria-label="avaliacaoFormatada + ' de 5 estrelas'">
                <i v-for="(preenchida, indice) in estrelasAvaliacao" :key="indice" :class="preenchida ? 'pi pi-star-fill' : 'pi pi-star'"></i>
            </span>
            <strong>{{ avaliacaoFormatada }}</strong>
            <span>{{ produto.total_avaliacoes }} {{ produto.total_avaliacoes === 1 ? 'avaliação' : 'avaliações' }}</span>
        </div>

        <div v-if="exibirProvaSocial" class="fz-produto-modelo-2__linha-prova-social">
            <span v-if="exibirVisualizacoes"><i class="pi pi-eye"></i> <strong>{{ visualizacoesFormatadas }} visitas</strong></span>
            <em v-if="exibirVisualizacoes && exibirVendas">·</em>
            <span v-if="exibirVendas"><i class="pi pi-shopping-cart"></i> <strong>{{ vendasFormatadas }} vendas</strong></span>
        </div>

        <h1 class="fz-produto-modelo-2__titulo">{{ produto.nome }}</h1>

        <div v-if="categorias.length || produto.sku || produto.destaque == 1 || temVideoExterno" class="fz-produto-modelo-2__metadados">
            <span v-for="categoria in categorias" :key="categoria">{{ categoria }}</span>
            <span v-if="produto.sku && configsLoja.mostrarCodigoReferenciaProduto">Ref. {{ produto.sku }}</span>
            <span v-if="produto.destaque == 1">Destaque</span>
            <span v-if="exibirEstoque">{{ produto.total_estoque }} em estoque</span>
            <button
                v-if="temVideoExterno"
                type="button"
                class="fz-produto-modelo-2__metadado-video"
                @click="abrirVideoExterno"
                aria-label="Ver vídeo do produto"
            >
                <i class="pi pi-video" aria-hidden="true"></i>
                Ver Vídeo
            </button>
        </div>

        <div v-if="!configsLoja.somenteOrcamentos && !configsLoja.precosRestritos" class="fz-produto-modelo-2__preco">
            <fz-produto-preco
                :produto="produto"
                :somente-orcamentos="configsLoja.somenteOrcamentos"
                :precos-restritos="configsLoja.precosRestritos"
                :preco-destaque="configsLoja.precoDestaque"
                :ativar-simulador-parcelas="configsLoja.ativarSimuladorParcelas"
                alinhamento="esquerda"
            ></fz-produto-preco>

            <fz-simulador-parcelas-melhor-parcelamento
                v-if="configsLoja.ativarSimuladorParcelas && !produto.venda_externa"
                :produto="produto"
                :simulacao="produto.simulacao_parcelas"
                :abrir-modal="true"
                alinhamento="direita"
                class="fz-produto-modelo-2__parcelamento"
            ></fz-simulador-parcelas-melhor-parcelamento>
        </div>
    </div>
    `},FZComponents.ProdutoModelo2DescontoProgressivo={mixins:[ProdutoConteudoMixin],props:{produto:{type:Object,required:!0}},computed:{regras(){const regrasProcessadas=this.processarRegrasPrecos(this.produto);return[...regrasProcessadas.regrasCategoria||[],...regrasProcessadas.regrasProduto||[]].map(regra=>({...regra,condicao:regra.tipoRegra==="valor"?`A partir de R$ ${this.formatarPreco(regra.itensMinimo)}`:`${regra.itensMinimo}+ itens`}))}},template:`
    <section v-if="regras.length" class="fz-produto-modelo-2__desconto-progressivo">
        <div class="fz-produto-modelo-2__desconto-cabecalho">
            <div>
                <strong>Descontos progressivos</strong>
                <small>As condições são aplicadas automaticamente no carrinho.</small>
            </div>
        </div>
        <div
            class="fz-produto-modelo-2__desconto-regras"
            :class="{ 'fz-produto-modelo-2__desconto-regras--rolavel': regras.length > 3 }"
            :tabindex="regras.length > 3 ? 0 : null"
            aria-label="Regras de descontos progressivos"
        >
            <article v-for="(regra, index) in regras" :key="index" :class="{ 'fz-produto-modelo-2__desconto-regra--destaque': index === regras.length - 1 }">
                <span>{{ regra.condicao }}</span>
                <strong>{{ regra.textoDesconto }}</strong>
            </article>
        </div>
    </section>
    `},FZComponents.ProdutoModelo2GaleriaEditorial={components:{"p-image":PrimeVue.Image},mixins:[ProdutoConteudoMixin],props:{produto:{type:Object,required:!0}},data(){return{swiperGaleria:null}},computed:{imagens(){return this.produto.imagens||[]}},mounted(){this.$nextTick(()=>this.inicializarSwiper())},beforeUnmount(){this.destruirSwiper()},watch:{"produto.id"(){this.destruirSwiper(),this.$nextTick(()=>this.inicializarSwiper())}},methods:{inicializarSwiper(){!this.$refs.swiperGaleria||typeof Swiper=="undefined"||this.imagens.length<2||(this.swiperGaleria=new Swiper(this.$refs.swiperGaleria,{slidesPerView:1,spaceBetween:14,watchOverflow:!0,breakpoints:{700:{slidesPerView:2,spaceBetween:16},981:{slidesPerView:3,spaceBetween:20}}}))},destruirSwiper(){this.swiperGaleria&&(this.swiperGaleria.destroy(!0,!0),this.swiperGaleria=null)},anterior(){var _a;(_a=this.swiperGaleria)==null||_a.slidePrev()},proxima(){var _a;(_a=this.swiperGaleria)==null||_a.slideNext()}},template:`
    <section v-if="imagens.length > 1" class="fz-produto-modelo-2__galeria-editorial">
        <div class="fz-produto-modelo-2__cabecalho-secao fz-produto-modelo-2__cabecalho-secao--centralizado">
            <span>Galeria</span>
            <h2>Fotos do produto</h2>
        </div>
        <div class="fz-produto-modelo-2__galeria-editorial-carrossel">
            <button type="button" class="swiper-button-prev fz-seta-slider fz-produto-modelo-2__galeria-seta fz-produto-modelo-2__galeria-seta--anterior" aria-label="Fotos anteriores" @click="anterior"></button>
            <div ref="swiperGaleria" class="fz-produto-modelo-2__galeria-editorial-lista swiper">
                <div class="swiper-wrapper">
                    <div v-for="(imagem, index) in imagens" :key="imagem + index" class="swiper-slide">
                        <p-image
                            :src="obterURLArquivos(imagem)"
                            :alt="produto.nome + ' - Foto ' + (index + 1)"
                            preview
                            image-class="fz-produto-modelo-2__galeria-editorial-imagem"
                            :image-style="{ cursor: 'zoom-in' }"
                            @error="handleImageError"
                        >
                            <template #previewicon><span></span></template>
                        </p-image>
                    </div>
                </div>
            </div>
            <button type="button" class="swiper-button-next fz-seta-slider fz-produto-modelo-2__galeria-seta fz-produto-modelo-2__galeria-seta--proxima" aria-label="Próximas fotos" @click="proxima"></button>
        </div>
    </section>
    `},FZComponents.ProdutoConteudoModelo2={...FZComponents.ProdutoConteudoModelo1,name:"ProdutoConteudoModelo2",components:{...FZComponents.ProdutoConteudoModelo1.components,"fz-produto-modelo2-resumo":FZComponents.ProdutoModelo2Resumo,"fz-produto-modelo2-desconto-progressivo":FZComponents.ProdutoModelo2DescontoProgressivo,"fz-produto-modelo2-galeria-editorial":FZComponents.ProdutoModelo2GaleriaEditorial},data(){return{...FZComponents.ProdutoConteudoModelo1.data.call(this),variacoesDestaque:[]}},methods:{...FZComponents.ProdutoConteudoModelo1.methods,deveRolarAbaAtiva(){return window.innerWidth>980},handleSlideChange(payload){if(FZComponents.ProdutoConteudoModelo1.methods.handleSlideChange.call(this,payload),payload.tipo!=="imagem"||!payload.imagem){this.variacoesDestaque=[];return}this.variacoesDestaque=Object.entries(this.produto.imagens_variacoes||{}).filter(([,imagem])=>imagem===payload.imagem).map(([variacaoId])=>String(variacaoId)),!(window.innerWidth<=980||this.variacoesDestaque.length===0)&&this.$nextTick(()=>{const primeiraVariacao=this.$el.querySelector(`[data-variacao-id="${this.variacoesDestaque[0]}"]`);primeiraVariacao==null||primeiraVariacao.scrollIntoView({behavior:"smooth",block:"nearest"})})}},template:`
    <div class="fz-produto-conteudo fz-produto-modelo-2">
        <div v-if="store.erro" class="fz-produto-conteudo__erro p-4">
            <p-message severity="error" :closable="false">{{ store.erro }}</p-message>
        </div>

        <div v-else-if="produtoSomenteId && carregandoDados" class="fz-produto-conteudo__container container-fluid p-4">
            <fz-produto-modal-skeleton></fz-produto-modal-skeleton>
        </div>

        <template v-else-if="produto">
            <div class="fz-produto-modelo-2__principal">
                <aside class="fz-produto-modelo-2__midia">
                    <fz-produto-modal-carousel
                        ref="carousel"
                        :produto="produto"
                        :altura-fixa="false"
                        @slide-change="handleSlideChange"
                    ></fz-produto-modal-carousel>
                </aside>

                <section class="fz-produto-modelo-2__compra">
                    <fz-produto-modelo2-resumo :produto="produto"></fz-produto-modelo2-resumo>

                    <fz-produto-modal-audio-descricao
                        v-if="dadosCompletos && produto.audio_descricao"
                        :audio-path="produto.audio_descricao"
                        :produto-id="produto.id"
                        :vendedor-nome="configsLoja.vendedorNome || ''"
                        :vendedor-foto="configsLoja.vendedorFoto || ''"
                        :total-plays="produto.total_plays_audio || 0"
                    ></fz-produto-modal-audio-descricao>

                    <fz-produto-modal-skeleton-detalhes v-if="carregandoDados"></fz-produto-modal-skeleton-detalhes>

                    <div v-else class="fz-produto-modelo-2__dados-completos">
                        <fz-produto-modelo2-desconto-progressivo :produto="produto"></fz-produto-modelo2-desconto-progressivo>

                        <div v-if="exibirAviseMeForm" class="fz-produto-modelo-2__avise-me">
                            <fz-produto-modal-avise-me-form :produto="produto"></fz-produto-modal-avise-me-form>
                        </div>

                        <section v-else-if="!produto.venda_externa && !configsLoja.precosRestritos" class="fz-produto-modelo-2__variacoes">
                            <div class="fz-produto-modelo-2__titulo-variacoes">
                                <span aria-hidden="true"></span>
                                <strong>Escolha as variações</strong>
                                <span aria-hidden="true"></span>
                            </div>

                            <fz-produto-kit-componentes
                                v-if="produto.is_kit || produto.tipo_produto === 'kit'"
                                :produto="produto"
                            ></fz-produto-kit-componentes>

                            <!-- Venda em Grade (hibrida com abas; quebrada colapsa para individual) -->
                            <template v-if="produto.grade && !isEmpty(produto.grade) && produto.grade_permitir_individual && !produto.grade_quebrada">
                                <fz-variacao-grade-com-abas
                                    :produto="produto"
                                    :catalogo-id="configsLoja.catalogoId"
                                    :carrinho="configsLoja.carrinho || {}"
                                    :configs-loja="configsLoja"
                                    :somente-orcamentos="configsLoja.somenteOrcamentos"
                                    :precos-restritos="configsLoja.precosRestritos"
                                    :exibir-preco="true"
                                    :exibir-sku="true"
                                    :exibir-divisoria="false"
                                    :exibir-descontos="true"
                                    :video-ativo="!isEmpty(produto.video)"
                                    :variacoes-isoladas="false"
                                    :tab-ativa="tabAtivaSubgrupos"
                                    :variacoes-destaque="variacoesDestaque"
                                ></fz-variacao-grade-com-abas>
                            </template>
                            <template v-else-if="produto.grade && !isEmpty(produto.grade) && !produto.grade_quebrada">
                                <fz-variacao-com-grade
                                    :produto="produto"
                                    :catalogo-id="configsLoja.catalogoId"
                                    :carrinho="configsLoja.carrinho || {}"
                                    :exibir-sku="true"
                                    :exibir-descontos="true"
                                    :video-ativo="!isEmpty(produto.video)"
                                    :variacoes-isoladas="false"
                                ></fz-variacao-com-grade>
                            </template>

                            <template v-else-if="produto.subgrupos_variacoes && !isEmpty(produto.subgrupos_variacoes)">
                                <fz-variacao-com-subgrupos-variacao
                                    :produto="produto"
                                    :catalogo-id="configsLoja.catalogoId"
                                    :carrinho="configsLoja.carrinho || {}"
                                    :somente-orcamentos="configsLoja.somenteOrcamentos"
                                    :precos-restritos="configsLoja.precosRestritos"
                                    :exibir-preco="true"
                                    :exibir-sku="true"
                                    :exibir-divisoria="false"
                                    :exibir-descontos="true"
                                    :video-ativo="!isEmpty(produto.video)"
                                    :variacoes-isoladas="false"
                                    :tab-ativa="tabAtivaSubgrupos"
                                    :variacoes-destaque="variacoesDestaque"
                                    :rolar-aba-ativa="deveRolarAbaAtiva()"
                                ></fz-variacao-com-subgrupos-variacao>
                            </template>

                            <template v-else-if="produto.variacoes && !isEmpty(produto.variacoes)">
                                <fz-variacao-com-variacao
                                    :produto="produto"
                                    :catalogo-id="configsLoja.catalogoId"
                                    :carrinho="configsLoja.carrinho || {}"
                                    :somente-orcamentos="configsLoja.somenteOrcamentos"
                                    :precos-restritos="configsLoja.precosRestritos"
                                    :exibir-preco="true"
                                    :exibir-sku="true"
                                    :exibir-divisoria="false"
                                    :exibir-descontos="true"
                                    :video-ativo="!isEmpty(produto.video)"
                                    :variacoes-destaque="variacoesDestaque"
                                ></fz-variacao-com-variacao>
                            </template>

                            <template v-else>
                                <fz-variacao-sem-variacao
                                    :produto="produto"
                                    :catalogo-id="configsLoja.catalogoId"
                                    :carrinho="configsLoja.carrinho || {}"
                                    :exibir-sku="true"
                                    :exibir-descontos="true"
                                ></fz-variacao-sem-variacao>
                            </template>
                        </section>

                        <fz-produto-modal-simulador-frete
                            v-if="!produtoIndisponivelEstoque && configsLoja.habilitarSimuladorFreteProduto"
                            :produto="produto"
                            :exibir-titulo="false"
                        >
                            <template #cabecalho>
                                <div class="fz-produto-modelo-2__frete-cabecalho">
                                    <span class="fz-produto-modelo-2__frete-icone"><i class="pi pi-truck"></i></span>
                                    <div>
                                        <strong>Calcule o frete</strong>
                                        <small>Informe seu CEP para consultar prazo e entrega.</small>
                                    </div>
                                </div>
                            </template>
                        </fz-produto-modal-simulador-frete>

                        <fz-produto-cupons
                            :cupons="configsLoja.cuponsDivulgaveis"
                            :produto="produto"
                        ></fz-produto-cupons>

                        <fz-produto-modal-footer :contexto="contexto" :produto="produto"></fz-produto-modal-footer>
                    </div>
                </section>
            </div>

            <div v-if="dadosCompletos" class="fz-produto-modelo-2__conteudo-inferior">
                <section v-if="produto.descricao" class="fz-produto-modelo-2__descricao-editorial">
                    <div class="fz-produto-modelo-2__cabecalho-secao fz-produto-modelo-2__cabecalho-secao--centralizado">
                        <span>Sobre o produto</span>
                        <h2>Descrição do produto</h2>
                    </div>
                    <fz-produto-modal-descricao :descricao="produto.descricao" :produto-id="produto.id" :exibir-titulo="false"></fz-produto-modal-descricao>
                </section>

                <section v-if="obterDescricaoGuiaMedidas(produto)" class="fz-produto-modelo-2__guia-medidas">
                    <div class="fz-produto-modelo-2__cabecalho-secao fz-produto-modelo-2__cabecalho-secao--centralizado">
                        <span>Informações</span>
                        <h2>Guia de Medidas</h2>
                    </div>
                    <fz-produto-modal-guia-medidas :produto="produto" :exibir-titulo="false"></fz-produto-modal-guia-medidas>
                </section>

                <section v-if="obterWidgetsProduto(produto).length" class="fz-produto-modelo-2__widgets">
                    <div class="fz-produto-modelo-2__cabecalho-secao fz-produto-modelo-2__cabecalho-secao--centralizado">
                        <span>Informações</span>
                        <h2>Informações adicionais</h2>
                    </div>
                    <fz-produto-modal-widgets :produto="produto" :exibir-titulo="false"></fz-produto-modal-widgets>
                </section>

                <fz-produto-modelo2-galeria-editorial :produto="produto"></fz-produto-modelo2-galeria-editorial>

                <section v-if="configsLoja.exibirProdutosRelacionadosTelaProduto" class="fz-produto-modelo-2__relacionados-editorial">
                    <div class="fz-produto-modelo-2__titulo-linha">
                        <i class="pi pi-th-large"></i>
                        <h2>Produtos relacionados</h2>
                    </div>
                    <fz-produto-modal-produtos-relacionados :produto="produto" :exibir-titulo="false" :abrir-link-direto="contexto === 'pagina'"></fz-produto-modal-produtos-relacionados>
                </section>

                <div class="fz-produto-modelo-2__interacoes">
                    <section v-if="configsLoja.exibirComentariosTelaProduto" class="fz-produto-modelo-2__interacao">
                        <div class="fz-produto-modelo-2__titulo-linha">
                            <i class="pi pi-comments"></i>
                            <h2>Perguntas</h2>
                        </div>
                        <fz-produto-modal-comentarios :produto="produto" :exibir-titulo="false"></fz-produto-modal-comentarios>
                    </section>
                    <section class="fz-produto-modelo-2__interacao">
                        <div class="fz-produto-modelo-2__titulo-linha">
                            <i class="pi pi-star"></i>
                            <h2>Avaliações dos clientes</h2>
                        </div>
                        <fz-produto-avaliacoes :produto="produto" :exibir-titulo="false"></fz-produto-avaliacoes>
                    </section>
                </div>
            </div>
        </template>

        <div v-else-if="carregandoDados" class="p-4">
            <fz-produto-modal-skeleton></fz-produto-modal-skeleton>
        </div>

        <fz-dialog-regras-precos></fz-dialog-regras-precos>
        <fz-dialog-video-externo></fz-dialog-video-externo>
    </div>
    `},FZComponents.ProdutoModelo3Resumo={...FZComponents.ProdutoModelo2Resumo,name:"ProdutoModelo3Resumo",components:{...FZComponents.ProdutoModelo2Resumo.components,"fz-produto-formas-pagamento":FZComponents.ProdutoFormasPagamento,"fz-simulador-parcelas-melhor-desconto":FZComponents.SimuladorParcelasMelhorDesconto},template:`
    <div class="fz-produto-modelo-3__resumo">
        <div v-if="categorias.length || produto.sku || produto.destaque == 1 || exibirEstoque || temVideoExterno" class="fz-produto-modelo-3__referencias">
            <span v-for="categoria in categorias" :key="categoria">{{ categoria }}</span>
            <span v-if="produto.sku && configsLoja.mostrarCodigoReferenciaProduto">Ref. {{ produto.sku }}</span>
            <span v-if="produto.destaque == 1">Destaque</span>
            <span v-if="exibirEstoque" class="fz-produto-modelo-3__estoque">{{ produto.total_estoque }} em estoque</span>
            <button
                v-if="temVideoExterno"
                type="button"
                class="fz-produto-modelo-3__video"
                @click="abrirVideoExterno"
                aria-label="Ver vídeo do produto"
            >
                <i class="pi pi-video" aria-hidden="true"></i>
                Ver vídeo
            </button>
        </div>

        <h1 class="fz-produto-modelo-3__titulo">{{ produto.nome }}</h1>

        <div
            v-if="exibirAvaliacoes || exibirProvaSocial"
            class="fz-produto-modelo-3__linha-avaliacao"
            :class="{ 'fz-produto-modelo-3__linha-avaliacao--clicavel': exibirAvaliacoes }"
            @click="exibirAvaliacoes ? irParaAvaliacoes() : null"
        >
            <template v-if="exibirAvaliacoes">
                <span class="fz-produto-modelo-3__estrelas" :aria-label="avaliacaoFormatada + ' de 5 estrelas'">
                    <i v-for="(preenchida, indice) in estrelasAvaliacao" :key="indice" :class="preenchida ? 'pi pi-star-fill' : 'pi pi-star'"></i>
                </span>
                <strong>{{ avaliacaoFormatada }}</strong>
                <span>{{ produto.total_avaliacoes }} {{ produto.total_avaliacoes === 1 ? 'avaliação' : 'avaliações' }}</span>
            </template>
            <span v-if="exibirAvaliacoes && exibirProvaSocial" class="fz-produto-modelo-3__separador" aria-hidden="true">|</span>
            <span v-if="exibirVisualizacoes" class="fz-produto-modelo-3__prova-social"><i class="pi pi-eye"></i> {{ visualizacoesFormatadas }} visitas</span>
            <span v-if="exibirVendas" class="fz-produto-modelo-3__prova-social"><i class="pi pi-shopping-cart"></i> {{ vendasFormatadas }} vendas</span>
        </div>

        <div v-if="!configsLoja.somenteOrcamentos && !configsLoja.precosRestritos" class="fz-produto-modelo-3__preco">
            <div class="fz-produto-modelo-3__preco-grid">
                <fz-produto-preco
                    :produto="produto"
                    :somente-orcamentos="configsLoja.somenteOrcamentos"
                    :precos-restritos="configsLoja.precosRestritos"
                    :preco-destaque="configsLoja.precoDestaque"
                    :ativar-simulador-parcelas="configsLoja.ativarSimuladorParcelas"
                    :exibir-simulador-melhor-desconto="false"
                    alinhamento="esquerda"
                    class="fz-produto-modelo-3__preco-valores"
                ></fz-produto-preco>

                <div v-if="configsLoja.ativarSimuladorParcelas && !produto.venda_externa" class="fz-produto-modelo-3__simuladores">
                    <fz-simulador-parcelas-melhor-desconto
                        :produto="produto"
                        :simulacao="produto.simulacao_parcelas"
                        :abrir-modal="true"
                        alinhamento="direita"
                        variacao="destaque"
                    ></fz-simulador-parcelas-melhor-desconto>

                    <fz-simulador-parcelas-melhor-parcelamento
                        :produto="produto"
                        :simulacao="produto.simulacao_parcelas"
                        :abrir-modal="true"
                        alinhamento="direita"
                        :mostrar-icones="false"
                        class="fz-produto-modelo-3__parcelamento"
                    ></fz-simulador-parcelas-melhor-parcelamento>
                </div>
            </div>

            <fz-produto-formas-pagamento
                v-if="configsLoja.ativarSimuladorParcelas && !produto.venda_externa"
                :produto="produto"
                :simulacao="produto.simulacao_parcelas"
                layout="modelo2"
            ></fz-produto-formas-pagamento>
        </div>
    </div>
    `},FZComponents.ProdutoModelo3DescontoProgressivo={...FZComponents.ProdutoModelo2DescontoProgressivo,name:"ProdutoModelo3DescontoProgressivo",template:`
    <section v-if="regras.length" class="fz-produto-modelo-3__desconto-progressivo">
        <div class="fz-produto-modelo-3__desconto-cabecalho">
            <strong>Descontos progressivos</strong>
            <small>As condições são aplicadas automaticamente no carrinho.</small>
        </div>
        <div
            class="fz-produto-modelo-3__desconto-regras"
            :class="{ 'fz-produto-modelo-3__desconto-regras--rolavel': regras.length > 3 }"
            :tabindex="regras.length > 3 ? 0 : null"
            aria-label="Regras de descontos progressivos"
        >
            <article v-for="(regra, index) in regras" :key="index" :class="{ 'fz-produto-modelo-3__desconto-regra--destaque': index === regras.length - 1 }">
                <span>{{ regra.condicao }}</span>
                <strong>{{ regra.textoDesconto }}</strong>
            </article>
        </div>
    </section>
    `},FZComponents.ProdutoModelo3GaleriaEditorial={components:{"p-image":PrimeVue.Image},mixins:[ProdutoConteudoMixin],props:{produto:{type:Object,required:!0}},computed:{imagens(){return this.produto.imagens||[]}},template:`
    <section v-if="imagens.length > 1" class="fz-produto-modelo-3__galeria-editorial">
        <div class="fz-produto-modelo-3__cabecalho-secao fz-produto-modelo-3__cabecalho-secao--centralizado">
            <span>Galeria</span>
            <h2>Fotos do produto</h2>
        </div>
        <div class="fz-produto-modelo-3__galeria-editorial-lista">
            <figure v-for="(imagem, index) in imagens" :key="imagem + index" class="fz-produto-modelo-3__galeria-editorial-item">
                <p-image
                    :src="obterURLArquivos(imagem)"
                    :alt="produto.nome + ' - Foto ' + (index + 1)"
                    preview
                    image-class="fz-produto-modelo-3__galeria-editorial-imagem"
                    :image-style="{ cursor: 'zoom-in' }"
                    @error="handleImageError"
                >
                    <template #previewicon><span></span></template>
                </p-image>
            </figure>
        </div>
    </section>
    `},FZComponents.ProdutoConteudoModelo3={...FZComponents.ProdutoConteudoModelo2,name:"ProdutoConteudoModelo3",components:{...FZComponents.ProdutoConteudoModelo2.components,"fz-produto-modelo3-resumo":FZComponents.ProdutoModelo3Resumo,"fz-produto-modelo3-desconto-progressivo":FZComponents.ProdutoModelo3DescontoProgressivo,"fz-produto-modelo3-galeria-editorial":FZComponents.ProdutoModelo3GaleriaEditorial},template:`
    <div class="fz-produto-conteudo fz-produto-modelo-3">
        <div v-if="store.erro" class="fz-produto-conteudo__erro p-4">
            <p-message severity="error" :closable="false">{{ store.erro }}</p-message>
        </div>

        <div v-else-if="produtoSomenteId && carregandoDados" class="fz-produto-conteudo__container container-fluid p-4">
            <fz-produto-modal-skeleton></fz-produto-modal-skeleton>
        </div>

        <template v-else-if="produto">
            <div class="fz-produto-modelo-3__principal">
                <aside class="fz-produto-modelo-3__midia">
                    <fz-produto-modal-carousel
                        ref="carousel"
                        :produto="produto"
                        :altura-fixa="false"
                        @slide-change="handleSlideChange"
                    ></fz-produto-modal-carousel>
                </aside>

                <section class="fz-produto-modelo-3__compra">
                    <fz-produto-modelo3-resumo :produto="produto"></fz-produto-modelo3-resumo>

                    <fz-produto-modal-audio-descricao
                        v-if="dadosCompletos && produto.audio_descricao"
                        :audio-path="produto.audio_descricao"
                        :produto-id="produto.id"
                        :vendedor-nome="configsLoja.vendedorNome || ''"
                        :vendedor-foto="configsLoja.vendedorFoto || ''"
                        :total-plays="produto.total_plays_audio || 0"
                    ></fz-produto-modal-audio-descricao>

                    <fz-produto-modal-skeleton-detalhes v-if="carregandoDados"></fz-produto-modal-skeleton-detalhes>

                    <div v-else class="fz-produto-modelo-3__dados-completos">
                        <fz-produto-modelo3-desconto-progressivo :produto="produto"></fz-produto-modelo3-desconto-progressivo>

                        <div v-if="exibirAviseMeForm" class="fz-produto-modelo-3__avise-me">
                            <fz-produto-modal-avise-me-form :produto="produto"></fz-produto-modal-avise-me-form>
                        </div>

                        <section v-else-if="!produto.venda_externa && !configsLoja.precosRestritos" class="fz-produto-modelo-3__variacoes">
                            <div class="fz-produto-modelo-3__titulo-variacoes">
                                <strong>Escolha as variações</strong>
                            </div>

                            <fz-produto-kit-componentes
                                v-if="produto.is_kit || produto.tipo_produto === 'kit'"
                                :produto="produto"
                            ></fz-produto-kit-componentes>

                            <!-- Venda em Grade (hibrida com abas; quebrada colapsa para individual) -->
                            <template v-if="produto.grade && !isEmpty(produto.grade) && produto.grade_permitir_individual && !produto.grade_quebrada">
                                <fz-variacao-grade-com-abas
                                    :produto="produto"
                                    :catalogo-id="configsLoja.catalogoId"
                                    :carrinho="configsLoja.carrinho || {}"
                                    :configs-loja="configsLoja"
                                    :somente-orcamentos="configsLoja.somenteOrcamentos"
                                    :precos-restritos="configsLoja.precosRestritos"
                                    :exibir-preco="true"
                                    :exibir-sku="true"
                                    :exibir-divisoria="false"
                                    :exibir-descontos="true"
                                    :video-ativo="!isEmpty(produto.video)"
                                    :variacoes-isoladas="false"
                                    :tab-ativa="tabAtivaSubgrupos"
                                    :variacoes-destaque="variacoesDestaque"
                                ></fz-variacao-grade-com-abas>
                            </template>
                            <template v-else-if="produto.grade && !isEmpty(produto.grade) && !produto.grade_quebrada">
                                <fz-variacao-com-grade
                                    :produto="produto"
                                    :catalogo-id="configsLoja.catalogoId"
                                    :carrinho="configsLoja.carrinho || {}"
                                    :exibir-sku="true"
                                    :exibir-descontos="true"
                                    :video-ativo="!isEmpty(produto.video)"
                                    :variacoes-isoladas="false"
                                ></fz-variacao-com-grade>
                            </template>

                            <template v-else-if="produto.subgrupos_variacoes && !isEmpty(produto.subgrupos_variacoes)">
                                <fz-variacao-com-subgrupos-variacao
                                    :produto="produto"
                                    :catalogo-id="configsLoja.catalogoId"
                                    :carrinho="configsLoja.carrinho || {}"
                                    :somente-orcamentos="configsLoja.somenteOrcamentos"
                                    :precos-restritos="configsLoja.precosRestritos"
                                    :exibir-preco="true"
                                    :exibir-sku="true"
                                    :exibir-divisoria="false"
                                    :exibir-descontos="true"
                                    :video-ativo="!isEmpty(produto.video)"
                                    :variacoes-isoladas="false"
                                    :tab-ativa="tabAtivaSubgrupos"
                                    :variacoes-destaque="variacoesDestaque"
                                    :rolar-aba-ativa="deveRolarAbaAtiva()"
                                ></fz-variacao-com-subgrupos-variacao>
                            </template>

                            <template v-else-if="produto.variacoes && !isEmpty(produto.variacoes)">
                                <fz-variacao-com-variacao
                                    :produto="produto"
                                    :catalogo-id="configsLoja.catalogoId"
                                    :carrinho="configsLoja.carrinho || {}"
                                    :somente-orcamentos="configsLoja.somenteOrcamentos"
                                    :precos-restritos="configsLoja.precosRestritos"
                                    :exibir-preco="true"
                                    :exibir-sku="true"
                                    :exibir-divisoria="false"
                                    :exibir-descontos="true"
                                    :video-ativo="!isEmpty(produto.video)"
                                    :variacoes-destaque="variacoesDestaque"
                                ></fz-variacao-com-variacao>
                            </template>

                            <template v-else>
                                <fz-variacao-sem-variacao
                                    :produto="produto"
                                    :catalogo-id="configsLoja.catalogoId"
                                    :carrinho="configsLoja.carrinho || {}"
                                    :exibir-sku="true"
                                    :exibir-descontos="true"
                                ></fz-variacao-sem-variacao>
                            </template>
                        </section>

                        <fz-produto-modal-simulador-frete
                            v-if="!produtoIndisponivelEstoque && configsLoja.habilitarSimuladorFreteProduto"
                            :produto="produto"
                            :exibir-titulo="false"
                        >
                            <template #cabecalho>
                                <div class="fz-produto-modelo-3__frete-cabecalho">
                                    <span class="fz-produto-modelo-3__frete-icone"><i class="pi pi-truck"></i></span>
                                    <div>
                                        <strong>Calcule o frete</strong>
                                        <small>Informe seu CEP para consultar prazo e entrega.</small>
                                    </div>
                                </div>
                            </template>
                        </fz-produto-modal-simulador-frete>

                        <fz-produto-cupons
                            :cupons="configsLoja.cuponsDivulgaveis"
                            :produto="produto"
                        ></fz-produto-cupons>

                        <fz-produto-modal-footer :contexto="contexto" :produto="produto"></fz-produto-modal-footer>
                    </div>
                </section>
            </div>

            <div v-if="dadosCompletos" class="fz-produto-modelo-3__conteudo-inferior">
                <section v-if="produto.descricao" class="fz-produto-modelo-3__descricao-editorial">
                    <div class="fz-produto-modelo-3__cabecalho-secao">
                        <span>Sobre o produto</span>
                        <h2>Descrição do produto</h2>
                    </div>
                    <fz-produto-modal-descricao :descricao="produto.descricao" :produto-id="produto.id" :exibir-titulo="false"></fz-produto-modal-descricao>
                </section>

                <section v-if="obterDescricaoGuiaMedidas(produto)" class="fz-produto-modelo-3__guia-medidas">
                    <div class="fz-produto-modelo-3__cabecalho-secao fz-produto-modelo-3__cabecalho-secao--centralizado">
                        <span>Informações</span>
                        <h2>Guia de medidas</h2>
                    </div>
                    <fz-produto-modal-guia-medidas :produto="produto" :exibir-titulo="false"></fz-produto-modal-guia-medidas>
                </section>

                <section v-if="obterWidgetsProduto(produto).length" class="fz-produto-modelo-3__widgets">
                    <fz-produto-modal-widgets :produto="produto" :exibir-titulo="false"></fz-produto-modal-widgets>
                </section>

                <fz-produto-modelo3-galeria-editorial :produto="produto"></fz-produto-modelo3-galeria-editorial>

                <section v-if="configsLoja.exibirComentariosTelaProduto" class="fz-produto-modelo-3__interacao fz-produto-modelo-3__interacao--perguntas">
                    <div class="fz-produto-modelo-3__cabecalho-secao">
                        <span>Dúvidas sobre o produto</span>
                        <h2>Perguntas e respostas</h2>
                    </div>
                    <fz-produto-modal-comentarios :produto="produto" :exibir-titulo="false" layout="modelo2"></fz-produto-modal-comentarios>
                </section>

                <section class="fz-produto-modelo-3__interacao fz-produto-modelo-3__interacao--avaliacoes">
                    <div class="fz-produto-modelo-3__cabecalho-secao">
                        <span>Avaliações verificadas</span>
                    </div>
                    <fz-produto-avaliacoes :produto="produto" :exibir-titulo="false" layout="modelo2"></fz-produto-avaliacoes>
                </section>

                <section v-if="configsLoja.exibirProdutosRelacionadosTelaProduto" class="fz-produto-modelo-3__relacionados-editorial">
                    <div class="fz-produto-modelo-3__cabecalho-secao">
                        <span>Seleção da loja</span>
                        <h2>Produtos relacionados</h2>
                    </div>
                    <fz-produto-modal-produtos-relacionados :produto="produto" :exibir-titulo="false" :abrir-link-direto="contexto === 'pagina'"></fz-produto-modal-produtos-relacionados>
                </section>
            </div>
        </template>

        <div v-else-if="carregandoDados" class="p-4">
            <fz-produto-modal-skeleton></fz-produto-modal-skeleton>
        </div>

        <fz-dialog-regras-precos></fz-dialog-regras-precos>
        <fz-dialog-video-externo></fz-dialog-video-externo>
    </div>
    `},FZComponents.ProdutoModelo4Resumo={...FZComponents.ProdutoModelo2Resumo,name:"ProdutoModelo4Resumo",components:{...FZComponents.ProdutoModelo2Resumo.components,"fz-produto-formas-pagamento":FZComponents.ProdutoFormasPagamento,"fz-simulador-parcelas-melhor-desconto":FZComponents.SimuladorParcelasMelhorDesconto},template:`
    <div class="fz-produto-modelo-4__resumo">
        <div v-if="categorias.length || produto.sku || produto.destaque == 1 || exibirEstoque || temVideoExterno" class="fz-produto-modelo-4__referencias">
            <span v-for="categoria in categorias" :key="categoria">{{ categoria }}</span>
            <span v-if="produto.sku && configsLoja.mostrarCodigoReferenciaProduto">Ref. {{ produto.sku }}</span>
            <span v-if="produto.destaque == 1">Destaque</span>
            <span v-if="exibirEstoque" class="fz-produto-modelo-4__estoque">{{ produto.total_estoque }} em estoque</span>
            <button
                v-if="temVideoExterno"
                type="button"
                class="fz-produto-modelo-4__video"
                @click="abrirVideoExterno"
                aria-label="Ver vídeo do produto"
            >
                <i class="pi pi-video" aria-hidden="true"></i>
                Ver vídeo
            </button>
        </div>

        <h1 class="fz-produto-modelo-4__titulo">{{ produto.nome }}</h1>

        <div
            v-if="exibirAvaliacoes || exibirProvaSocial"
            class="fz-produto-modelo-4__linha-avaliacao"
            :class="{ 'fz-produto-modelo-4__linha-avaliacao--clicavel': exibirAvaliacoes }"
            @click="exibirAvaliacoes ? irParaAvaliacoes() : null"
        >
            <template v-if="exibirAvaliacoes">
                <span class="fz-produto-modelo-4__estrelas" :aria-label="avaliacaoFormatada + ' de 5 estrelas'">
                    <i v-for="(preenchida, indice) in estrelasAvaliacao" :key="indice" :class="preenchida ? 'pi pi-star-fill' : 'pi pi-star'"></i>
                </span>
                <strong>{{ avaliacaoFormatada }}</strong>
                <span>{{ produto.total_avaliacoes }} {{ produto.total_avaliacoes === 1 ? 'avaliação' : 'avaliações' }}</span>
            </template>
            <span v-if="exibirAvaliacoes && exibirProvaSocial" class="fz-produto-modelo-4__separador" aria-hidden="true">|</span>
            <span v-if="exibirVisualizacoes" class="fz-produto-modelo-4__prova-social"><i class="pi pi-eye"></i> {{ visualizacoesFormatadas }} visitas</span>
            <span v-if="exibirVendas" class="fz-produto-modelo-4__prova-social"><i class="pi pi-shopping-cart"></i> {{ vendasFormatadas }} vendas</span>
        </div>

        <div v-if="!configsLoja.somenteOrcamentos && !configsLoja.precosRestritos" class="fz-produto-modelo-4__preco">
            <div class="fz-produto-modelo-4__preco-grid">
                <fz-produto-preco
                    :produto="produto"
                    :somente-orcamentos="configsLoja.somenteOrcamentos"
                    :precos-restritos="configsLoja.precosRestritos"
                    :preco-destaque="configsLoja.precoDestaque"
                    :ativar-simulador-parcelas="configsLoja.ativarSimuladorParcelas"
                    :exibir-simulador-melhor-desconto="false"
                    alinhamento="esquerda"
                    class="fz-produto-modelo-4__preco-valores"
                ></fz-produto-preco>

                <div v-if="configsLoja.ativarSimuladorParcelas && !produto.venda_externa" class="fz-produto-modelo-4__simuladores">
                    <fz-simulador-parcelas-melhor-desconto
                        :produto="produto"
                        :simulacao="produto.simulacao_parcelas"
                        :abrir-modal="true"
                        alinhamento="direita"
                        variacao="destaque"
                    ></fz-simulador-parcelas-melhor-desconto>

                    <fz-simulador-parcelas-melhor-parcelamento
                        :produto="produto"
                        :simulacao="produto.simulacao_parcelas"
                        :abrir-modal="true"
                        alinhamento="direita"
                        :mostrar-icones="false"
                        class="fz-produto-modelo-4__parcelamento"
                    ></fz-simulador-parcelas-melhor-parcelamento>
                </div>
            </div>

            <fz-produto-formas-pagamento
                v-if="configsLoja.ativarSimuladorParcelas && !produto.venda_externa"
                :produto="produto"
                :simulacao="produto.simulacao_parcelas"
                layout="modelo2"
            ></fz-produto-formas-pagamento>
        </div>
    </div>
    `},FZComponents.ProdutoModelo4DescontoProgressivo={...FZComponents.ProdutoModelo2DescontoProgressivo,name:"ProdutoModelo4DescontoProgressivo",template:`
    <section v-if="regras.length" class="fz-produto-modelo-4__desconto-progressivo">
        <div class="fz-produto-modelo-4__desconto-cabecalho">
            <strong>Descontos progressivos</strong>
            <small>As condições são aplicadas automaticamente no carrinho.</small>
        </div>
        <div
            class="fz-produto-modelo-4__desconto-regras"
            :class="{ 'fz-produto-modelo-4__desconto-regras--rolavel': regras.length > 3 }"
            :tabindex="regras.length > 3 ? 0 : null"
            aria-label="Regras de descontos progressivos"
        >
            <article v-for="(regra, index) in regras" :key="index" :class="{ 'fz-produto-modelo-4__desconto-regra--destaque': index === regras.length - 1 }">
                <span>{{ regra.condicao }}</span>
                <strong>{{ regra.textoDesconto }}</strong>
            </article>
        </div>
    </section>
    `},FZComponents.ProdutoConteudoModelo4={...FZComponents.ProdutoConteudoModelo3,name:"ProdutoConteudoModelo4",components:{...FZComponents.ProdutoConteudoModelo3.components,"fz-produto-modelo4-resumo":FZComponents.ProdutoModelo4Resumo,"fz-produto-modelo4-desconto-progressivo":FZComponents.ProdutoModelo4DescontoProgressivo,"fz-produto":FZComponents.Produto},data(){return{...FZComponents.ProdutoConteudoModelo3.data.call(this),produtosRelacionados:[],carregandoProdutosRelacionados:!1,erroProdutosRelacionados:null,produtoRelacionadosId:null,requisicaoRelacionadosId:0,abaInformacoes:"descricao"}},computed:{...FZComponents.ProdutoConteudoModelo3.computed,primeiroProdutoRelacionado(){return this.produtosRelacionados[0]||null},produtosVejaTambem(){return this.produtosRelacionados.slice(0,4)},temProdutosRelacionados(){return this.produtosRelacionados.length>0},temDescricaoProduto(){var _a;return!!((_a=this.produto)!=null&&_a.descricao)},temGuiaMedidasProduto(){return!!this.obterDescricaoGuiaMedidas(this.produto)},temWidgetsProduto(){return this.obterWidgetsProduto(this.produto).length>0},abaInformacoesExibida(){return this.abaInformacoes==="descricao"&&this.temDescricaoProduto?"descricao":this.abaInformacoes==="guia-medidas"&&this.temGuiaMedidasProduto?"guia-medidas":this.abaInformacoes==="widgets"&&this.temWidgetsProduto?"widgets":this.temDescricaoProduto?"descricao":this.temGuiaMedidasProduto?"guia-medidas":"widgets"},opcoesProdutoRelacionado(){return{layout:"grid_novo",abrirLinkDireto:this.contexto==="pagina",somenteOrcamentos:this.configsLoja.somenteOrcamentos,precosRestritos:this.configsLoja.precosRestritos,precoDestaque:this.configsLoja.precoDestaque,mostrarQuantidadeVenda:this.configsLoja.mostrarQuantidadeVenda,habilitarCurtidas:this.configsLoja.habilitarCurtidas,habilitarPerguntas:this.configsLoja.habilitarPerguntas,permitirCompartilharProduto:this.configsLoja.permitirCompartilharProduto,ativarSimuladorParcelas:this.configsLoja.ativarSimuladorParcelas,textoBotaoAcaoProdutos:this.configsLoja.textoBotaoAcaoProdutos,iconeBotaoAcaoProdutos:this.configsLoja.iconeBotaoAcaoProdutos,gridFormatoImagem:this.configsLoja.gridFormatoImagem,campanhaPromocionalAtivaNoMomento:this.configsLoja.campanhaPromocionalAtivaNoMomento,campanhaPromocionalTagProdutosAtivada:this.configsLoja.campanhaPromocionalTagProdutosAtivada,campanhaPromocionalTagProdutosTexto:this.configsLoja.campanhaPromocionalTagProdutosTexto,campanhaPromocionalTagProdutosCorFundo:this.configsLoja.campanhaPromocionalTagProdutosCorFundo,campanhaPromocionalTagProdutosCorTexto:this.configsLoja.campanhaPromocionalTagProdutosCorTexto}}},watch:{...FZComponents.ProdutoConteudoModelo3.watch,produto:{handler(produto,produtoAnterior){!(produto!=null&&produto.id)||String(produto.id)===String((produtoAnterior==null?void 0:produtoAnterior.id)||"")||(this.produtosRelacionados=[],this.erroProdutosRelacionados=null,this.produtoRelacionadosId=null,this.abaInformacoes=produto.descricao?"descricao":this.temGuiaMedidasProduto?"guia-medidas":"widgets",this.carregarProdutosRelacionados())},immediate:!0}},methods:{...FZComponents.ProdutoConteudoModelo3.methods,async carregarProdutosRelacionados(){var _a,_b,_c;if(!this.configsLoja.exibirProdutosRelacionadosTelaProduto||!((_a=this.produto)!=null&&_a.id))return;const produtoId=this.produto.id;if(this.carregandoProdutosRelacionados||String(this.produtoRelacionadosId||"")===String(produtoId))return;this.produtoRelacionadosId=produtoId,this.carregandoProdutosRelacionados=!0,this.erroProdutosRelacionados=null;const requisicaoId=++this.requisicaoRelacionadosId;try{if(Array.isArray(this.produto.produtos_relacionados)&&this.produto.produtos_relacionados.length>0){this.produtosRelacionados=this.produto.produtos_relacionados;return}const cache=(_b=this.conteudoStore.cacheProdutos[produtoId])==null?void 0:_b.relacionados;if(cache&&Array.isArray(cache.produtos)){this.produtosRelacionados=cache.produtos;return}const url=this.obterLinkCatalogo(`produto/${produtoId}`)+"?relacionados",response=await fetch(url);if(!response.ok)throw new Error("Erro ao carregar produtos relacionados");const data=await response.json();if(requisicaoId!==this.requisicaoRelacionadosId||String((_c=this.produto)==null?void 0:_c.id)!==String(produtoId))return;this.produtosRelacionados=Array.isArray(data.produtos_relacionados)?data.produtos_relacionados:[],this.conteudoStore.cacheProdutos[produtoId]||(this.conteudoStore.cacheProdutos[produtoId]={}),this.conteudoStore.cacheProdutos[produtoId].relacionados={produtos:this.produtosRelacionados}}catch(error){if(requisicaoId!==this.requisicaoRelacionadosId)return;console.error("[Modelo 4] Erro ao carregar produtos relacionados:",error),this.erroProdutosRelacionados="Erro ao carregar produtos relacionados."}finally{requisicaoId===this.requisicaoRelacionadosId&&(this.carregandoProdutosRelacionados=!1)}},rolarRelacionados(direcao){var _a;(_a=this.$refs.relacionadosModelo4)==null||_a.scrollBy({left:direcao*360,behavior:"smooth"})}},template:`
    <div class="fz-produto-conteudo fz-produto-modelo-4">
        <div v-if="store.erro" class="fz-produto-conteudo__erro p-4">
            <p-message severity="error" :closable="false">{{ store.erro }}</p-message>
        </div>

        <div v-else-if="produtoSomenteId && carregandoDados" class="fz-produto-conteudo__container container-fluid p-4">
            <fz-produto-modal-skeleton></fz-produto-modal-skeleton>
        </div>

        <template v-else-if="produto">
            <div class="fz-produto-modelo-4__principal">
                <aside class="fz-produto-modelo-4__midia">
                    <fz-produto-modal-carousel
                        ref="carousel"
                        :produto="produto"
                        :altura-fixa="false"
                        :miniaturas-horizontais="true"
                        @slide-change="handleSlideChange"
                    ></fz-produto-modal-carousel>
                </aside>

                <section class="fz-produto-modelo-4__compra">
                    <fz-produto-modelo4-resumo :produto="produto"></fz-produto-modelo4-resumo>

                    <fz-produto-modal-audio-descricao
                        v-if="dadosCompletos && produto.audio_descricao"
                        :audio-path="produto.audio_descricao"
                        :produto-id="produto.id"
                        :vendedor-nome="configsLoja.vendedorNome || ''"
                        :vendedor-foto="configsLoja.vendedorFoto || ''"
                        :total-plays="produto.total_plays_audio || 0"
                    ></fz-produto-modal-audio-descricao>

                    <fz-produto-modal-skeleton-detalhes v-if="carregandoDados"></fz-produto-modal-skeleton-detalhes>

                    <div v-else class="fz-produto-modelo-4__dados-completos">
                        <fz-produto-modelo4-desconto-progressivo :produto="produto"></fz-produto-modelo4-desconto-progressivo>

                        <div v-if="exibirAviseMeForm" class="fz-produto-modelo-4__avise-me">
                            <fz-produto-modal-avise-me-form :produto="produto"></fz-produto-modal-avise-me-form>
                        </div>

                        <section v-else-if="!produto.venda_externa && !configsLoja.precosRestritos" class="fz-produto-modelo-4__variacoes">
                            <div class="fz-produto-modelo-4__titulo-variacoes">
                                <strong>Escolha as variações</strong>
                            </div>

                            <fz-produto-kit-componentes
                                v-if="produto.is_kit || produto.tipo_produto === 'kit'"
                                :produto="produto"
                            ></fz-produto-kit-componentes>

                            <!-- Venda em Grade (hibrida com abas; quebrada colapsa para individual) -->
                            <template v-if="produto.grade && !isEmpty(produto.grade) && produto.grade_permitir_individual && !produto.grade_quebrada">
                                <fz-variacao-grade-com-abas
                                    :produto="produto"
                                    :catalogo-id="configsLoja.catalogoId"
                                    :carrinho="configsLoja.carrinho || {}"
                                    :configs-loja="configsLoja"
                                    :somente-orcamentos="configsLoja.somenteOrcamentos"
                                    :precos-restritos="configsLoja.precosRestritos"
                                    :exibir-preco="true"
                                    :exibir-sku="true"
                                    :exibir-divisoria="false"
                                    :exibir-descontos="true"
                                    :video-ativo="!isEmpty(produto.video)"
                                    :variacoes-isoladas="false"
                                    :tab-ativa="tabAtivaSubgrupos"
                                    :variacoes-destaque="variacoesDestaque"
                                ></fz-variacao-grade-com-abas>
                            </template>
                            <template v-else-if="produto.grade && !isEmpty(produto.grade) && !produto.grade_quebrada">
                                <fz-variacao-com-grade
                                    :produto="produto"
                                    :catalogo-id="configsLoja.catalogoId"
                                    :carrinho="configsLoja.carrinho || {}"
                                    :exibir-sku="true"
                                    :exibir-descontos="true"
                                    :video-ativo="!isEmpty(produto.video)"
                                    :variacoes-isoladas="false"
                                ></fz-variacao-com-grade>
                            </template>

                            <template v-else-if="produto.subgrupos_variacoes && !isEmpty(produto.subgrupos_variacoes)">
                                <fz-variacao-com-subgrupos-variacao
                                    :produto="produto"
                                    :catalogo-id="configsLoja.catalogoId"
                                    :carrinho="configsLoja.carrinho || {}"
                                    :somente-orcamentos="configsLoja.somenteOrcamentos"
                                    :precos-restritos="configsLoja.precosRestritos"
                                    :exibir-preco="true"
                                    :exibir-sku="true"
                                    :exibir-divisoria="false"
                                    :exibir-descontos="true"
                                    :video-ativo="!isEmpty(produto.video)"
                                    :variacoes-isoladas="false"
                                    :tab-ativa="tabAtivaSubgrupos"
                                    :variacoes-destaque="variacoesDestaque"
                                    :rolar-aba-ativa="deveRolarAbaAtiva()"
                                ></fz-variacao-com-subgrupos-variacao>
                            </template>

                            <template v-else-if="produto.variacoes && !isEmpty(produto.variacoes)">
                                <fz-variacao-com-variacao
                                    :produto="produto"
                                    :catalogo-id="configsLoja.catalogoId"
                                    :carrinho="configsLoja.carrinho || {}"
                                    :somente-orcamentos="configsLoja.somenteOrcamentos"
                                    :precos-restritos="configsLoja.precosRestritos"
                                    :exibir-preco="true"
                                    :exibir-sku="true"
                                    :exibir-divisoria="false"
                                    :exibir-descontos="true"
                                    :video-ativo="!isEmpty(produto.video)"
                                    :variacoes-destaque="variacoesDestaque"
                                ></fz-variacao-com-variacao>
                            </template>

                            <template v-else>
                                <fz-variacao-sem-variacao
                                    :produto="produto"
                                    :catalogo-id="configsLoja.catalogoId"
                                    :carrinho="configsLoja.carrinho || {}"
                                    :exibir-sku="true"
                                    :exibir-descontos="true"
                                ></fz-variacao-sem-variacao>
                            </template>
                        </section>

                        <fz-produto-modal-simulador-frete
                            v-if="!produtoIndisponivelEstoque && configsLoja.habilitarSimuladorFreteProduto"
                            :produto="produto"
                            :exibir-titulo="false"
                        >
                            <template #cabecalho>
                                <div class="fz-produto-modelo-4__frete-cabecalho">
                                    <span class="fz-produto-modelo-4__frete-icone"><i class="pi pi-truck"></i></span>
                                    <div>
                                        <strong>Calcule o frete</strong>
                                        <small>Informe seu CEP para consultar prazo e entrega.</small>
                                    </div>
                                </div>
                            </template>
                        </fz-produto-modal-simulador-frete>

                        <fz-produto-cupons
                            :cupons="configsLoja.cuponsDivulgaveis"
                            :produto="produto"
                        ></fz-produto-cupons>

                        <fz-produto-modal-footer :contexto="contexto" :produto="produto"></fz-produto-modal-footer>
                    </div>
                </section>
            </div>

            <div v-if="dadosCompletos" class="fz-produto-modelo-4__conteudo-inferior">
                <div class="fz-produto-modelo-4__informacoes-grid" :class="{ 'fz-produto-modelo-4__informacoes-grid--sem-informacoes': !temDescricaoProduto && !temGuiaMedidasProduto && !temWidgetsProduto }">
                    <main v-if="temDescricaoProduto || temGuiaMedidasProduto || temWidgetsProduto" class="fz-produto-modelo-4__informacoes">
                        <h2 class="fz-produto-modelo-4__titulo-secao">Informações do produto</h2>
                        <div v-if="(temDescricaoProduto ? 1 : 0) + (temGuiaMedidasProduto ? 1 : 0) + (temWidgetsProduto ? 1 : 0) > 1" class="fz-produto-modelo-4__abas-informacoes" role="tablist" aria-label="Informações do produto">
                            <button v-if="temDescricaoProduto" type="button" role="tab" :aria-selected="abaInformacoesExibida === 'descricao'" :class="{ 'fz-produto-modelo-4__aba--ativa': abaInformacoesExibida === 'descricao' }" @click="abaInformacoes = 'descricao'">Descrição do produto</button>
                            <button v-if="temGuiaMedidasProduto" type="button" role="tab" :aria-selected="abaInformacoesExibida === 'guia-medidas'" :class="{ 'fz-produto-modelo-4__aba--ativa': abaInformacoesExibida === 'guia-medidas' }" @click="abaInformacoes = 'guia-medidas'">Guia de medidas</button>
                            <button v-if="temWidgetsProduto" type="button" role="tab" :aria-selected="abaInformacoesExibida === 'widgets'" :class="{ 'fz-produto-modelo-4__aba--ativa': abaInformacoesExibida === 'widgets' }" @click="abaInformacoes = 'widgets'">Informações adicionais</button>
                        </div>
                        <section v-if="temDescricaoProduto && abaInformacoesExibida === 'descricao'" class="fz-produto-modelo-4__descricao">
                            <fz-produto-modal-descricao :descricao="produto.descricao" :produto-id="produto.id" :exibir-titulo="false"></fz-produto-modal-descricao>
                        </section>
                        <section v-if="temGuiaMedidasProduto && abaInformacoesExibida === 'guia-medidas'" class="fz-produto-modelo-4__guia-medidas">
                            <fz-produto-modal-guia-medidas :produto="produto" :exibir-titulo="false"></fz-produto-modal-guia-medidas>
                        </section>
                        <section v-if="temWidgetsProduto && abaInformacoesExibida === 'widgets'" class="fz-produto-modelo-4__widgets">
                            <fz-produto-modal-widgets :produto="produto" :exibir-titulo="false"></fz-produto-modal-widgets>
                        </section>
                    </main>

                    <aside v-if="temProdutosRelacionados" class="fz-produto-modelo-4__relacionados-laterais">
                        <section v-if="primeiroProdutoRelacionado" class="fz-produto-modelo-4__compre-junto">
                            <div class="fz-produto-modelo-4__titulo-lateral">
                                <h2>Compre junto</h2>
                            </div>
                            <div class="fz-produto-modelo-4__card-compre-junto">
                                <fz-produto :produto="primeiroProdutoRelacionado" v-bind="opcoesProdutoRelacionado" :exibir-slide-imagens="false"></fz-produto>
                            </div>
                        </section>

                        <section class="fz-produto-modelo-4__veja-tambem">
                            <div class="fz-produto-modelo-4__titulo-lateral">
                                <h2>Veja também</h2>
                            </div>
                            <div class="fz-produto-modelo-4__lista-veja-tambem">
                                <fz-produto
                                    v-for="produtoRelacionado in produtosVejaTambem"
                                    :key="produtoRelacionado.id"
                                    :produto="produtoRelacionado"
                                    v-bind="opcoesProdutoRelacionado"
                                    :exibir-slide-imagens="false"
                                    :ocultar-destaque="true"
                                ></fz-produto>
                            </div>
                        </section>
                    </aside>
                </div>

                <section v-if="configsLoja.exibirComentariosTelaProduto" class="fz-produto-modelo-4__interacao fz-produto-modelo-4__interacao--perguntas">
                    <div class="fz-produto-modelo-4__cabecalho-secao">
                        <h2>Perguntas e respostas</h2>
                    </div>
                    <fz-produto-modal-comentarios :produto="produto" :exibir-titulo="false" layout="modelo2"></fz-produto-modal-comentarios>
                </section>

                <section class="fz-produto-modelo-4__interacao fz-produto-modelo-4__interacao--avaliacoes">
                    <div class="fz-produto-modelo-4__cabecalho-secao">
                        <h2>Avaliações do produto</h2>
                    </div>
                    <fz-produto-avaliacoes :produto="produto" :exibir-titulo="false" layout="modelo2"></fz-produto-avaliacoes>
                </section>

                <section v-if="temProdutosRelacionados" class="fz-produto-modelo-4__aproveite-junto">
                    <div class="fz-produto-modelo-4__cabecalho-secao">
                        <h2>Aproveite e compre junto</h2>
                    </div>
                    <div class="fz-produto-modelo-4__carrossel-relacionados">
                        <button
                            v-if="produtosRelacionados.length > 1"
                            type="button"
                            class="fz-produto-modelo-4__seta-relacionados fz-produto-modelo-4__seta-relacionados--anterior"
                            aria-label="Produtos relacionados anteriores"
                            @click="rolarRelacionados(-1)"
                        ><i class="pi pi-chevron-left"></i></button>
                        <div ref="relacionadosModelo4" class="fz-produto-modelo-4__lista-relacionados">
                            <fz-produto
                                v-for="produtoRelacionado in produtosRelacionados"
                                :key="produtoRelacionado.id"
                                :produto="produtoRelacionado"
                                v-bind="opcoesProdutoRelacionado"
                            ></fz-produto>
                        </div>
                        <button
                            v-if="produtosRelacionados.length > 1"
                            type="button"
                            class="fz-produto-modelo-4__seta-relacionados fz-produto-modelo-4__seta-relacionados--proxima"
                            aria-label="Próximos produtos relacionados"
                            @click="rolarRelacionados(1)"
                        ><i class="pi pi-chevron-right"></i></button>
                    </div>
                </section>
            </div>
        </template>

        <div v-else-if="carregandoDados" class="p-4">
            <fz-produto-modal-skeleton></fz-produto-modal-skeleton>
        </div>

        <fz-dialog-regras-precos></fz-dialog-regras-precos>
        <fz-dialog-video-externo></fz-dialog-video-externo>
    </div>
    `},FZComponents.ProdutoConteudo={components:{"fz-produto-conteudo-modelo1":FZComponents.ProdutoConteudoModelo1,"fz-produto-conteudo-modelo2":FZComponents.ProdutoConteudoModelo2,"fz-produto-conteudo-modelo3":FZComponents.ProdutoConteudoModelo3,"fz-produto-conteudo-modelo4":FZComponents.ProdutoConteudoModelo4},inject:["configsLoja"],props:{produtoInicial:{type:Object,required:!0},carregarDadosCompletos:{type:Boolean,default:!0},contexto:{type:String,default:"dialog-drawer",validator:value=>["dialog-drawer","pagina"].includes(value)}},emits:["produto-carregado","erro-carregamento","estatistica-enviada","voltar"],computed:{componenteModelo(){const modelos={2:"fz-produto-conteudo-modelo2",3:"fz-produto-conteudo-modelo3",4:"fz-produto-conteudo-modelo4"};return String(this.configsLoja.modeloPaginaProduto)==="custom"?typeof window!="undefined"&&window.FZ_PRODUTO_LAYOUT_VALID===!0?"fz-produto-conteudo-custom":"fz-produto-conteudo-modelo1":modelos[String(this.configsLoja.modeloPaginaProduto)]||"fz-produto-conteudo-modelo1"}},template:`
    <component
        :is="componenteModelo"
        :produto-inicial="produtoInicial"
        :carregar-dados-completos="carregarDadosCompletos"
        :contexto="contexto"
        @produto-carregado="$emit('produto-carregado', $event)"
        @erro-carregamento="$emit('erro-carregamento', $event)"
        @estatistica-enviada="$emit('estatistica-enviada', $event)"
        @voltar="$emit('voltar')"
    ></component>
    `},FZComponents.ProdutoDialogDrawer={components:{"p-dialog":PrimeVue.Dialog,"p-drawer":PrimeVue.Drawer,"p-button":PrimeVue.Button,"fz-produto-conteudo":FZComponents.ProdutoConteudo},mixins:[ProdutoConteudoMixin],data(){return{isMobile:!1,navegando:!1,fzScrollbarDrag:null,fzScrollbarSyncRaf:null,fzResizeTimer:null,fzLigacaoAdiada:null,fzLarguraJanela:0,fzScrollRefs:null}},computed:{visible:{get(){return this.dialogDrawerStore.isOpen},set(value){value||(this.dialogDrawerStore.isOpen=!1)}},produtoAtual(){return this.conteudoStore.produtoInicial},useDrawer(){return this.isMobile},useDialog(){return!this.isMobile},temNavegacao(){return this.visible&&this.dialogDrawerStore.ordemProdutos&&this.dialogDrawerStore.ordemProdutos.length>1},temProdutoAnterior(){return this.temNavegacao&&this.dialogDrawerStore.indiceProdutoAtual>0},temProximoProduto(){return this.temNavegacao&&this.dialogDrawerStore.indiceProdutoAtual<this.dialogDrawerStore.ordemProdutos.length-1},posicaoAtual(){return this.temNavegacao?`${Math.max(1,this.dialogDrawerStore.indiceProdutoAtual+1)} de ${this.dialogDrawerStore.ordemProdutos.length}`:""},proximoDoFimDaLista(){return this.temNavegacao&&this.dialogDrawerStore.ordemProdutos.length-this.dialogDrawerStore.indiceProdutoAtual<=3}},watch:{"dialogDrawerStore.isOpen"(isOpen){isOpen?this.aoAbrirDialogDrawer():this.aoFecharDialogDrawer()}},mounted(){this.checkViewport(),this.fzLarguraJanela=typeof window!="undefined"?window.innerWidth:0,window.addEventListener("hashchange",this.handleHashChange),window.addEventListener("keydown",this.handleKeydown),window.addEventListener("resize",this.aoRedimensionarJanela),window.addEventListener("orientationchange",this.aoGirarTela),this.handleHashChange()},beforeUnmount(){window.removeEventListener("hashchange",this.handleHashChange),window.removeEventListener("keydown",this.handleKeydown),window.removeEventListener("resize",this.aoRedimensionarJanela),window.removeEventListener("orientationchange",this.aoGirarTela),this.cancelarLigacaoAdiada(),this.cancelarSyncAgendado(),this.fzResizeTimer&&(clearTimeout(this.fzResizeTimer),this.fzResizeTimer=null),this.desligarModalScrollbar()},methods:{checkViewport(){this.isMobile=window.innerWidth<=991},aoRedimensionarJanela(){typeof window!="undefined"&&(window.innerWidth===this.fzLarguraJanela&&this.fzResizeTimer||(this.fzResizeTimer&&clearTimeout(this.fzResizeTimer),this.fzResizeTimer=setTimeout(()=>{this.fzResizeTimer=null,typeof window!="undefined"&&window.innerWidth!==this.fzLarguraJanela&&(this.fzLarguraJanela=window.innerWidth,this.checkViewport(),this.invalidarRefsScrollbar(),this.agendarSyncScrollbar())},150)))},aoGirarTela(){this.checkViewport(),typeof window!="undefined"&&(this.fzLarguraJanela=window.innerWidth),this.invalidarRefsScrollbar(),this.agendarSyncScrollbar()},handleHashChange(){const match=window.location.hash.match(/#produto(\d+)/);if(match){const produtoId=match[1];this.dialogDrawerStore.ordemProdutos.unshift(produtoId),this.conteudoStore.produtoId!==produtoId&&window.abrirModalProdutoVue({id:produtoId})}else this.dialogDrawerStore.isOpen&&this.fecharDialogDrawer()},handleKeydown(event){if(!this.dialogDrawerStore.isOpen)return;const tagName=event.target.tagName.toLowerCase();tagName==="input"||tagName==="textarea"||(event.key==="ArrowLeft"?(event.preventDefault(),this.irParaProdutoAnterior()):event.key==="ArrowRight"&&(event.preventDefault(),this.irParaProximoProduto()))},verificarCarregarMaisProdutos(){if(this.proximoDoFimDaLista){const event=new CustomEvent("fz-carregar-mais-produtos");window.dispatchEvent(event)}},async irParaProdutoAnterior(){if(!this.temProdutoAnterior||this.navegando)return;const novoIndice=this.dialogDrawerStore.indiceProdutoAtual-1,produtoId=this.dialogDrawerStore.ordemProdutos[novoIndice];if(!produtoId)return;this.navegando=!0,this.dialogDrawerStore.indiceProdutoAtual=novoIndice,await Vue.nextTick();const produtoCache=this.conteudoStore.cacheProdutos[produtoId];produtoCache?window.abrirModalProdutoVue(produtoCache,!1):window.abrirModalProdutoVue({id:produtoId}),await new Promise(resolve=>setTimeout(resolve,100)),this.navegando=!1;const containerAnterior=this.obterContainerRolagemModal();containerAnterior&&(containerAnterior.scrollTop=0),this.invalidarRefsScrollbar(),this.agendarSyncScrollbar()},async irParaProximoProduto(){if(!this.temProximoProduto||this.navegando)return;const novoIndice=this.dialogDrawerStore.indiceProdutoAtual+1,produtoId=this.dialogDrawerStore.ordemProdutos[novoIndice];if(!produtoId)return;this.navegando=!0,this.dialogDrawerStore.indiceProdutoAtual=novoIndice,this.verificarCarregarMaisProdutos(),await Vue.nextTick();const produtoCache=this.conteudoStore.cacheProdutos[produtoId];produtoCache?window.abrirModalProdutoVue(produtoCache,!1):window.abrirModalProdutoVue({id:produtoId},!1),await new Promise(resolve=>setTimeout(resolve,100)),this.navegando=!1;const containerProximo=this.obterContainerRolagemModal();containerProximo&&(containerProximo.scrollTop=0),this.invalidarRefsScrollbar(),this.agendarSyncScrollbar()},aoAbrirDialogDrawer(){var _a;(_a=this.produtoAtual)!=null&&_a.id&&(window.location.hash=`produto${this.produtoAtual.id}`);const scrollContainer=this.obterContainerRolagemModal();scrollContainer&&(scrollContainer.scrollTop=0),this.invalidarRefsScrollbar(),this.agendarLigacaoScrollbar()},agendarLigacaoScrollbar(){this.cancelarLigacaoAdiada();const ligar=()=>{this.fzLigacaoAdiada=null,this.ligarModalScrollbar();const container=this.obterContainerRolagemModal();container&&(container.scrollTop=0),this.agendarSyncScrollbar()};typeof window!="undefined"&&typeof window.requestIdleCallback=="function"?this.fzLigacaoAdiada={tipo:"idle",id:window.requestIdleCallback(ligar,{timeout:800})}:this.fzLigacaoAdiada={tipo:"timeout",id:setTimeout(ligar,0)}},cancelarLigacaoAdiada(){if(this.fzLigacaoAdiada){try{this.fzLigacaoAdiada.tipo==="idle"&&typeof window!="undefined"&&typeof window.cancelIdleCallback=="function"?window.cancelIdleCallback(this.fzLigacaoAdiada.id):clearTimeout(this.fzLigacaoAdiada.id)}catch(e){}this.fzLigacaoAdiada=null}},agendarSyncScrollbar(){if(typeof window=="undefined"||typeof window.requestAnimationFrame!="function"){this.syncModalScrollbar();return}this.fzScrollbarSyncRaf===null&&(this.fzScrollbarSyncRaf=window.requestAnimationFrame(()=>{this.fzScrollbarSyncRaf=null,this.syncModalScrollbar()}))},cancelarSyncAgendado(){this.fzScrollbarSyncRaf!==null&&typeof window!="undefined"&&typeof window.cancelAnimationFrame=="function"&&window.cancelAnimationFrame(this.fzScrollbarSyncRaf),this.fzScrollbarSyncRaf=null},invalidarRefsScrollbar(){this.fzScrollRefs=null},aoFecharDialogDrawer(){this.cancelarLigacaoAdiada(),this.cancelarSyncAgendado(),this.desligarModalScrollbar(),window.location.hash.startsWith("#produto")&&history.replaceState("",document.title,window.location.pathname),setTimeout(()=>{this.conteudoStore.produtoId=null,this.conteudoStore.produtoInicial=null,this.conteudoStore.dadosCompletos=null,this.conteudoStore.quantidadesSelecionadas={},this.conteudoStore.erro=null},300)},fecharDialogDrawer(){this.dialogDrawerStore.isOpen=!1},obterContainerRolagemModal(){return typeof document=="undefined"?null:document.querySelector(this.isMobile?".fz-produto-dialog-drawer .fz-produto-conteudo":".p-dialog-content")},obterScrollbarModal(){if(typeof document=="undefined")return null;const seletor=this.isMobile?".fz-produto-dialog-drawer .fz-produto-modal-scrollbar--mobile":".fz-produto-dialog-drawer .fz-produto-modal-scrollbar--desktop";return document.querySelector(seletor)},obterThumbScrollbarModal(){const scrollbar=this.obterScrollbarModal();return scrollbar?scrollbar.querySelector(".fz-produto-modal-scrollbar__thumb"):null},syncModalScrollbar(){const scrollContainer=this.obterContainerRolagemModal(),scrollbar=this.obterScrollbarModal(),thumb=this.obterThumbScrollbarModal();if(!scrollContainer||!scrollbar||!thumb)return;const trackHeight=scrollbar.clientHeight,viewportHeight=scrollContainer.clientHeight,contentHeight=scrollContainer.scrollHeight;if(!trackHeight||!viewportHeight||!contentHeight)return;const maxScroll=Math.max(0,contentHeight-viewportHeight),ratio=contentHeight>0?viewportHeight/contentHeight:1,thumbHeight=Math.max(46,Math.min(trackHeight,trackHeight*ratio)),maxThumbTop=Math.max(0,trackHeight-thumbHeight),thumbTop=maxScroll>0?scrollContainer.scrollTop/maxScroll*maxThumbTop:0;thumb.style.height=`${thumbHeight}px`,thumb.style.transform=`translateY(${thumbTop}px)`,scrollbar.style.opacity=maxScroll>0?"1":"0"},aoRolarModalProduto(){this.agendarSyncScrollbar()},obterRefsScrollbar(){if(this.fzScrollRefs)return this.fzScrollRefs;const scrollContainer=this.obterContainerRolagemModal(),scrollbar=this.obterScrollbarModal(),thumb=scrollbar?scrollbar.querySelector(".fz-produto-modal-scrollbar__thumb"):null;return!scrollContainer||!scrollbar||!thumb?null:(this.fzScrollRefs={scrollContainer,scrollbar,thumb},this.fzScrollRefs)},ligarModalScrollbar(){this.ancorarElementosForaDaRolagem();const refs=this.obterRefsScrollbar();if(!refs)return;const{scrollContainer,scrollbar,thumb}=refs;scrollContainer.__fzScrollbarLigada||(scrollContainer.addEventListener("scroll",this.aoRolarModalProduto,{passive:!0}),scrollContainer.__fzScrollbarLigada=!0),thumb.__fzDragLigado||(thumb.addEventListener("pointerdown",this.aoIniciarArrastoThumb),thumb.__fzDragLigado=!0),window.__fzThumbDragLigado||(window.addEventListener("pointermove",this.aoArrastarThumb,{passive:!0}),window.addEventListener("pointerup",this.aoSoltarThumb),window.addEventListener("pointercancel",this.aoSoltarThumb),window.__fzThumbDragLigado=!0),scrollbar.__fzCliqueLigado||(scrollbar.addEventListener("click",this.aoClicarTrilhaScrollbar),scrollbar.__fzCliqueLigado=!0),this.syncModalScrollbar()},desligarModalScrollbar(){if(typeof document=="undefined")return;document.querySelectorAll(".p-dialog-content, .p-drawer-content, .fz-produto-dialog-drawer .fz-produto-conteudo").forEach(container=>{container.__fzScrollbarLigada&&(container.removeEventListener("scroll",this.aoRolarModalProduto),container.__fzScrollbarLigada=!1)}),this.fzScrollbarDrag=null,this.invalidarRefsScrollbar()},aoIniciarArrastoThumb(event){const scrollContainer=this.obterContainerRolagemModal(),thumb=this.obterThumbScrollbarModal();if(!(!scrollContainer||!thumb)){this.fzScrollbarDrag={inicioY:event.clientY,scrollInicial:scrollContainer.scrollTop};try{thumb.setPointerCapture(event.pointerId)}catch(e){}}},aoArrastarThumb(event){if(!this.fzScrollbarDrag)return;const refs=this.obterRefsScrollbar();if(!refs)return;const{scrollContainer,scrollbar,thumb}=refs;try{if(event.pointerId!==void 0&&thumb.hasPointerCapture&&!thumb.hasPointerCapture(event.pointerId))return}catch(e){}const trackHeight=scrollbar.clientHeight,thumbHeight=thumb.offsetHeight,maxThumbTop=Math.max(1,trackHeight-thumbHeight),maxScroll=Math.max(0,scrollContainer.scrollHeight-scrollContainer.clientHeight),deltaY=event.clientY-this.fzScrollbarDrag.inicioY;scrollContainer.scrollTop=this.fzScrollbarDrag.scrollInicial+deltaY/maxThumbTop*maxScroll},aoSoltarThumb(event){const thumb=this.obterThumbScrollbarModal();if(thumb&&event&&event.pointerId!==void 0)try{thumb.hasPointerCapture&&thumb.hasPointerCapture(event.pointerId)&&thumb.releasePointerCapture(event.pointerId)}catch(e){}this.fzScrollbarDrag=null},aoClicarTrilhaScrollbar(event){const thumb=this.obterThumbScrollbarModal();if(event.target===thumb)return;const scrollbar=this.obterScrollbarModal(),scrollContainer=this.obterContainerRolagemModal();if(!scrollbar||!scrollContainer)return;const rect=scrollbar.getBoundingClientRect();if(!rect.height)return;const ratio=(event.clientY-rect.top)/rect.height;scrollContainer.scrollTo({top:ratio*(scrollContainer.scrollHeight-scrollContainer.clientHeight),behavior:"smooth"})},ancorarElementosForaDaRolagem(){if(typeof document!="undefined")try{if(this.isMobile){const drawer=document.querySelector(".fz-produto-dialog-drawer.fz-produto-drawer"),botao=document.querySelector(".fz-produto-dialog-drawer__btn-fechar--mobile"),scrollbar=document.querySelector(".fz-produto-modal-scrollbar--mobile");drawer&&botao&&botao.parentElement!==drawer&&drawer.appendChild(botao),drawer&&scrollbar&&scrollbar.parentElement!==drawer&&drawer.appendChild(scrollbar)}else{const dialog=document.querySelector(".fz-produto-dialog-drawer.produto-modal-dialog .p-dialog"),botao=document.querySelector(".fz-produto-dialog-drawer__btn-fechar--desktop"),scrollbar=document.querySelector(".fz-produto-modal-scrollbar--desktop");dialog&&botao&&botao.parentElement!==dialog&&dialog.appendChild(botao),dialog&&scrollbar&&scrollbar.parentElement!==dialog&&dialog.appendChild(scrollbar)}}catch(e){}}},template:`
    <!-- Drawer for Mobile/Tablet (<= 991px, alinhado ao CSS) -->
    <p-drawer
        v-if="useDrawer"
        v-model:visible="visible"
        position="full"
        :dismissable="true"
        :closable="false"
        :block-scroll="true"
        :style="{ height: '100vh' }"
        :base-z-index="100000"
        class="fz-produto-dialog-drawer fz-produto-drawer"
    >
        <template #container="{ closeCallback }">
            <!-- Close Button Mobile -->
            <button
                type="button"
                class="fz-produto-dialog-drawer__btn-fechar fz-produto-dialog-drawer__btn-fechar--mobile"
                @click="fecharDialogDrawer"
                aria-label="Fechar"
            >
                <i class="ti-close"></i>
            </button>

            <!-- FZ-5729: scrollbar visual fiel (track abaixo do fechar, sem setas) -->
            <div class="fz-produto-modal-scrollbar fz-produto-modal-scrollbar--mobile" aria-hidden="true">
                <div class="fz-produto-modal-scrollbar__track">
                    <div class="fz-produto-modal-scrollbar__thumb"></div>
                </div>
            </div>

            <fz-produto-conteudo
                v-if="produtoAtual"
                :key="produtoAtual.id"
                :produto-inicial="produtoAtual"
                contexto="dialog-drawer"
            ></fz-produto-conteudo>
        </template>
    </p-drawer>

    <!-- Dialog for Desktop (>= 992px) -->
    <p-dialog
        v-else
        v-model:visible="visible"
        :modal="true"
        :dismissable-mask="true"
        :draggable="false"
        :closable="false"
        :style="{ width: '95vw', maxWidth: '1500px' }"
        :content-style="{ padding: 0 }"
        :base-z-index="100000"
        class="fz-produto-dialog-drawer fz-produto-dialog produto-modal-dialog"
    >
        <template #header>
            <div></div>
        </template>

        <!-- Close Button Desktop -->
        <button
            type="button"
            class="fz-produto-dialog-drawer__btn-fechar fz-produto-dialog-drawer__btn-fechar--desktop"
            @click="fecharDialogDrawer"
            aria-label="Fechar"
        >
            <i class="ti-close"></i>
        </button>

        <!-- FZ-5729: scrollbar visual fiel (track abaixo do fechar, sem setas) -->
        <div class="fz-produto-modal-scrollbar fz-produto-modal-scrollbar--desktop" aria-hidden="true">
            <div class="fz-produto-modal-scrollbar__track">
                <div class="fz-produto-modal-scrollbar__thumb"></div>
            </div>
        </div>

        <fz-produto-conteudo
            v-if="produtoAtual"
            :key="produtoAtual.id"
            :produto-inicial="produtoAtual"
            contexto="dialog-drawer"
        ></fz-produto-conteudo>
    </p-dialog>

    <!-- Navigation Arrows (only for desktop dialog) -->
    <p-button
        v-if="useDialog && temProdutoAnterior"
        class="fz-produto-dialog-drawer__btn-navegar fz-produto-dialog-drawer__btn-navegar--anterior"
        icon="pi pi-chevron-left"
        @click="irParaProdutoAnterior"
        aria-label="Produto anterior"
        title="Produto anterior (←)"
        rounded
        size="large"
        severity="secondary"
    ></p-button>

    <p-button
        v-if="useDialog && temProximoProduto"
        class="fz-produto-dialog-drawer__btn-navegar fz-produto-dialog-drawer__btn-navegar--proximo"
        icon="pi pi-chevron-right"
        @click="irParaProximoProduto"
        aria-label="Próximo produto"
        title="Próximo produto (→)"
        rounded
        size="large"
        severity="secondary"
    ></p-button>

    <!-- Position Counter -->
    <div v-if="useDialog && temNavegacao" class="fz-produto-dialog-drawer__contador-posicao">
        {{ posicaoAtual }}
    </div>
    `},window.abrirModalProdutoVue=function(produto,recalcularIndice=!0){if(!produto||!produto.id){console.error("Produto inválido passado para abrirModalProdutoVue:",produto);return}ProdutoConteudoStore.dadosCompletos=null,ProdutoConteudoStore.erro=null,ProdutoConteudoStore.produtoId=produto.id,ProdutoConteudoStore.produtoInicial=produto,ProdutoDialogDrawerStore.isOpen=!0,ProdutoDialogDrawerStore.ordemProdutos.length>0&&recalcularIndice&&(ProdutoDialogDrawerStore.indiceProdutoAtual=ProdutoDialogDrawerStore.ordemProdutos.indexOf(produto.id))};

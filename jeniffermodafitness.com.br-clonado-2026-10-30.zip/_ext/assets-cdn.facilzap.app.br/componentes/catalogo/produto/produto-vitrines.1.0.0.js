FZComponents.SimuladorParcelasMelhorDesconto={components:{},mixins:[ProdutoBaseMixin],props:{produto:{type:Object,required:!0},simulacao:{type:Object,default:null},abrirModal:{type:Boolean,default:!1},alinhamento:{type:String,default:"centro"},variacao:{type:String,default:"completo"},quantidadeMinima:{type:Number,default:0}},template:`
    <div v-if="exibirSimulacao" class="fz-simulador-parcelas-desconto" :class="[classAlinhamento, { 'fz-simulador-parcelas-desconto--compacto': variacao == 'compacto' }]" :style="abrirModal ? 'cursor:pointer' : ''" @click="abrirModal ? abrirModalSimulador() : null">
        <template v-if="variacao == 'compacto'">
            <span class="fz-simulador-parcelas-desconto__compacto-label">A partir de</span>
            <strong class="fz-simulador-parcelas-desconto__valor">R$ {{ formatarPreco(simulacao.melhor_desconto.valor) }}</strong>
            <span class="fz-simulador-parcelas-desconto__compacto-pagamento">no {{ formaPagamentoMelhorDesconto }}</span>
            <span v-if="quantidadeMinima > 0" class="fz-simulador-parcelas-desconto__compacto-quantidade">em {{ quantidadeMinima }}+ peças</span>
        </template>

        <template v-else>
            <template v-if="variacao == 'completo'">
                ou
            </template>
            <strong class="fz-simulador-parcelas-desconto__valor">R$ {{ formatarPreco(simulacao.melhor_desconto.valor) }}</strong> no
            <svg v-if="variacao == 'completo' || variacao == 'destaque'" class="fz-simulador-parcelas-desconto__icone-pix align-middle" viewBox="0 0 194 194" aria-label="Pix">
                <path d="M147.04 144.34c-7.02 0-13.6-2.7-18.57-7.67L101.7 109.9c-1.84-1.84-5.18-1.84-7.02 0L67.8 136.78c-4.97 4.97-11.55 7.67-18.57 7.67h-5.29l34.01 34.01c10.58 10.58 27.85 10.58 38.43 0l34.11-34.11h-3.45Z"></path>
                <path d="M49.12 49.55c7.02 0 13.6 2.7 18.57 7.67l26.88 26.88c1.94 1.94 5.07 1.94 7.02 0l26.88-26.77c4.97-4.97 11.55-7.67 18.57-7.67h3.24l-34.11-34.11c-10.58-10.58-27.85-10.58-38.43 0L43.72 49.55h5.4Z"></path>
                <path d="m178.45 77.84-20.62-20.62c-.43.22-.97.32-1.51.32h-9.39c-4.86 0-9.61 1.94-12.95 5.4L107.2 89.71c-2.48 2.48-5.83 3.78-9.07 3.78-3.35 0-6.59-1.3-9.07-3.78L62.18 62.83c-3.45-3.45-8.2-5.4-12.95-5.4H37.68c-.54 0-.97-.11-1.4-.32L15.55 77.84c-10.58 10.58-10.58 27.85 0 38.43l20.62 20.62c.43-.22.86-.32 1.4-.32h11.55c4.86 0 9.61-1.94 12.95-5.4l26.88-26.88c4.86-4.86 13.39-4.86 18.24 0l26.77 26.77c3.45 3.45 8.2 5.4 12.95 5.4h9.39c.54 0 .97.11 1.51.32l20.62-20.62c10.58-10.58 10.58-27.85 0-38.43Z"></path>
            </svg>
            <b>PIX</b>
            <template v-if="variacao == 'completo' || variacao == 'destaque'">
                <br/>com
                <span class="fz-simulador-parcelas-desconto__badge badge bg-success preco_promo_badge">{{ Math.floor(simulacao.melhor_desconto.desconto) }}% de desconto</span>
            </template>
        </template>
    </div>
    `,computed:{exibirSimulacao(){return this.simulacao&&this.simulacao.exibir_simulador&&this.simulacao.melhor_desconto&&this.simulacao.melhor_desconto.desconto},classAlinhamento(){return{centro:"text-center",esquerda:"text-left",direita:"text-right"}[this.alinhamento]||"text-center"},formaPagamentoMelhorDesconto(){var _a,_b;const nomes={pix:"PIX",boleto:"Boleto"},idFormaPagamento=(_b=(_a=this.simulacao)==null?void 0:_a.melhor_desconto)==null?void 0:_b.id;return nomes[idFormaPagamento]||idFormaPagamento||"PIX"}}},FZComponents.SimuladorParcelasMelhorParcelamento={components:{},mixins:[ProdutoBaseMixin],props:{produto:{type:Object,required:!0},simulacao:{type:Object,default:null},abrirModal:{type:Boolean,default:!1},alinhamento:{type:String,default:"centro"},variacao:{type:String,default:"completo"},modeloIcones:{type:String,default:"padrao",validator:value=>["padrao","svg"].includes(value)},mostrarLabelFormasPagamento:{type:Boolean,default:!1},ocultarMelhorParcelamento:{type:Boolean,default:!1},mostrarIcones:{type:Boolean,default:!0}},template:`
    <div v-if="exibirSimulacao" class="fz-simulador-parcelas-parcelamento">
        <!-- Ícones dos métodos de pagamento -->
        <span
            v-if="mostrarLabelFormasPagamento && variacao == 'completo' && metodosAceitosFormatados.length > 0"
            class="fz-simulador-parcelas-parcelamento__label">
            Formas de pagamento
        </span>
        <div class="fz-simulador-parcelas-parcelamento__icones mb-1 d-flex align-items-center"
            v-if="mostrarIcones && variacao == 'completo'"
             :class="classAlinhamentoIcones"
             :style="abrirModal ? 'cursor:pointer' : ''"
             @click="abrirModal ? abrirModalSimulador() : null">
            <span
                 v-if="metodosAceitosFormatados.includes('pix')"
                 class="fz-simulador-parcelas-parcelamento__icone fz-simulador-parcelas-parcelamento__icone--svg fz-simulador-parcelas-parcelamento__icone--pix"
                 role="img"
                 aria-label="PIX">
                <svg viewBox="0 0 194 194" aria-hidden="true" focusable="false">
                    <path d="M147.04 144.34c-7.02 0-13.6-2.7-18.57-7.67L101.7 109.9c-1.84-1.84-5.18-1.84-7.02 0L67.8 136.78c-4.97 4.97-11.55 7.67-18.57 7.67h-5.29l34.01 34.01c10.58 10.58 27.85 10.58 38.43 0l34.11-34.11h-3.45Z"></path>
                    <path d="M49.12 49.55c7.02 0 13.6 2.7 18.57 7.67l26.88 26.88c1.94 1.94 5.07 1.94 7.02 0l26.88-26.77c4.97-4.97 11.55-7.67 18.57-7.67h3.24l-34.11-34.11c-10.58-10.58-27.85-10.58-38.43 0L43.72 49.55h5.4Z"></path>
                    <path d="m178.45 77.84-20.62-20.62c-.43.22-.97.32-1.51.32h-9.39c-4.86 0-9.61 1.94-12.95 5.4L107.2 89.71c-2.48 2.48-5.83 3.78-9.07 3.78-3.35 0-6.59-1.3-9.07-3.78L62.18 62.83c-3.45-3.45-8.2-5.4-12.95-5.4H37.68c-.54 0-.97-.11-1.4-.32L15.55 77.84c-10.58 10.58-10.58 27.85 0 38.43l20.62 20.62c.43-.22.86-.32 1.4-.32h11.55c4.86 0 9.61-1.94 12.95-5.4l26.88-26.88c4.86-4.86 13.39-4.86 18.24 0l26.77 26.77c3.45 3.45 8.2 5.4 12.95 5.4h9.39c.54 0 .97.11 1.51.32l20.62-20.62c10.58-10.58 10.58-27.85 0-38.43Z"></path>
                </svg>
            </span>
            <span
                 v-if="metodosAceitosFormatados.includes('cartao_credito') && modeloIcones == 'svg'"
                 class="fz-simulador-parcelas-parcelamento__icone fz-simulador-parcelas-parcelamento__icone--svg"
                 role="img"
                 aria-label="Cartão de crédito">
                <svg viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                    <rect x="2" y="5" width="20" height="14" rx="2"/>
                    <path d="M2 10h20M6 15h4"/>
                </svg>
            </span>
            <img v-else-if="metodosAceitosFormatados.includes('cartao_credito')"
                 src="https://assets.facilzap.app.br/logo-cartao-64.png"
                 loading="lazy"
                 class="fz-simulador-parcelas-parcelamento__icone"
                 style="width:28px;height:19px;"
                 width="28"
                 height="19"
                 alt="Cartão de Crédito" />
            <span
                 v-if="metodosAceitosFormatados.includes('boleto') && modeloIcones == 'svg'"
                 class="fz-simulador-parcelas-parcelamento__icone fz-simulador-parcelas-parcelamento__icone--svg"
                 role="img"
                 aria-label="Boleto">
                <svg viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                    <path d="M4 3v18M7 3v18M10 3v18M14 3v18M17 3v18M20 3v18"/>
                </svg>
            </span>
            <img v-else-if="metodosAceitosFormatados.includes('boleto')"
                 src="https://assets.facilzap.app.br/logo-boleto-86.png"
                 loading="lazy"
                 class="fz-simulador-parcelas-parcelamento__icone"
                 style="width:24px;height:18px;"
                 width="24"
                 height="18"
                 alt="Boleto" />
            <img v-if="metodosAceitosFormatados.includes('crypto')"
                 src="https://assets.facilzap.app.br/crypto-logo.png"
                 loading="lazy"
                 class="fz-simulador-parcelas-parcelamento__icone"
                 style="width:22px;height:22px;"
                 width="22"
                 height="22"
                 alt="Boleto" />
            <i v-if="metodosAceitosFormatados.includes('outros') && metodosAceitosFormatados.length > 1"
               class="fz-simulador-parcelas-parcelamento__icone-mais ti-plus f-16 text-success"></i>
        </div>

        <!-- Informações de parcelamento -->
        <div v-if="!ocultarMelhorParcelamento" class="fz-simulador-parcelas-parcelamento__info" :class="classAlinhamentoIcones" :style="abrirModal ? 'cursor:pointer' : ''" @click="abrirModal ? abrirModalSimulador() : null">
            <strong>{{ simulacao.melhor_parcelamento.parcela }}x</strong> de
            <strong>R$ {{ formatarPreco(simulacao.melhor_parcelamento.valor_parcela) }}</strong>
            <strong v-if="simulacao.melhor_parcelamento.tipo_juros == 'sem_juros'"> sem juros</strong>
            <template v-if="simulacao.melhor_parcelamento.id == 'cartao_credito'">
                no <strong>Cartão</strong>
            </template>
            <template v-else-if="simulacao.melhor_parcelamento.id == 'boleto'">
                no <strong>Boleto</strong>
            </template>
        </div>
    </div>
    `,computed:{exibirSimulacao(){return this.simulacao&&this.simulacao.exibir_simulador&&this.simulacao.melhor_parcelamento&&this.simulacao.melhor_parcelamento.parcela},classAlinhamentoIcones(){return{centro:"justify-content-center text-center",esquerda:"justify-content-left text-left",direita:"justify-content-end text-right",modal:"justify-content-end justify-content-left"}[this.alinhamento]||"justify-content-center"},metodosAceitosFormatados(){return this.simulacao&&this.simulacao.metodos_aceitos?Array.isArray(this.simulacao.metodos_aceitos)?this.simulacao.metodos_aceitos:Object.values(this.simulacao.metodos_aceitos):[]}}},FZComponents.ProdutoFormasPagamento={mixins:[ProdutoBaseMixin],props:{produto:{type:Object,required:!0},simulacao:{type:Object,default:null},layout:{type:String,default:"modelo1",validator:value=>["modelo1","modelo2"].includes(value)}},computed:{metodosAceitos(){var _a;return(_a=this.simulacao)!=null&&_a.metodos_aceitos?Array.isArray(this.simulacao.metodos_aceitos)?this.simulacao.metodos_aceitos:Object.values(this.simulacao.metodos_aceitos):[]},exibir(){var _a;return((_a=this.simulacao)==null?void 0:_a.exibir_simulador)&&this.metodosAceitos.length>0}},template:`
    <button
        v-if="exibir"
        type="button"
        class="fz-produto-formas-pagamento"
        :class="'fz-produto-formas-pagamento--' + layout"
        aria-label="Ver mais formas de pagamento"
        @click="abrirModalSimulador"
    >
        <span class="fz-produto-formas-pagamento__icones" aria-hidden="true">
            <svg v-if="metodosAceitos.includes('cartao_credito')" viewBox="0 0 24 24">
                <rect x="2.5" y="5" width="19" height="14" rx="2.5"></rect>
                <path d="M2.5 9h19M6 15h4"></path>
            </svg>
            <svg v-if="metodosAceitos.includes('pix')" class="fz-produto-formas-pagamento__icone-pix" viewBox="0 0 194 194">
                <path d="M147.04 144.34c-7.02 0-13.6-2.7-18.57-7.67L101.7 109.9c-1.84-1.84-5.18-1.84-7.02 0L67.8 136.78c-4.97 4.97-11.55 7.67-18.57 7.67h-5.29l34.01 34.01c10.58 10.58 27.85 10.58 38.43 0l34.11-34.11h-3.45Z"></path>
                <path d="M49.12 49.55c7.02 0 13.6 2.7 18.57 7.67l26.88 26.88c1.94 1.94 5.07 1.94 7.02 0l26.88-26.77c4.97-4.97 11.55-7.67 18.57-7.67h3.24l-34.11-34.11c-10.58-10.58-27.85-10.58-38.43 0L43.72 49.55h5.4Z"></path>
                <path d="m178.45 77.84-20.62-20.62c-.43.22-.97.32-1.51.32h-9.39c-4.86 0-9.61 1.94-12.95 5.4L107.2 89.71c-2.48 2.48-5.83 3.78-9.07 3.78-3.35 0-6.59-1.3-9.07-3.78L62.18 62.83c-3.45-3.45-8.2-5.4-12.95-5.4H37.68c-.54 0-.97-.11-1.4-.32L15.55 77.84c-10.58 10.58-10.58 27.85 0 38.43l20.62 20.62c.43-.22.86-.32 1.4-.32h11.55c4.86 0 9.61-1.94 12.95-5.4l26.88-26.88c4.86-4.86 13.39-4.86 18.24 0l26.77 26.77c3.45 3.45 8.2 5.4 12.95 5.4h9.39c.54 0 .97.11 1.51.32l20.62-20.62c10.58-10.58 10.58-27.85 0-38.43Z"></path>
            </svg>
            <svg v-if="metodosAceitos.includes('boleto')" viewBox="0 0 24 24">
                <path d="M3 4v16M6 4v16M9 4v16M13 4v16M15.5 4v16M19 4v16M21 4v16"></path>
            </svg>
        </span>
        <strong>Mais formas de pagamento</strong>
        <i class="pi pi-chevron-right" aria-hidden="true"></i>
    </button>
    `},FZComponents.ProdutoPreco={components:{"fz-simulador-parcelas-melhor-desconto":FZComponents.SimuladorParcelasMelhorDesconto},mixins:[ProdutoBaseMixin],props:{produto:{type:Object,required:!0},somenteOrcamentos:{type:Boolean,default:!1},precosRestritos:{type:Boolean,default:!1},precoDestaque:{type:String,default:"preco_original"},paginaLive:{type:Boolean,default:!1},ativarSimuladorParcelas:{type:Boolean,default:!1},alinhamento:{type:String,default:"centro",validator:value=>["centro","esquerda","direita","modal"].includes(value)},variacao:{type:String,default:"completo"},modeloMelhorDesconto:{type:String,default:"padrao",validator:value=>["padrao","compacto"].includes(value)},exibirSimuladorMelhorDesconto:{type:Boolean,default:!0}},computed:{isAlinhamentoModal(){return this.alinhamento==="modal"},classContainer(){return this.isAlinhamentoModal?"fz-produto-preco--modal d-flex justify-content-between align-items-center":""},isModoPrecoDesconto(){return this.precoDestaque==="preco_desconto"},simuladorMelhorDescontoDisponivel(){var _a;if(this.paginaLive||this.somenteOrcamentos||!this.ativarSimuladorParcelas||this.produto.venda_externa)return!1;const simulacao=(_a=this.produto)==null?void 0:_a.simulacao_parcelas,melhorDesconto=simulacao==null?void 0:simulacao.melhor_desconto;return!!(simulacao&&simulacao.exibir_simulador&&melhorDesconto&&Number(melhorDesconto.desconto)>0)},variacaoMelhorDesconto(){return this.modeloMelhorDesconto==="compacto"?"compacto":this.isModoPrecoDesconto?"destaque":this.variacao},quantidadeMinimaMelhorDesconto(){var _a,_b,_c,_d,_e,_f,_g,_h;const precoAPartir=((_b=(_a=this.produto)==null?void 0:_a.precos_produto)==null?void 0:_b.preco_a_partir)||{},catalogoId=((_c=this.configsLoja)==null?void 0:_c.catalogoId)||"padrao",qtdsMinimas=((_d=this.produto)==null?void 0:_d.qtds_minimas)||{},quantidadeCatalogo=(_g=(_e=qtdsMinimas==null?void 0:qtdsMinimas[catalogoId])==null?void 0:_e[0])!=null?_g:(_f=qtdsMinimas==null?void 0:qtdsMinimas.padrao)==null?void 0:_f[0];return Number(precoAPartir.quantidade||precoAPartir.qtd_minima||quantidadeCatalogo||((_h=this.produto)==null?void 0:_h.qtd_grade)||0)}},template:`
    <div v-if="!somenteOrcamentos && !precosRestritos" class="fz-produto-preco" :class="classContainer">
        <template v-if="isModoPrecoDesconto && simuladorMelhorDescontoDisponivel && exibirSimuladorMelhorDesconto">

            <!-- Container de preços do produto (fluxo em paralelo) -->
            <div :class="isAlinhamentoModal ? 'fz-produto-preco__valores' : ''">
                <!-- Grade -->
                <template v-if="produto.grade && !isEmpty(produto.grade)">
                    <p v-if="variacao == 'completo' && produto.preco_grade_desconto > 0" class="fz-produto-preco__antigo mb-0 preco_promo_antigo">
                        R$ {{ formatarPreco(produto.preco_grade_original) }}
                        <span class="fz-produto-preco__badge badge bg-success text-white ml-1 preco_promo_badge">
                            <i class="ti-arrow-down"></i> {{ produto.preco_grade_desconto }}%
                        </span>
                    </p>
                    <p class="fz-produto-preco__apartir-texto mb-0 preco_produto_apartir_texto" v-if="variacao == 'completo'">
                        {{ produto.qtd_grade }} itens por grade
                    </p>
                </template>

                <!-- Preço a partir de -->
                <template v-else-if="produto.precos_produto && produto.precos_produto.preco_a_partir && produto.precos_produto.preco_a_partir.ativado">
                    <p v-if="variacao == 'completo'" class="fz-produto-preco__apartir-texto mb-0 preco_produto_apartir_texto">
                        a partir de
                        <span v-if="produto.precos_produto.preco_a_partir.promocional_desconto > 0" class="fz-produto-preco__badge badge bg-success text-white ml-1 preco_promo_badge">
                            <i class="ti-arrow-down"></i> {{ produto.precos_produto.preco_a_partir.promocional_desconto }}%
                        </span>
                    </p>
                </template>

                <!-- Preço promocional -->
                <template v-else-if="produto.precos_produto && produto.precos_produto.promocional !== false && produto.precos_produto.promocional !== null">
                    <p v-if="variacao == 'completo'" class="fz-produto-preco__antigo mb-0 preco_promo_antigo">
                        R$ {{ formatarPreco(produto.precos_produto.padrao) }}
                        <span v-if="produto.precos_produto.promocional_desconto > 0" class="fz-produto-preco__badge badge bg-success text-white ml-1 preco_promo_badge">
                            <i class="ti-arrow-down"></i> {{ produto.precos_produto.promocional_desconto }}%
                        </span>
                    </p>
                </template>
            </div>

            <!-- Simulador de Parcelas - Melhor Desconto em destaque -->
            <fz-simulador-parcelas-melhor-desconto
                v-if="exibirSimuladorMelhorDesconto"
                :produto="produto"
                :simulacao="produto.simulacao_parcelas"
                :abrir-modal="false"
                :alinhamento="alinhamento"
                :variacao="variacaoMelhorDesconto"
                :quantidade-minima="quantidadeMinimaMelhorDesconto"
                :class="{
                    'fz-produto-preco__simulador': isAlinhamentoModal,
                    'fz-produto-preco__promocional': !isAlinhamentoModal,
                }"
            >
            </fz-simulador-parcelas-melhor-desconto>
        </template>

        <template v-else>
            <!-- Container de preços -->
            <div :class="isAlinhamentoModal ? 'fz-produto-preco__valores' : ''">
                <!-- Grade -->
                <template v-if="produto.grade && !isEmpty(produto.grade)">
                    <p v-if="variacao == 'completo' && produto.preco_grade_desconto > 0" class="fz-produto-preco__antigo mb-0 preco_promo_antigo">
                        R$ {{ formatarPreco(produto.preco_grade_original) }}
                        <span class="fz-produto-preco__badge badge bg-success text-white ml-1 preco_promo_badge">
                            <i class="ti-arrow-down"></i> {{ produto.preco_grade_desconto }}%
                        </span>
                    </p>
                    <p class="fz-produto-preco__apartir mb-0 preco_produto_apartir">
                        R$ {{ formatarPreco(produto.preco_grade) }}

                        <span v-if="variacao == 'compacto' && produto.preco_grade_desconto > 0" class="fz-produto-preco__antigo mb-0 preco_promo_antigo">
                            R$ {{ formatarPreco(produto.preco_grade_original) }}
                        </span>
                    </p>
                    <p class="fz-produto-preco__apartir-texto mb-0 preco_produto_apartir_texto" v-if="variacao == 'completo'">
                        {{ produto.qtd_grade }} itens por grade
                    </p>
                </template>

                <!-- Preço a partir de -->
                <template v-else-if="produto.precos_produto && produto.precos_produto.preco_a_partir && produto.precos_produto.preco_a_partir.ativado">
                    <p v-if="variacao == 'completo'" class="fz-produto-preco__apartir-texto mb-0 preco_produto_apartir_texto">
                        a partir de
                        <span v-if="produto.precos_produto.preco_a_partir.promocional_desconto > 0" class="fz-produto-preco__badge badge bg-success text-white ml-1 preco_promo_badge">
                            <i class="ti-arrow-down"></i> {{ produto.precos_produto.preco_a_partir.promocional_desconto }}%
                        </span>
                    </p>
                    <p class="fz-produto-preco__apartir mb-0 preco_produto_apartir">
                        <span v-if="variacao == 'compacto'" class="fz-produto-preco__apartir-texto">
                            a partir de
                        </span>

                        R$ {{ formatarPreco(produto.precos_produto.preco_a_partir.preco) }}
                    </p>
                </template>

                <!-- Preço promocional -->
                <template v-else-if="produto.precos_produto && produto.precos_produto.promocional !== false && produto.precos_produto.promocional !== null">
                    <p v-if="variacao == 'completo'" class="fz-produto-preco__antigo mb-0 preco_promo_antigo">
                        R$ {{ formatarPreco(produto.precos_produto.padrao) }}
                        <span v-if="produto.precos_produto.promocional_desconto > 0" class="fz-produto-preco__badge badge bg-success text-white ml-1 preco_promo_badge">
                            <i class="ti-arrow-down"></i> {{ produto.precos_produto.promocional_desconto }}%
                        </span>
                    </p>
                    <p class="fz-produto-preco__promocional mb-0 preco_promo">
                        R$ {{ formatarPreco(produto.precos_produto.promocional) }}

                        <span v-if="variacao == 'compacto'" class="fz-produto-preco__antigo mb-0 preco_promo_antigo">
                            R$ {{ formatarPreco(produto.precos_produto.padrao) }}
                        </span>
                    </p>
                </template>

                <!-- Preço normal -->
                <template v-else>
                    <p class="fz-produto-preco__normal mb-0 preco_normal">
                        R$ {{ formatarPreco(produto.precos_produto ? produto.precos_produto.padrao : 0) }}
                    </p>
                </template>
            </div>

            <!-- Simulador de Parcelas - Melhor Desconto -->
            <fz-simulador-parcelas-melhor-desconto
                v-if="exibirSimuladorMelhorDesconto && !paginaLive && !somenteOrcamentos && ativarSimuladorParcelas && !produto.venda_externa"
                :produto="produto"
                :simulacao="produto.simulacao_parcelas"
                :abrir-modal="false"
                :alinhamento="alinhamento"
                :variacao="variacaoMelhorDesconto"
                :quantidade-minima="quantidadeMinimaMelhorDesconto"
                :class="{
                    'fz-produto-preco__simulador': isAlinhamentoModal,
                    'px-1 pt-1 pb-1': !isAlinhamentoModal && variacao == 'completo'
                }"
            >
            </fz-simulador-parcelas-melhor-desconto>
        </template>
    </div>
    `},FZComponents.ProdutoAcoes={components:{"p-button":PrimeVue.Button},mixins:[ProdutoBaseMixin],props:{produto:{type:Object,required:!0},habilitarCurtidas:{type:Boolean,default:!1},habilitarPerguntas:{type:Boolean,default:!1},permitirCompartilharProduto:{type:Boolean,default:!1},habilitarWhatsApp:{type:Boolean,default:!1},linkWhatsApp:{type:String,default:null},size:{type:String,default:null}},mounted(){this.permitirCompartilharProduto&&this.$nextTick(()=>{typeof a2a!="undefined"&&a2a.init("page",{target:".a2a_dd"})})},template:`
    <div
        v-if="habilitarCurtidas || habilitarPerguntas || permitirCompartilharProduto || habilitarWhatsApp"
        class="fz-produto-acoes d-flex justify-content-around align-items-center"
        style="flex-grow: 1;"
    >
        <!-- Curtir -->
        <p-button
            v-if="habilitarCurtidas"
            :class="['fz-produto-acoes__curtir', 'curtir_produto_' + produto.id]"
            @click="curtirProduto"
            :icon="produto.curtido ? 'pi pi-heart-fill' : 'pi pi-heart'"
            :badge="produto.total_curtidas > 0 ? String(produto.total_curtidas) : null"
            :severity="produto.curtido ? 'danger' : 'primary'"
            variant="text"
            rounded
            :size="size"
            aria-label="Curtir produto">
        </p-button>

        <!-- Perguntas -->
        <p-button
            v-if="habilitarPerguntas"
            class="fz-produto-acoes__perguntas"
            @click="perguntasProduto"
            icon="pi pi-comment"
            :badge="produto.total_perguntas > 0 ? String(produto.total_perguntas) : null"
            variant="text"
            rounded
            :size="size"
            aria-label="Perguntas sobre o produto">
        </p-button>

        <!-- Compartilhar -->
        <p-button
            v-if="permitirCompartilharProduto"
            class="fz-produto-acoes__compartilhar a2a_dd"
            icon="pi pi-share-alt"
            variant="text"
            rounded
            aria-label="Compartilhar"
            :data-a2a-url="linkProduto"
            :data-a2a-title="produto.nome"
            :size="size"
            data-href="https://www.addtoany.com/share">
        </p-button>

        <!-- WhatsApp -->
        <p-button
            v-if="habilitarWhatsApp && linkWhatsApp"
            class="fz-produto-acoes__whatsapp"
            icon="pi pi-whatsapp"
            variant="text"
            rounded
            severity="success"
            as="a"
            :href="linkWhatsApp"
            target="_blank"
            :size="size"
            aria-label="Falar no WhatsApp">
        </p-button>
    </div>
    `},FZComponents.ProdutoBotaoCompra={components:{"p-button":PrimeVue.Button},mixins:[ProdutoBaseMixin],props:{produto:{type:Object,required:!0},textoBotao:{type:String,required:!0},iconeBotao:{type:String,default:"pi pi-shopping-cart"},precosRestritos:{type:Boolean,default:!1},paginaLive:{type:Boolean,default:!1},habilitarAviseMeQuandoChegar:{type:Boolean,default:!1}},methods:{handleClick(event){this.$emit("click",event)}},template:`
    <div class="fz-produto-botao-compra">
        <!-- Venda externa -->
        <template v-if="produto.venda_externa">
            <p-button
                class="fz-produto-botao-compra__btn fz-produto-botao-compra__btn--externo w-100"
                :size="paginaLive ? 'small' : undefined"
                as="a"
                :href="produto.link_externo"
                target="_blank"
                severity="primary"
                :label="textoBotao"
                icon="pi pi-external-link"
                :aria-label="textoBotao"></p-button>
        </template>

        <!-- Preços restritos -->
        <template v-else-if="precosRestritos">
            <p-button
                class="fz-produto-botao-compra__btn fz-produto-botao-compra__btn--restrito w-100"
                :size="paginaLive ? 'small' : undefined"
                as="a"
                :href="linkLogin"
                severity="primary"
                :label="'Ver Preços'"
                icon="pi pi-lock"
                aria-label="Ver Preços">
            </p-button>
        </template>

        <!-- Produto indisponível - Avise-me -->
        <template v-else-if="produtoIndisponivelEstoque">
            <p-button
                class="fz-produto-botao-compra__btn fz-produto-botao-compra__btn--avise-me w-100"
                :size="paginaLive ? 'small' : undefined"
                as="a"
                :href="linkProduto"
                @click.prevent="handleClick"
                severity="primary"
                :label="'Avise-me'"
                icon="pi pi-bell">
            </p-button>
        </template>

        <!-- Ação padrão - Comprar -->
        <template v-else>
            <p-button
                class="fz-produto-botao-compra__btn fz-produto-botao-compra__btn--comprar w-100"
                :size="paginaLive ? 'small' : undefined"
                as="a"
                :href="linkProduto"
                @click.prevent="handleClick"
                severity="primary"
                :label="textoBotao"
                :icon="iconeBotao"
                aria-label="textoBotao">
            </p-button>
        </template>
    </div>
    `},FZComponents.ProdutoSkeleton={components:{"p-skeleton":PrimeVue.Skeleton},template:`
    <div class="fz-produto-skeleton px-2" style="margin-bottom: 5px !important;">
        <div class="container-fluid">
            <div class="row">
                <div class="fz-produto-skeleton__card bloco-mensagem w-100 p-0" style="box-shadow: rgb(0 0 0 / 12%) 0px 4px 7px;">

                    <!-- Imagem Skeleton -->
                    <div class="fz-produto-skeleton__imagem p-2" style="border-bottom: 1px solid #ebebeb;">
                        <p-skeleton width="100%" height="200px" class="mx-auto"></p-skeleton>
                    </div>

                    <!-- Título Skeleton -->
                    <div class="fz-produto-skeleton__titulo px-2 pt-2 pb-2 text-center">
                        <p-skeleton width="80%" height="1.2rem" class="mb-2 mx-auto"></p-skeleton>
                        <p-skeleton width="60%" height="1rem" class="mx-auto"></p-skeleton>
                    </div>

                    <!-- Preço Skeleton -->
                    <div class="fz-produto-skeleton__preco px-3 pt-1 pb-2 text-center">
                        <p-skeleton width="50%" height="1.5rem" class="mb-2 mx-auto"></p-skeleton>
                        <p-skeleton width="70%" height="1rem" class="mx-auto"></p-skeleton>
                    </div>

                    <!-- Botão Skeleton -->
                    <div class="fz-produto-skeleton__botao px-2 pt-2 pb-2 text-center">
                        <p-skeleton width="100%" height="2.5rem" borderRadius="4px" class="mx-auto"></p-skeleton>
                    </div>

                    <!-- Skeleton dos 3 botões circulares de curtir, compartilhar e comentar -->
                    <div class="fz-produto-skeleton__acoes d-flex justify-content-around px-2 py-2">
                        <p-skeleton width="36px" height="36px" borderRadius="50%"></p-skeleton>
                        <p-skeleton width="36px" height="36px" borderRadius="50%"></p-skeleton>
                        <p-skeleton width="36px" height="36px" borderRadius="50%"></p-skeleton>
                    </div>

                </div>
            </div>
        </div>
    </div>
    `},FZComponents.ProdutoSlider={components:{"p-button":PrimeVue.Button},mixins:[ProdutoBaseMixin],props:{produto:{type:Object,required:!0},ocultarDestaque:{type:Boolean,default:!1},prefixoSlider:{type:String,default:""},habilitarAviseMeQuandoChegar:{type:Boolean,default:!1},gridFormatoImagem:{type:String,default:"original"},variacao:{type:String,default:"completo"},habilitarCurtidas:{type:Boolean,default:!1},exibirSlideImagens:{type:Boolean,default:!0}},data(){return{swiperInstance:null}},computed:{produtoIndisponivel(){return this.produto.total_estoque<=0&&this.produto.controlar_estoque=="1"&&this.habilitarAviseMeQuandoChegar},sliderId(){return(this.prefixoSlider||"")+"slide_produto_"+this.produto.id},temMultiplasImagens(){return this.exibirSlideImagens&&this.produto.imagens&&this.produto.imagens.length>1}},mounted(){this.temMultiplasImagens&&this.$nextTick(()=>{this.initSwiper()})},watch:{"produto.imagens":{handler(newValue){newValue&&newValue.length>1&&this.$nextTick(()=>{this.initSwiper()})},deep:!0},exibirSlideImagens(habilitado){if(!habilitado){this.destruirSwiper();return}this.produto.imagens&&this.produto.imagens.length>1&&this.$nextTick(()=>{this.initSwiper()})}},methods:{destruirSwiper(){this.swiperInstance&&typeof this.swiperInstance.destroy=="function"&&(this.swiperInstance.destroy(!0,!0),this.swiperInstance=null)},initSwiper(){typeof Swiper!="undefined"&&this.temMultiplasImagens&&(this.destruirSwiper(),this.swiperInstance=new Swiper("#"+this.sliderId,{slidesPerView:1,spaceBetween:0,observer:!0,observeSlideChildren:!0,touchAngle:20,autoHeight:!0,navigation:{enabled:!0,nextEl:"#"+this.sliderId+" .swiper-button-next",prevEl:"#"+this.sliderId+" .swiper-button-prev"},pagination:{enabled:!0,el:"#"+this.sliderId+" .swiper-pagination",type:"bullets"}}))}},beforeUnmount(){this.destruirSwiper()},template:`
    <div class="fz-produto-slider" style="position: relative;">
        <span v-if="produtoIndisponivel" class="fz-produto-slider__badge fz-produto-slider__badge--indisponivel badge badge-secondary bg-success">
            Produto<br>indisponível
        </span>
        <span v-else-if="produto.comprado_recentemente" class="fz-produto-slider__badge fz-produto-slider__badge--recente badge badge-secondary bg-success">
            <i class="fa fa-star" aria-hidden="true"></i> Você comprou<br>recentemente
        </span>
        <span v-else-if="produto.destaque == '1' && !ocultarDestaque" class="fz-produto-slider__badge fz-produto-slider__badge--destaque badge badge-secondary bg-success">
            Destaque
        </span>

        <p-button
            v-if="habilitarCurtidas && variacao === 'compacto'"
            :class="['fz-produto-slider__curtir', 'curtir_produto_' + produto.id]"
            @click.stop="curtirProduto"
            :icon="produto.curtido ? 'pi pi-heart-fill' : 'pi pi-heart'"
            :severity="produto.curtido ? 'danger' : 'secondary'"
            variant="text"
            rounded
            :aria-label="produto.curtido ? 'Descurtir produto' : 'Curtir produto'">
        </p-button>

        <div v-if="temMultiplasImagens" class="fz-produto-slider__swiper slide_produtos swiper" :id="sliderId" :style="produtoIndisponivel ? 'opacity:0.4' : ''">
            <div class="swiper-wrapper">
                <div v-for="(imagem, index) in produto.imagens" :key="index" class="swiper-slide" style="cursor:pointer" @click="abrirProduto">
                    <img
                        :src="obterURLThumb(imagem)"
                        class="fz-produto-slider__imagem img-fluid w-100"
                        :class="{
                            'square-image': gridFormatoImagem == 'square',
                            'rectangle-image': gridFormatoImagem != 'original' && gridFormatoImagem != 'square',
                        }"
                        loading="lazy"
                        @error="handleImageError"
                    />
                </div>
            </div>
            <div class="swiper-pagination d-block d-lg-none"></div>
            <div class="swiper-button-prev fz-seta-slider small slider-produto d-none d-lg-flex"></div>
            <div class="swiper-button-next fz-seta-slider small slider-produto d-none d-lg-flex"></div>
        </div>

        <a v-else :href="linkProduto" class="fz-produto-slider__link" :style="produtoIndisponivel ? 'opacity:0.4' : ''" style="cursor:pointer" @click="abrirProduto">
            <img
                :src="obterURLThumb(produto.imagens[0])"
                class="fz-produto-slider__imagem img-fluid w-100"
                :class="{
                    'square-image': gridFormatoImagem == 'square',
                    'rectangle-image': gridFormatoImagem != 'original' && gridFormatoImagem != 'square',
                }"
                loading="lazy"
                @error="handleImageError"
            />
        </a>
    </div>
    `},FZComponents.TagCampanhaPromocional={components:{},mixins:[ProdutoBaseMixin],props:{produto:{type:Object,required:!0},campanhaPromocionalAtivaNoMomento:{type:Boolean,default:!1},campanhaPromocionalTagProdutosAtivada:{type:Boolean,default:!1},campanhaPromocionalTagProdutosTexto:{type:String,default:""},campanhaPromocionalTagProdutosCorFundo:{type:String,default:"#28a745"},campanhaPromocionalTagProdutosCorTexto:{type:String,default:"#ffffff"}},template:`
    <div v-if="exibirTag" class="fz-tag-campanha-promocional px-2 py-1 text-center font-weight-bold" :style="estiloTag">
        {{ campanhaPromocionalTagProdutosTexto }}
    </div>
    `,computed:{exibirTag(){return this.campanhaPromocionalAtivaNoMomento&&this.campanhaPromocionalTagProdutosAtivada&&this.campanhaPromocionalTagProdutosTexto&&this.produto.campanha_promocional==!0},estiloTag(){return{backgroundColor:this.campanhaPromocionalTagProdutosCorFundo||"#28a745",color:this.campanhaPromocionalTagProdutosCorTexto||"#ffffff"}}}},FZComponents.ProdutoClean={components:{"p-tag":PrimeVue.Tag,"fz-produto-slider":FZComponents.ProdutoSlider,"fz-tag-campanha-promocional":FZComponents.TagCampanhaPromocional,"fz-produto-preco":FZComponents.ProdutoPreco,"fz-produto-botao-compra":FZComponents.ProdutoBotaoCompra,"fz-simulador-parcelas-melhor-parcelamento":FZComponents.SimuladorParcelasMelhorParcelamento,"fz-produto-acoes":FZComponents.ProdutoAcoes},mixins:[ProdutoBaseMixin],props:{class:{type:String,default:""},produto:{type:Object,required:!0},prefixoSlider:{type:String,default:""},precoDestaque:{type:String,default:"preco_original"},precosRestritos:{type:Boolean,default:!1},paginaLive:{type:Boolean,default:!1},ocultarDestaque:{type:Boolean,default:!1},somenteOrcamentos:{type:Boolean,default:!1},mostrarQuantidadeVenda:{type:Boolean,default:!1},habilitarCurtidas:{type:Boolean,default:!1},habilitarPerguntas:{type:Boolean,default:!1},permitirCompartilharProduto:{type:Boolean,default:!1},ativarSimuladorParcelas:{type:Boolean,default:!1},textoBotaoAcaoProdutos:{type:String,default:"Comprar"},iconeBotaoAcaoProdutos:{type:String,default:"pi pi-shopping-cart"},habilitarAviseMeQuandoChegar:{type:Boolean,default:!1},gridFormatoImagem:{type:String,default:"original"},campanhaPromocionalAtivaNoMomento:{type:Boolean,default:!1},campanhaPromocionalTagProdutosAtivada:{type:Boolean,default:!1},campanhaPromocionalTagProdutosTexto:{type:String,default:""},campanhaPromocionalTagProdutosCorFundo:{type:String,default:"#28a745"},campanhaPromocionalTagProdutosCorTexto:{type:String,default:"#ffffff"}},template:`
    <div :class="['fz-produto', 'fz-produto--clean', classe, 'px-1', 'produto_div_' + produto.id]" :id="'produto_div_' + produto.id" style="margin-bottom: 15px !important;">
        <div class="container-fluid">
            <div class="row">
                <div class="fz-produto__card w-100">
                    <div class="fz-produto__imagem-container">
                        <fz-produto-slider
                            :produto="produto"
                            variacao="compacto"
                            :prefixo-slider="prefixoSlider"
                            :ocultar-destaque="ocultarDestaque"
                            :habilitar-avise-me-quando-chegar="habilitarAviseMeQuandoChegar"
                            :habilitar-curtidas="habilitarCurtidas"
                            :abrir-link-direto="abrirLinkDireto"
                            :grid-formato-imagem="gridFormatoImagem">
                        </fz-produto-slider>
                    </div>

                    <fz-tag-campanha-promocional
                        :produto="produto"
                        :campanha-promocional-ativa-no-momento="campanhaPromocionalAtivaNoMomento"
                        :campanha-promocional-tag-produtos-ativada="campanhaPromocionalTagProdutosAtivada"
                        :campanha-promocional-tag-produtos-texto="campanhaPromocionalTagProdutosTexto"
                        :campanha-promocional-tag-produtos-cor-fundo="campanhaPromocionalTagProdutosCorFundo"
                        :campanha-promocional-tag-produtos-cor-texto="campanhaPromocionalTagProdutosCorTexto">
                    </fz-tag-campanha-promocional>

                    <a class="fz-produto__titulo link-produto my-2 text-left cursor-pointer d-block"
                       @click="abrirProduto"
                       :href="linkProduto">
                        {{ produto.nome }}
                    </a>

                    <a class="fz-produto__preco-link link-produto text-left cursor-pointer d-block"
                       @click="abrirProduto"
                       :href="linkProduto">
                        <fz-produto-preco
                            :produto="produto"
                            :preco-destaque="precoDestaque"
                            :somente-orcamentos="somenteOrcamentos"
                            :precos-restritos="precosRestritos"
                            :pagina-live="paginaLive"
                            :ativar-simulador-parcelas="ativarSimuladorParcelas"
                            variacao="compacto"
                            alinhamento="esquerda">
                        </fz-produto-preco>
                    </a>

                    <!-- Simulador de Parcelas - Melhor Parcelamento (apenas quando não é live) -->
                    <fz-simulador-parcelas-melhor-parcelamento
                        v-if="!paginaLive && !somenteOrcamentos && !precosRestritos && ativarSimuladorParcelas && !produto.venda_externa"
                        :produto="produto"
                        :simulacao="produto.simulacao_parcelas"
                        :abrir-modal="true"
                        alinhamento="esquerda"
                        variacao="compacto"
                        class="fz-produto__simulador text-left">
                    </fz-simulador-parcelas-melhor-parcelamento>

                </div>
            </div>
        </div>
    </div>
    `},FZComponents.ProdutoClean2={components:{"p-tag":PrimeVue.Tag,"fz-produto-slider":FZComponents.ProdutoSlider,"fz-tag-campanha-promocional":FZComponents.TagCampanhaPromocional,"fz-produto-preco":FZComponents.ProdutoPreco,"fz-produto-botao-compra":FZComponents.ProdutoBotaoCompra,"fz-simulador-parcelas-melhor-parcelamento":FZComponents.SimuladorParcelasMelhorParcelamento,"fz-produto-acoes":FZComponents.ProdutoAcoes},mixins:[ProdutoBaseMixin],props:{class:{type:String,default:""},produto:{type:Object,required:!0},prefixoSlider:{type:String,default:""},precoDestaque:{type:String,default:"preco_original"},precosRestritos:{type:Boolean,default:!1},paginaLive:{type:Boolean,default:!1},ocultarDestaque:{type:Boolean,default:!1},somenteOrcamentos:{type:Boolean,default:!1},mostrarQuantidadeVenda:{type:Boolean,default:!1},habilitarCurtidas:{type:Boolean,default:!1},habilitarPerguntas:{type:Boolean,default:!1},permitirCompartilharProduto:{type:Boolean,default:!1},ativarSimuladorParcelas:{type:Boolean,default:!1},textoBotaoAcaoProdutos:{type:String,default:"Comprar"},iconeBotaoAcaoProdutos:{type:String,default:"pi pi-shopping-cart"},habilitarAviseMeQuandoChegar:{type:Boolean,default:!1},gridFormatoImagem:{type:String,default:"original"},campanhaPromocionalAtivaNoMomento:{type:Boolean,default:!1},campanhaPromocionalTagProdutosAtivada:{type:Boolean,default:!1},campanhaPromocionalTagProdutosTexto:{type:String,default:""},campanhaPromocionalTagProdutosCorFundo:{type:String,default:"#28a745"},campanhaPromocionalTagProdutosCorTexto:{type:String,default:"#ffffff"}},computed:{totalQuantidade(){return CarrinhoManager.obterTotalQuantidadeProduto(this.produto.id,this.configsLoja.carrinho)}},template:`
    <div :class="['fz-produto', 'fz-produto--clean-2', classe, 'px-1', 'produto_div_' + produto.id]" :id="'produto_div_' + produto.id" style="margin-bottom: 15px !important;">
        <div class="container-fluid">
            <div class="row">
                <div class="fz-produto__card w-100">
                    <div class="fz-produto__imagem-container">
                        <fz-produto-slider
                            :produto="produto"
                            variacao="compacto"
                            :prefixo-slider="prefixoSlider"
                            :ocultar-destaque="ocultarDestaque"
                            :habilitar-avise-me-quando-chegar="habilitarAviseMeQuandoChegar"
                            :habilitar-curtidas="habilitarCurtidas"
                            :abrir-link-direto="abrirLinkDireto"
                            :grid-formato-imagem="gridFormatoImagem">
                        </fz-produto-slider>
                    </div>

                    <fz-tag-campanha-promocional
                        :produto="produto"
                        :campanha-promocional-ativa-no-momento="campanhaPromocionalAtivaNoMomento"
                        :campanha-promocional-tag-produtos-ativada="campanhaPromocionalTagProdutosAtivada"
                        :campanha-promocional-tag-produtos-texto="campanhaPromocionalTagProdutosTexto"
                        :campanha-promocional-tag-produtos-cor-fundo="campanhaPromocionalTagProdutosCorFundo"
                        :campanha-promocional-tag-produtos-cor-texto="campanhaPromocionalTagProdutosCorTexto">
                    </fz-tag-campanha-promocional>

                    <a class="fz-produto__titulo link-produto text-left px-1 cursor-pointer d-block"
                       @click="abrirProduto"
                       :href="linkProduto">
                        {{ produto.nome }}
                    </a>

                    <a class="fz-produto__preco-link link-produto px-1 text-left cursor-pointer d-block"
                       @click="abrirProduto"
                       :href="linkProduto">
                        <fz-produto-preco
                            :produto="produto"
                            :preco-destaque="precoDestaque"
                            :somente-orcamentos="somenteOrcamentos"
                            :precos-restritos="precosRestritos"
                            :pagina-live="paginaLive"
                            :ativar-simulador-parcelas="ativarSimuladorParcelas"
                            variacao="compacto"
                            alinhamento="esquerda">
                        </fz-produto-preco>
                    </a>

                    <!-- Simulador de Parcelas - Melhor Parcelamento (apenas quando não é live) -->
                    <fz-simulador-parcelas-melhor-parcelamento
                        v-if="!paginaLive && !somenteOrcamentos && !precosRestritos && ativarSimuladorParcelas && !produto.venda_externa"
                        :produto="produto"
                        :simulacao="produto.simulacao_parcelas"
                        :abrir-modal="true"
                        alinhamento="esquerda"
                        variacao="compacto"
                        class="fz-produto__simulador text-left px-1">
                    </fz-simulador-parcelas-melhor-parcelamento>

                    <div class="d-flex flex-column align-items-center px-1 pt-2 pb-1">
                        <a class="fz-produto__quantidade-fake d-flex align-items-center justify-content-between mb-2"
                           @click="abrirProduto"
                           :href="linkProduto">
                            <span class="fz-produto__quantidade-fake__button">-</span>
                            <span class="fz-produto__quantidade-fake__value">{{ totalQuantidade }}</span>
                            <span class="fz-produto__quantidade-fake__button">+</span>
                        </a>

                        <div class="w-100 text-center">
                            <fz-produto-botao-compra
                                :produto="produto"
                                :texto-botao="textoBotaoAcao"
                                :icone-botao="iconeBotaoAcao"
                                :precos-restritos="precosRestritos"
                                :pagina-live="paginaLive"
                                :habilitar-avise-me-quando-chegar="habilitarAviseMeQuandoChegar"
                                class="w-100"
                                @click="abrirProduto">
                            </fz-produto-botao-compra>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    `},FZComponents.ProdutoFancy={components:{"p-tag":PrimeVue.Tag,"fz-produto-slider":FZComponents.ProdutoSlider,"fz-tag-campanha-promocional":FZComponents.TagCampanhaPromocional,"fz-produto-preco":FZComponents.ProdutoPreco,"fz-produto-botao-compra":FZComponents.ProdutoBotaoCompra,"fz-simulador-parcelas-melhor-parcelamento":FZComponents.SimuladorParcelasMelhorParcelamento,"fz-produto-acoes":FZComponents.ProdutoAcoes},mixins:[ProdutoBaseMixin],props:{class:{type:String,default:""},produto:{type:Object,required:!0},prefixoSlider:{type:String,default:""},precoDestaque:{type:String,default:"preco_original"},precosRestritos:{type:Boolean,default:!1},paginaLive:{type:Boolean,default:!1},ocultarDestaque:{type:Boolean,default:!1},somenteOrcamentos:{type:Boolean,default:!1},mostrarQuantidadeVenda:{type:Boolean,default:!1},habilitarCurtidas:{type:Boolean,default:!1},habilitarPerguntas:{type:Boolean,default:!1},permitirCompartilharProduto:{type:Boolean,default:!1},ativarSimuladorParcelas:{type:Boolean,default:!1},textoBotaoAcaoProdutos:{type:String,default:"Comprar"},iconeBotaoAcaoProdutos:{type:String,default:"pi pi-shopping-cart"},habilitarAviseMeQuandoChegar:{type:Boolean,default:!1},gridFormatoImagem:{type:String,default:"original"},campanhaPromocionalAtivaNoMomento:{type:Boolean,default:!1},campanhaPromocionalTagProdutosAtivada:{type:Boolean,default:!1},campanhaPromocionalTagProdutosTexto:{type:String,default:""},campanhaPromocionalTagProdutosCorFundo:{type:String,default:"#28a745"},campanhaPromocionalTagProdutosCorTexto:{type:String,default:"#ffffff"}},computed:{totalQuantidade(){return CarrinhoManager.obterTotalQuantidadeProduto(this.produto.id,this.configsLoja.carrinho)}},template:`
    <div :class="['fz-produto', 'fz-produto--fancy', classe, 'px-2', 'produto_div_' + produto.id]" :id="'produto_div_' + produto.id" style="margin-bottom: 15px !important;">
        <div class="container-fluid">
            <div class="row">
                <div class="fz-produto__card w-100">
                    <div class="fz-produto__imagem-container">
                        <fz-produto-slider
                            :produto="produto"
                            variacao="compacto"
                            :prefixo-slider="prefixoSlider"
                            :ocultar-destaque="ocultarDestaque"
                            :habilitar-avise-me-quando-chegar="habilitarAviseMeQuandoChegar"
                            :habilitar-curtidas="habilitarCurtidas"
                            :abrir-link-direto="abrirLinkDireto"
                            :grid-formato-imagem="gridFormatoImagem">
                        </fz-produto-slider>
                    </div>

                    <fz-tag-campanha-promocional
                        :produto="produto"
                        :campanha-promocional-ativa-no-momento="campanhaPromocionalAtivaNoMomento"
                        :campanha-promocional-tag-produtos-ativada="campanhaPromocionalTagProdutosAtivada"
                        :campanha-promocional-tag-produtos-texto="campanhaPromocionalTagProdutosTexto"
                        :campanha-promocional-tag-produtos-cor-fundo="campanhaPromocionalTagProdutosCorFundo"
                        :campanha-promocional-tag-produtos-cor-texto="campanhaPromocionalTagProdutosCorTexto">
                    </fz-tag-campanha-promocional>

                    <a class="fz-produto__titulo link-produto text-left px-1 cursor-pointer d-block"
                       @click="abrirProduto"
                       :href="linkProduto">
                        {{ produto.nome }}
                    </a>

                    <a class="fz-produto__preco-link link-produto px-1 text-left cursor-pointer d-block"
                       @click="abrirProduto"
                       :href="linkProduto">
                        <fz-produto-preco
                            :produto="produto"
                            :preco-destaque="precoDestaque"
                            :somente-orcamentos="somenteOrcamentos"
                            :precos-restritos="precosRestritos"
                            :pagina-live="paginaLive"
                            :ativar-simulador-parcelas="ativarSimuladorParcelas"
                            variacao="compacto"
                            alinhamento="esquerda">
                        </fz-produto-preco>
                    </a>

                    <!-- Simulador de Parcelas - Melhor Parcelamento (apenas quando não é live) -->
                    <fz-simulador-parcelas-melhor-parcelamento
                        v-if="!paginaLive && !somenteOrcamentos && !precosRestritos && ativarSimuladorParcelas && !produto.venda_externa"
                        :produto="produto"
                        :simulacao="produto.simulacao_parcelas"
                        :abrir-modal="true"
                        alinhamento="esquerda"
                        variacao="compacto"
                        class="fz-produto__simulador text-left px-1">
                    </fz-simulador-parcelas-melhor-parcelamento>

                    <div class="mt-3 px-1 text-center">
                        <fz-produto-botao-compra
                            :produto="produto"
                            :texto-botao="textoBotaoAcao"
                            :icone-botao="iconeBotaoAcao"
                            :precos-restritos="precosRestritos"
                            :pagina-live="paginaLive"
                            :habilitar-avise-me-quando-chegar="habilitarAviseMeQuandoChegar"
                            class="w-100"
                            @click="abrirProduto">
                        </fz-produto-botao-compra>
                    </div>
                </div>
            </div>
        </div>
    </div>
    `},FZComponents.ProdutoColor={components:{"p-tag":PrimeVue.Tag,"fz-produto-slider":FZComponents.ProdutoSlider,"fz-tag-campanha-promocional":FZComponents.TagCampanhaPromocional,"fz-produto-preco":FZComponents.ProdutoPreco,"fz-produto-botao-compra":FZComponents.ProdutoBotaoCompra,"fz-simulador-parcelas-melhor-parcelamento":FZComponents.SimuladorParcelasMelhorParcelamento,"fz-produto-acoes":FZComponents.ProdutoAcoes},mixins:[ProdutoBaseMixin],props:{class:{type:String,default:""},produto:{type:Object,required:!0},prefixoSlider:{type:String,default:""},precoDestaque:{type:String,default:"preco_original"},precosRestritos:{type:Boolean,default:!1},paginaLive:{type:Boolean,default:!1},ocultarDestaque:{type:Boolean,default:!1},somenteOrcamentos:{type:Boolean,default:!1},mostrarQuantidadeVenda:{type:Boolean,default:!1},habilitarCurtidas:{type:Boolean,default:!1},habilitarPerguntas:{type:Boolean,default:!1},permitirCompartilharProduto:{type:Boolean,default:!1},ativarSimuladorParcelas:{type:Boolean,default:!1},textoBotaoAcaoProdutos:{type:String,default:"Comprar"},iconeBotaoAcaoProdutos:{type:String,default:"pi pi-shopping-cart"},habilitarAviseMeQuandoChegar:{type:Boolean,default:!1},gridFormatoImagem:{type:String,default:"original"},campanhaPromocionalAtivaNoMomento:{type:Boolean,default:!1},campanhaPromocionalTagProdutosAtivada:{type:Boolean,default:!1},campanhaPromocionalTagProdutosTexto:{type:String,default:""},campanhaPromocionalTagProdutosCorFundo:{type:String,default:"#28a745"},campanhaPromocionalTagProdutosCorTexto:{type:String,default:"#ffffff"}},template:`
    <div :class="['fz-produto', 'fz-produto--color', classe, 'px-1', 'produto_div_' + produto.id]" :id="'produto_div_' + produto.id" style="margin-bottom: 15px !important;">
        <div class="container-fluid">
            <div class="row">
                <div class="fz-produto__card w-100">
                    <div class="fz-produto__imagem-container">
                        <fz-produto-slider
                            :produto="produto"
                            variacao="compacto"
                            :prefixo-slider="prefixoSlider"
                            :ocultar-destaque="ocultarDestaque"
                            :habilitar-avise-me-quando-chegar="habilitarAviseMeQuandoChegar"
                            :habilitar-curtidas="habilitarCurtidas"
                            :abrir-link-direto="abrirLinkDireto"
                            :grid-formato-imagem="gridFormatoImagem">
                        </fz-produto-slider>
                    </div>

                    <fz-tag-campanha-promocional
                        :produto="produto"
                        :campanha-promocional-ativa-no-momento="campanhaPromocionalAtivaNoMomento"
                        :campanha-promocional-tag-produtos-ativada="campanhaPromocionalTagProdutosAtivada"
                        :campanha-promocional-tag-produtos-texto="campanhaPromocionalTagProdutosTexto"
                        :campanha-promocional-tag-produtos-cor-fundo="campanhaPromocionalTagProdutosCorFundo"
                        :campanha-promocional-tag-produtos-cor-texto="campanhaPromocionalTagProdutosCorTexto">
                    </fz-tag-campanha-promocional>

                    <a class="fz-produto__titulo link-produto my-0 px-1 text-center cursor-pointer d-block"
                       @click="abrirProduto"
                       :href="linkProduto">
                        {{ produto.nome }}
                    </a>

                    <a class="fz-produto__preco-link link-produto px-1 text-center cursor-pointer d-block"
                       @click="abrirProduto"
                       :href="linkProduto">
                        <fz-produto-preco
                            :produto="produto"
                            :preco-destaque="precoDestaque"
                            :somente-orcamentos="somenteOrcamentos"
                            :precos-restritos="precosRestritos"
                            :pagina-live="paginaLive"
                            :ativar-simulador-parcelas="ativarSimuladorParcelas"
                            variacao="compacto"
                            alinhamento="centro">
                        </fz-produto-preco>
                    </a>

                    <!-- Simulador de Parcelas - Melhor Parcelamento (apenas quando não é live) -->
                    <fz-simulador-parcelas-melhor-parcelamento
                        v-if="!paginaLive && !somenteOrcamentos && !precosRestritos && ativarSimuladorParcelas && !produto.venda_externa"
                        :produto="produto"
                        :simulacao="produto.simulacao_parcelas"
                        :abrir-modal="true"
                        alinhamento="centro"
                        variacao="compacto"
                        class="fz-produto__simulador text-left px-1">
                    </fz-simulador-parcelas-melhor-parcelamento>

                    <div class="w-100 text-center px-2 mb-1 mt-2">
                        <fz-produto-botao-compra
                            :produto="produto"
                            :texto-botao="textoBotaoAcao"
                            :icone-botao="iconeBotaoAcao"
                            :precos-restritos="precosRestritos"
                            :pagina-live="paginaLive"
                            :habilitar-avise-me-quando-chegar="habilitarAviseMeQuandoChegar"
                            class="w-100"
                            @click="abrirProduto">
                        </fz-produto-botao-compra>
                    </div>

                </div>
            </div>
        </div>
    </div>
    `},FZComponents.ProdutoVideo={components:{"p-tag":PrimeVue.Tag,"fz-produto-slider":FZComponents.ProdutoSlider,"fz-tag-campanha-promocional":FZComponents.TagCampanhaPromocional,"fz-produto-preco":FZComponents.ProdutoPreco,"fz-produto-botao-compra":FZComponents.ProdutoBotaoCompra,"fz-simulador-parcelas-melhor-parcelamento":FZComponents.SimuladorParcelasMelhorParcelamento,"fz-produto-acoes":FZComponents.ProdutoAcoes},mixins:[ProdutoBaseMixin],data(){return{videoProgress:0,isMuted:!0}},props:{class:{type:String,default:""},produto:{type:Object,required:!0},prefixoSlider:{type:String,default:""},precoDestaque:{type:String,default:"preco_original"},precosRestritos:{type:Boolean,default:!1},paginaLive:{type:Boolean,default:!1},ocultarDestaque:{type:Boolean,default:!1},somenteOrcamentos:{type:Boolean,default:!1},mostrarQuantidadeVenda:{type:Boolean,default:!1},habilitarCurtidas:{type:Boolean,default:!1},habilitarPerguntas:{type:Boolean,default:!1},permitirCompartilharProduto:{type:Boolean,default:!1},ativarSimuladorParcelas:{type:Boolean,default:!1},textoBotaoAcaoProdutos:{type:String,default:"Comprar"},iconeBotaoAcaoProdutos:{type:String,default:"pi pi-shopping-cart"},habilitarAviseMeQuandoChegar:{type:Boolean,default:!1},gridFormatoImagem:{type:String,default:"original"},campanhaPromocionalAtivaNoMomento:{type:Boolean,default:!1},campanhaPromocionalTagProdutosAtivada:{type:Boolean,default:!1},campanhaPromocionalTagProdutosTexto:{type:String,default:""},campanhaPromocionalTagProdutosCorFundo:{type:String,default:"#28a745"},campanhaPromocionalTagProdutosCorTexto:{type:String,default:"#ffffff"}},computed:{totalQuantidade(){return CarrinhoManager.obterTotalQuantidadeProduto(this.produto.id,this.configsLoja.carrinho)},temMidia(){var _a,_b,_c,_d;return!!((_b=(_a=this.produto)==null?void 0:_a.video)!=null&&_b.url||(_d=(_c=this.produto)==null?void 0:_c.imagens)!=null&&_d[0])}},methods:{onVideoTimeUpdate(event){event.target.duration&&(this.videoProgress=event.target.currentTime/event.target.duration*100)},toggleMute(event){event.stopPropagation(),this.isMuted=!this.isMuted,this.$refs.video&&(this.$refs.video.muted=this.isMuted)}},template:`
    <div v-if="temMidia" :class="['fz-produto', 'fz-produto--video', classe, 'px-2', 'produto_div_' + produto.id]" :id="'produto_div_' + produto.id" style="margin-bottom: 15px !important;">
        <div class="container-fluid">
            <div class="row">
                <div class="fz-produto__card w-100">
                    <div class="fz-produto__media-ratio">
                        <video
                            v-if="produto.video?.url"
                            ref="video"
                            @click="abrirProduto"
                            class="fz-produto__media-video"
                            :src="obterURLArquivos(produto.video.url)"
                            :poster="produto.video?.thumb ? obterURLArquivos(produto.video.thumb) : ''"
                            @timeupdate="onVideoTimeUpdate"
                            autoplay
                            muted
                            loop
                            playsinline
                            preload="metadata"
                            disablePictureInPicture
                            controlsList="nodownload nofullscreen noremoteplayback">
                        </video>
                        <img
                            v-else-if="produto.imagens?.[0]"
                            @click="abrirProduto"
                            class="fz-produto__media-image"
                            :src="obterURLArquivos(produto.imagens[0])"
                            :alt="produto.nome">

                        <!-- Gradient Overlay -->
                        <div class="fz-produto__overlay-gradient"></div>

                        <!-- Video Progress Bar -->
                        <div v-if="produto.video?.url" class="fz-produto__video-progress">
                            <div class="fz-produto__video-progress-bar" :style="{ width: videoProgress + '%' }"></div>
                        </div>

                        <!-- Mute Button -->
                        <button
                            v-if="produto.video?.url"
                            class="fz-produto__video-mute-btn"
                            @click="toggleMute"
                            :aria-label="isMuted ? 'Ativar som' : 'Desativar som'">
                            <i :class="isMuted ? 'pi pi-volume-off' : 'pi pi-volume-up'"></i>
                        </button>

                        <!-- Product Info Overlay -->
                        <div class="fz-produto__overlay-info" @click="abrirProduto">
                            <img
                                v-if="produto.imagens?.[0]"
                                class="fz-produto__overlay-thumb"
                                :src="obterURLArquivos(produto.imagens[0])"
                                :alt="produto.nome">
                            <div class="fz-produto__overlay-content">
                                <p class="fz-produto__overlay-nome">{{ produto.nome }}</p>

                                <fz-produto-preco
                                    :produto="produto"
                                    :preco-destaque="precoDestaque"
                                    :somente-orcamentos="somenteOrcamentos"
                                    :precos-restritos="precosRestritos"
                                    variacao="compacto"
                                    class-container="fz-produto__overlay-preco">
                                </fz-produto-preco>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    `},FZComponents.ProdutoGrid2={components:{"p-tag":PrimeVue.Tag,"fz-produto-slider":FZComponents.ProdutoSlider,"fz-tag-campanha-promocional":FZComponents.TagCampanhaPromocional,"fz-produto-preco":FZComponents.ProdutoPreco,"fz-produto-botao-compra":FZComponents.ProdutoBotaoCompra,"fz-simulador-parcelas-melhor-parcelamento":FZComponents.SimuladorParcelasMelhorParcelamento,"fz-produto-acoes":FZComponents.ProdutoAcoes},mixins:[ProdutoBaseMixin],props:{class:{type:String,default:""},produto:{type:Object,required:!0},prefixoSlider:{type:String,default:""},precoDestaque:{type:String,default:"preco_original"},precosRestritos:{type:Boolean,default:!1},paginaLive:{type:Boolean,default:!1},ocultarDestaque:{type:Boolean,default:!1},somenteOrcamentos:{type:Boolean,default:!1},mostrarQuantidadeVenda:{type:Boolean,default:!1},habilitarCurtidas:{type:Boolean,default:!1},habilitarPerguntas:{type:Boolean,default:!1},permitirCompartilharProduto:{type:Boolean,default:!1},ativarSimuladorParcelas:{type:Boolean,default:!1},textoBotaoAcaoProdutos:{type:String,default:"Comprar"},iconeBotaoAcaoProdutos:{type:String,default:"pi pi-shopping-cart"},habilitarAviseMeQuandoChegar:{type:Boolean,default:!1},gridFormatoImagem:{type:String,default:"original"},campanhaPromocionalAtivaNoMomento:{type:Boolean,default:!1},campanhaPromocionalTagProdutosAtivada:{type:Boolean,default:!1},campanhaPromocionalTagProdutosTexto:{type:String,default:""},campanhaPromocionalTagProdutosCorFundo:{type:String,default:"#28a745"},campanhaPromocionalTagProdutosCorTexto:{type:String,default:"#ffffff"}},template:`
    <div :class="['fz-produto', 'fz-produto--grid-2', classe, 'px-2', 'produto_div_' + produto.id]" :id="'produto_div_' + produto.id" style="margin-bottom: 5px !important;">
        <div class="container-fluid">
            <div class="row">
                <div class="fz-produto__card bloco-mensagem w-100">

                    <div class="fz-produto__imagem-container p-2">
                        <fz-produto-slider
                            :produto="produto"
                            :prefixo-slider="prefixoSlider"
                            :ocultar-destaque="ocultarDestaque"
                            :habilitar-avise-me-quando-chegar="habilitarAviseMeQuandoChegar"
                            :abrir-link-direto="abrirLinkDireto"
                            :grid-formato-imagem="gridFormatoImagem">
                        </fz-produto-slider>
                    </div>

                    <fz-tag-campanha-promocional
                        :produto="produto"
                        :campanha-promocional-ativa-no-momento="campanhaPromocionalAtivaNoMomento"
                        :campanha-promocional-tag-produtos-ativada="campanhaPromocionalTagProdutosAtivada"
                        :campanha-promocional-tag-produtos-texto="campanhaPromocionalTagProdutosTexto"
                        :campanha-promocional-tag-produtos-cor-fundo="campanhaPromocionalTagProdutosCorFundo"
                        :campanha-promocional-tag-produtos-cor-texto="campanhaPromocionalTagProdutosCorTexto">
                    </fz-tag-campanha-promocional>

                    <a class="fz-produto__titulo link-produto px-2 pt-2 pb-2 text-center cursor-pointer d-block"
                       @click="abrirProduto"
                       :href="linkProduto">
                        {{ produto.nome }}
                    </a>

                    <a class="fz-produto__preco-link link-produto px-3 pt-1 pb-2 text-center cursor-pointer d-block"
                       @click="abrirProduto"
                       :href="linkProduto">
                        <fz-produto-preco
                            :produto="produto"
                            :preco-destaque="precoDestaque"
                            :somente-orcamentos="somenteOrcamentos"
                            :precos-restritos="precosRestritos"
                            :pagina-live="paginaLive"
                            :ativar-simulador-parcelas="ativarSimuladorParcelas"
                            alinhamento="centro">
                        </fz-produto-preco>
                    </a>

                    <!-- Quantidade de vendas -->
                    <a v-if="mostrarQuantidadeVenda && produto.total_vendas > 0"
                       class="fz-produto__vendas link-produto px-3 pt-0 pb-1 text-center cursor-pointer d-block"
                       @click="abrirProduto"
                       :href="linkProduto">
                        <p-tag
                            :value="produto.total_vendas + (produto.total_vendas == 1 ? ' venda' : ' vendas')"
                            severity="secondary"
                            icon="pi pi-shopping-cart"
                            class="fz-produto__tag-vendas"
                        ></p-tag>
                    </a>

                    <!-- Botão de ação -->
                    <div class="fz-produto__botao-container text-center px-3" :class="paginaLive ? 'pt-0 pb-2' : 'pt-2 pb-0'">
                        <fz-produto-botao-compra
                            :produto="produto"
                            :texto-botao="textoBotaoAcao"
                            :icone-botao="iconeBotaoAcao"
                            :precos-restritos="precosRestritos"
                            :pagina-live="paginaLive"
                            :habilitar-avise-me-quando-chegar="habilitarAviseMeQuandoChegar"
                            @click="abrirProduto">
                        </fz-produto-botao-compra>
                    </div>

                    <!-- Simulador de Parcelas - Melhor Parcelamento (apenas quando não é live) -->
                    <fz-simulador-parcelas-melhor-parcelamento
                        v-if="!paginaLive && !somenteOrcamentos && !precosRestritos && ativarSimuladorParcelas && !produto.venda_externa"
                        :produto="produto"
                        :simulacao="produto.simulacao_parcelas"
                        :abrir-modal="true"
                        alinhamento="centro"
                        class="fz-produto__simulador px-1 pt-3 pb-1 text-center">
                    </fz-simulador-parcelas-melhor-parcelamento>

                    <!-- Curtidas, Perguntas, Compartilhar (apenas quando não é live) -->
                    <div v-if="!paginaLive" class="fz-produto__acoes-container d-flex justify-content-around text-center">
                        <fz-produto-acoes
                            :produto="produto"
                            :habilitar-curtidas="habilitarCurtidas"
                            :habilitar-perguntas="habilitarPerguntas"
                            :permitir-compartilhar-produto="permitirCompartilharProduto">
                        </fz-produto-acoes>
                    </div>

                </div>
            </div>
        </div>
    </div>
    `},FZComponents.ProdutoGridNovo={components:{"p-button":PrimeVue.Button,"fz-produto-slider":FZComponents.ProdutoSlider,"fz-tag-campanha-promocional":FZComponents.TagCampanhaPromocional,"fz-produto-preco":FZComponents.ProdutoPreco,"fz-produto-botao-compra":FZComponents.ProdutoBotaoCompra,"fz-simulador-parcelas-melhor-parcelamento":FZComponents.SimuladorParcelasMelhorParcelamento,"fz-variacao-sem-variacao":FZComponents.VariacaoSemVariacao,"fz-variacao-com-variacao":FZComponents.VariacaoComVariacao,"fz-variacao-com-grade":FZComponents.VariacaoComGrade},mixins:[ProdutoBaseMixin],props:{class:{type:String,default:""},produto:{type:Object,required:!0},prefixoSlider:{type:String,default:""},precoDestaque:{type:String,default:"preco_original"},precosRestritos:{type:Boolean,default:!1},paginaLive:{type:Boolean,default:!1},ocultarDestaque:{type:Boolean,default:!1},somenteOrcamentos:{type:Boolean,default:!1},mostrarQuantidadeVenda:{type:Boolean,default:!1},habilitarCurtidas:{type:Boolean,default:!1},habilitarPerguntas:{type:Boolean,default:!1},permitirCompartilharProduto:{type:Boolean,default:!1},ativarSimuladorParcelas:{type:Boolean,default:!1},textoBotaoAcaoProdutos:{type:String,default:"Comprar"},iconeBotaoAcaoProdutos:{type:String,default:"pi pi-shopping-cart"},habilitarAviseMeQuandoChegar:{type:Boolean,default:!1},gridFormatoImagem:{type:String,default:"original"},exibirSlideImagens:{type:Boolean,default:!0},exibirVariacoesDiretoPagina:{type:Boolean,default:!1},campanhaPromocionalAtivaNoMomento:{type:Boolean,default:!1},campanhaPromocionalTagProdutosAtivada:{type:Boolean,default:!1},campanhaPromocionalTagProdutosTexto:{type:String,default:""},campanhaPromocionalTagProdutosCorFundo:{type:String,default:"#28a745"},campanhaPromocionalTagProdutosCorTexto:{type:String,default:"#ffffff"}},data(){return{gradeAberta:!1}},computed:{deveExibirVariacoesDiretoPagina(){return this.exibirVariacoesDiretoPagina&&!this.produto.venda_externa&&!this.precosRestritos},determinarComponenteVariacao(){if(this.produto.grade&&Object.keys(this.produto.grade).length>0&&!this.produto.grade_quebrada)return"fz-variacao-com-grade";const temSubgrupos=this.produto.subgrupos_variacoes&&Object.keys(this.produto.subgrupos_variacoes).length>0;return!this.produto.variacoes||Object.keys(this.produto.variacoes).length===0?temSubgrupos?"fz-variacao-com-variacao":this.produto.controlar_estoque!="1"||this.produto.estoque&&this.produto.estoque[0]>0?"fz-variacao-sem-variacao":null:"fz-variacao-com-variacao"},gradeDisponivel(){return this.exibirBotaoVariacoes&&!this.variacoesAcimaDoLimite},variacoesAcimaDoLimite(){const maxVariacoes=this.configsLoja.maxVariacoesMostrar||20;return Number(this.produto.total_disponibilidade)>maxVariacoes},exibirBotaoVariacoes(){return this.deveExibirVariacoesDiretoPagina&&!!this.determinarComponenteVariacao},exibirTagCampanha(){return this.campanhaPromocionalAtivaNoMomento&&this.campanhaPromocionalTagProdutosAtivada&&!!this.campanhaPromocionalTagProdutosTexto&&this.produto.campanha_promocional==!0}},methods:{abrirVariacoes(event){if(this.variacoesAcimaDoLimite){if(event&&event.preventDefault(),typeof abrirModalProdutoVue=="function"){abrirModalProdutoVue(this.produto);return}this.abrirProduto(event);return}this.alternarGrade()},alternarGrade(){this.gradeDisponivel&&(this.gradeAberta=!this.gradeAberta)}},template:`
    <div :class="['fz-produto', 'fz-produto--grid-novo', 'fz-produto--grid-novo--' + gridFormatoImagem, classe, 'px-2', 'pb-3', 'produto_div_' + produto.id]" :id="'produto_div_' + produto.id">
        <article class="fz-produto__card" :class="{ 'is-grade-aberta': gradeAberta }">
            <div class="fz-produto__imagem-container" :class="{ 'has-campanha': exibirTagCampanha }">
                <fz-produto-slider
                    :produto="produto"
                    :prefixo-slider="prefixoSlider"
                    :ocultar-destaque="ocultarDestaque"
                    :habilitar-avise-me-quando-chegar="habilitarAviseMeQuandoChegar"
                    :abrir-link-direto="abrirLinkDireto"
                    :exibir-slide-imagens="exibirSlideImagens"
                    :grid-formato-imagem="gridFormatoImagem">
                </fz-produto-slider>

                <fz-tag-campanha-promocional
                    :produto="produto"
                    :campanha-promocional-ativa-no-momento="campanhaPromocionalAtivaNoMomento"
                    :campanha-promocional-tag-produtos-ativada="campanhaPromocionalTagProdutosAtivada"
                    :campanha-promocional-tag-produtos-texto="campanhaPromocionalTagProdutosTexto"
                    :campanha-promocional-tag-produtos-cor-fundo="campanhaPromocionalTagProdutosCorFundo"
                    :campanha-promocional-tag-produtos-cor-texto="campanhaPromocionalTagProdutosCorTexto">
                </fz-tag-campanha-promocional>

                <p-button
                    v-if="habilitarCurtidas"
                    :class="['fz-produto-grid-novo__curtir', 'curtir_produto_' + produto.id, { 'is-curtido': produto.curtido }]"
                    @click.stop="curtirProduto"
                    :icon="produto.curtido ? 'pi pi-heart-fill' : 'pi pi-heart'"
                    severity="primary"
                    variant="text"
                    rounded
                    :aria-label="produto.curtido ? 'Descurtir produto' : 'Curtir produto'">
                </p-button>
            </div>

            <div class="fz-produto-grid-novo__conteudo">
                <a class="fz-produto__titulo fz-produto-grid-novo__titulo link-produto cursor-pointer d-block"
                   @click="abrirProduto"
                   :href="linkProduto">
                    {{ produto.nome }}
                </a>

                <div v-if="mostrarQuantidadeVenda && produto.total_vendas > 0" class="fz-produto-grid-novo__prova-social">
                    <strong><i class="pi pi-shopping-cart mr-1"></i>{{ produto.total_vendas }} {{ produto.total_vendas == 1 ? 'venda' : 'vendas' }}</strong>
                </div>

                <a class="fz-produto__preco-link fz-produto-grid-novo__preco-link link-produto cursor-pointer d-block"
                   @click="abrirProduto"
                   :href="linkProduto">
                    <fz-produto-preco
                        :produto="produto"
                        :preco-destaque="precoDestaque"
                        :somente-orcamentos="somenteOrcamentos"
                        :precos-restritos="precosRestritos"
                        :pagina-live="paginaLive"
                        :ativar-simulador-parcelas="ativarSimuladorParcelas"
                        modelo-melhor-desconto="compacto"
                        alinhamento="esquerda">
                    </fz-produto-preco>
                </a>

                <fz-simulador-parcelas-melhor-parcelamento
                    v-if="!paginaLive && !somenteOrcamentos && !precosRestritos && ativarSimuladorParcelas && !produto.venda_externa"
                    :produto="produto"
                    :simulacao="produto.simulacao_parcelas"
                    :abrir-modal="true"
                    alinhamento="esquerda"
                    modelo-icones="svg"
                    :mostrar-label-formas-pagamento="true"
                    :ocultar-melhor-parcelamento="true"
                    class="fz-produto-grid-novo__simulador fz-produto-grid-novo__simulador--contornos">
                </fz-simulador-parcelas-melhor-parcelamento>

                <div
                    class="fz-produto__botao-container fz-produto-grid-novo__botao-container fz-produto-grid-novo__acoes"
                    :class="{ 'fz-produto-grid-novo__acoes--simples': !exibirBotaoVariacoes }">
                    <fz-produto-botao-compra
                        :produto="produto"
                        :texto-botao="textoBotaoAcao"
                        :icone-botao="iconeBotaoAcao"
                        :precos-restritos="precosRestritos"
                        :pagina-live="paginaLive"
                        :habilitar-avise-me-quando-chegar="habilitarAviseMeQuandoChegar"
                        @click="abrirProduto">
                    </fz-produto-botao-compra>

                    <button
                        v-if="exibirBotaoVariacoes"
                        type="button"
                        class="fz-produto-grid-novo__grade-toggle"
                        :aria-expanded="gradeDisponivel && gradeAberta"
                        :aria-label="variacoesAcimaDoLimite ? 'Ver variações do produto' : (gradeAberta ? 'Fechar grade' : 'Abrir grade')"
                        @click.stop="abrirVariacoes">
                        {{ gradeAberta ? '-' : '+' }}
                    </button>
                </div>
            </div>

            <div v-if="gradeDisponivel" class="fz-produto-grid-novo__grade" :class="{ 'is-open': gradeAberta }">
                <div class="fz-produto-grid-novo__grade-cabecalho">
                    <strong>Escolha as Variações</strong>
                </div>

                <component
                    :is="determinarComponenteVariacao"
                    v-if="gradeAberta"
                    :produto="produto"
                    :catalogo-id="configsLoja.catalogoId"
                    :carrinho="configsLoja.carrinho"
                    :somente-orcamentos="somenteOrcamentos"
                    :precos-restritos="precosRestritos"
                    :exibir-preco="false"
                    :exibir-sku="false"
                    :exibir-divisoria="false"
                    :exibir-descontos="true"
                    :video-ativo="false"
                    :variacoes-isoladas="true"
                    :modelo-condensado="true"
                    :usar-subgrupos-como-lista="true">
                </component>
            </div>
        </article>
    </div>
    `},FZComponents.ProdutoGrid={components:{"fz-produto-slider":FZComponents.ProdutoSlider,"fz-tag-campanha-promocional":FZComponents.TagCampanhaPromocional,"fz-produto-acoes":FZComponents.ProdutoAcoes,"fz-produto-preco":FZComponents.ProdutoPreco,"fz-simulador-parcelas-melhor-parcelamento":FZComponents.SimuladorParcelasMelhorParcelamento,"fz-produto-botao-compra":FZComponents.ProdutoBotaoCompra,"fz-variacao-sem-variacao":FZComponents.VariacaoSemVariacao,"fz-variacao-com-variacao":FZComponents.VariacaoComVariacao,"fz-variacao-com-grade":FZComponents.VariacaoComGrade},mixins:[ProdutoBaseMixin],props:{class:{type:String,default:""},produto:{type:Object,required:!0},prefixoSlider:{type:String,default:""},precoDestaque:{type:String,default:"preco_original"},precosRestritos:{type:Boolean,default:!1},paginaLive:{type:Boolean,default:!1},ocultarDestaque:{type:Boolean,default:!1},somenteOrcamentos:{type:Boolean,default:!1},mostrarQuantidadeVenda:{type:Boolean,default:!1},habilitarCurtidas:{type:Boolean,default:!1},habilitarPerguntas:{type:Boolean,default:!1},permitirCompartilharProduto:{type:Boolean,default:!1},ativarSimuladorParcelas:{type:Boolean,default:!1},textoBotaoAcaoProdutos:{type:String,default:"Comprar"},iconeBotaoAcaoProdutos:{type:String,default:"pi pi-shopping-cart"},habilitarAviseMeQuandoChegar:{type:Boolean,default:!1},gridFormatoImagem:{type:String,default:"original"},exibirVariacoesDiretoPagina:{type:Boolean,default:!1},campanhaPromocionalAtivaNoMomento:{type:Boolean,default:!1},campanhaPromocionalTagProdutosAtivada:{type:Boolean,default:!1},campanhaPromocionalTagProdutosTexto:{type:String,default:""},campanhaPromocionalTagProdutosCorFundo:{type:String,default:"#28a745"},campanhaPromocionalTagProdutosCorTexto:{type:String,default:"#ffffff"}},computed:{deveExibirVariacoesDiretoPagina(){if(!this.exibirVariacoesDiretoPagina||this.produto.venda_externa||this.precosRestritos)return!1;const maxVariacoes=this.configsLoja.maxVariacoesMostrar||20;return!(this.produto.total_disponibilidade>maxVariacoes)},determinarComponenteVariacao(){return this.produto.grade&&Object.keys(this.produto.grade).length>0&&!this.produto.grade_quebrada?"fz-variacao-com-grade":!this.produto.variacoes||Object.keys(this.produto.variacoes).length===0?this.produto.controlar_estoque!="1"||this.produto.estoque&&this.produto.estoque[0]>0?"fz-variacao-sem-variacao":null:"fz-variacao-com-variacao"}},template:`
    <div :class="['fz-produto', 'fz-produto--grid', classe, 'produtos_div', 'produto_div_' + produto.id]" :id="'produto_div_' + produto.id" style="margin-bottom: 45px !important;">
                <div class="fz-produto__card bloco-mensagem w-100 text-center">
                    <!-- Category link above image -->
                    <a class="fz-produto__categoria link-produto mt-0 mb-1 cursor-pointer text-left"
                       @click="abrirProduto"
                       :href="linkProduto">
                        {{ produto.categoria_nome }}
                    </a>

                    <div class="fz-produto__imagem-container w-100">
                        <fz-produto-slider
                            :produto="produto"
                            :prefixo-slider="prefixoSlider"
                            :ocultar-destaque="ocultarDestaque"
                            :habilitar-avise-me-quando-chegar="habilitarAviseMeQuandoChegar"
                            :abrir-link-direto="abrirLinkDireto"
                            :grid-formato-imagem="gridFormatoImagem">
                        </fz-produto-slider>
                    </div>

                    <fz-tag-campanha-promocional
                        :produto="produto"
                        :campanha-promocional-ativa-no-momento="campanhaPromocionalAtivaNoMomento"
                        :campanha-promocional-tag-produtos-ativada="campanhaPromocionalTagProdutosAtivada"
                        :campanha-promocional-tag-produtos-texto="campanhaPromocionalTagProdutosTexto"
                        :campanha-promocional-tag-produtos-cor-fundo="campanhaPromocionalTagProdutosCorFundo"
                        :campanha-promocional-tag-produtos-cor-texto="campanhaPromocionalTagProdutosCorTexto">
                    </fz-tag-campanha-promocional>

                    <!-- Interactions above title -->
                    <div class="fz-produto__acoes-vendas-container d-flex justify-content-around align-items-center mt-2">
                        <fz-produto-acoes
                            :produto="produto"
                            :habilitar-curtidas="habilitarCurtidas"
                            :habilitar-perguntas="habilitarPerguntas"
                            :permitir-compartilhar-produto="permitirCompartilharProduto">
                        </fz-produto-acoes>

                        <!-- Quantidade de vendas -->
                        <p v-if="mostrarQuantidadeVenda && produto.total_vendas > 0"
                           class="fz-produto__badge-vendas badge badge-default text-dark m-0"
                           style="font-size:12px;">
                            {{ produto.total_vendas }} {{ produto.total_vendas == 1 ? "vendido" : "vendidos" }}
                        </p>
                    </div>

                    <a class="fz-produto__titulo link-produto d-block font-weight-bold my-2 cursor-pointer"
                       @click="abrirProduto"
                       :href="linkProduto">
                        {{ produto.nome }}
                    </a>

                    <a class="fz-produto__preco-link link-produto d-block my-2 cursor-pointer"
                       @click="abrirProduto"
                       :href="linkProduto">
                        <fz-produto-preco
                            :produto="produto"
                            :preco-destaque="precoDestaque"
                            :somente-orcamentos="somenteOrcamentos"
                            :precos-restritos="precosRestritos"
                            :pagina-live="paginaLive"
                            :ativar-simulador-parcelas="ativarSimuladorParcelas"
                            alinhamento="centro">
                        </fz-produto-preco>
                    </a>

                    <!-- Simulador de Parcelas - Melhor Parcelamento -->
                    <div v-if="!somenteOrcamentos && !precosRestritos && ativarSimuladorParcelas && !produto.venda_externa" class="fz-produto__simulador d-block my-2">
                        <fz-simulador-parcelas-melhor-parcelamento
                            :produto="produto"
                            :simulacao="produto.simulacao_parcelas"
                            :abrir-modal="true"
                            alinhamento="centro">
                        </fz-simulador-parcelas-melhor-parcelamento>
                    </div>

                    <!-- Botão de ação -->
                    <div v-if="!deveExibirVariacoesDiretoPagina" class="fz-produto__botao-container my-2 w-100 text-center">
                        <fz-produto-botao-compra
                            :produto="produto"
                            :texto-botao="textoBotaoAcao"
                            :precos-restritos="precosRestritos"
                            :pagina-live="false"
                            :habilitar-avise-me-quando-chegar="habilitarAviseMeQuandoChegar"
                            @click="abrirProduto"
                            style="font-size: 16px;">
                        </fz-produto-botao-compra>
                    </div>

                    <!-- Variações Direto na Página -->
                        <component
                            :is="determinarComponenteVariacao"
                            v-if="deveExibirVariacoesDiretoPagina && determinarComponenteVariacao"
                            :produto="produto"
                            :catalogo-id="configsLoja.catalogoId"
                            :carrinho="configsLoja.carrinho"
                            :somente-orcamentos="somenteOrcamentos"
                            :precos-restritos="precosRestritos"
                            :exibir-preco="true"
                            :exibir-sku="true"
                            :exibir-divisoria="true"
                            :exibir-descontos="true"
                            :video-ativo="false"
                            :variacoes-isoladas="true">
                        </component>
                </div>
    </div>
    `},FZComponents.ProdutoLista={components:{"fz-produto-slider":FZComponents.ProdutoSlider,"fz-produto-acoes":FZComponents.ProdutoAcoes,"fz-tag-campanha-promocional":FZComponents.TagCampanhaPromocional,"fz-produto-preco":FZComponents.ProdutoPreco,"fz-simulador-parcelas-melhor-parcelamento":FZComponents.SimuladorParcelasMelhorParcelamento,"fz-produto-botao-compra":FZComponents.ProdutoBotaoCompra,"fz-variacao-sem-variacao":FZComponents.VariacaoSemVariacao,"fz-variacao-com-variacao":FZComponents.VariacaoComVariacao,"fz-variacao-com-grade":FZComponents.VariacaoComGrade},mixins:[ProdutoBaseMixin],props:{class:{type:String,default:""},produto:{type:Object,required:!0},prefixoSlider:{type:String,default:""},precoDestaque:{type:String,default:"preco_original"},precosRestritos:{type:Boolean,default:!1},paginaLive:{type:Boolean,default:!1},ocultarDestaque:{type:Boolean,default:!1},somenteOrcamentos:{type:Boolean,default:!1},mostrarQuantidadeVenda:{type:Boolean,default:!1},habilitarCurtidas:{type:Boolean,default:!1},habilitarPerguntas:{type:Boolean,default:!1},permitirCompartilharProduto:{type:Boolean,default:!1},ativarSimuladorParcelas:{type:Boolean,default:!1},textoBotaoAcaoProdutos:{type:String,default:"Comprar"},iconeBotaoAcaoProdutos:{type:String,default:"pi pi-shopping-cart"},habilitarAviseMeQuandoChegar:{type:Boolean,default:!1},gridFormatoImagem:{type:String,default:"original"},exibirVariacoesDiretoPagina:{type:Boolean,default:!1},campanhaPromocionalAtivaNoMomento:{type:Boolean,default:!1},campanhaPromocionalTagProdutosAtivada:{type:Boolean,default:!1},campanhaPromocionalTagProdutosTexto:{type:String,default:""},campanhaPromocionalTagProdutosCorFundo:{type:String,default:"#28a745"},campanhaPromocionalTagProdutosCorTexto:{type:String,default:"#ffffff"}},computed:{deveExibirVariacoesDiretoPagina(){if(!this.exibirVariacoesDiretoPagina||this.produto.venda_externa||this.precosRestritos)return!1;const maxVariacoes=this.configsLoja.maxVariacoesMostrar||20;return!(this.produto.total_disponibilidade>maxVariacoes)},determinarComponenteVariacao(){return this.produto.grade&&Object.keys(this.produto.grade).length>0&&!this.produto.grade_quebrada?"fz-variacao-com-grade":!this.produto.variacoes||Object.keys(this.produto.variacoes).length===0?this.produto.controlar_estoque!="1"||this.produto.estoque&&this.produto.estoque[0]>0?"fz-variacao-sem-variacao":null:"fz-variacao-com-variacao"}},template:`
    <div :class="[classe, 'fz-produto', 'fz-produto--lista', 'produtos_div', 'produto_div_' + produto.id]" :id="'produto_div_' + produto.id" style="margin-bottom: 5px !important;">
                <div class="fz-produto__card bloco-mensagem w-100">
                    <div class="row">
                        <!-- Left column: Image (5/12 width) -->
                        <div class="col-5 col-lg-4 col-xl-4">
                            <div class="fz-produto__imagem-container w-100">
                                <fz-produto-slider
                                    :produto="produto"
                                    :ocultar-destaque="ocultarDestaque"
                                    :prefixo-slider="prefixoSlider"
                                    :habilitar-avise-me-quando-chegar="habilitarAviseMeQuandoChegar"
                                    :abrir-link-direto="abrirLinkDireto"
                                    :grid-formato-imagem="gridFormatoImagem">
                                </fz-produto-slider>


                                <!-- Interactions -->
                                <fz-produto-acoes
                                    :produto="produto"
                                    :habilitar-curtidas="habilitarCurtidas"
                                    :habilitar-perguntas="habilitarPerguntas"
                                    :permitir-compartilhar-produto="permitirCompartilharProduto"
                                    class="fz-produto__acoes-container">
                                </fz-produto-acoes>
                            </div>
                        </div>

                        <!-- Right column: Details (7/12 width) -->
                        <div class="col-7 col-lg-8 col-xl-8">
                            <fz-tag-campanha-promocional
                                :produto="produto"
                                :campanha-promocional-ativa-no-momento="campanhaPromocionalAtivaNoMomento"
                                :campanha-promocional-tag-produtos-ativada="campanhaPromocionalTagProdutosAtivada"
                                :campanha-promocional-tag-produtos-texto="campanhaPromocionalTagProdutosTexto"
                                :campanha-promocional-tag-produtos-cor-fundo="campanhaPromocionalTagProdutosCorFundo"
                                :campanha-promocional-tag-produtos-cor-texto="campanhaPromocionalTagProdutosCorTexto">
                            </fz-tag-campanha-promocional>

                            <a class="fz-produto__titulo link-produto mt-2 mb-1 font-weight-bold cursor-pointer"
                               style="font-size: 15px;"
                               @click="abrirProduto"
                               :href="linkProduto">
                                {{ produto.nome }}
                            </a>

                            <a class="fz-produto__categoria link-produto mt-2 mb-1 cursor-pointer" v-if="produto.categoria_nome"
                               @click="abrirProduto"
                               :href="linkProduto">
                                <i class="fa fa-tags"></i> {{ produto.categoria_nome }}
                            </a>

                            <!-- Quantidade de vendas -->
                            <a v-if="mostrarQuantidadeVenda && produto.total_vendas > 0"
                               class="fz-produto__vendas link-produto mt-2 mb-1 cursor-pointer"
                               @click="abrirProduto"
                               :href="linkProduto">
                                <i class="fa fa-shopping-cart"></i> {{ produto.total_vendas }}
                                {{ produto.total_vendas == 1 ? 'vendido' : 'vendidos' }}
                            </a>

                            <!-- Preços -->
                            <a class="fz-produto__preco-link link-produto w-100 pt-2 pb-0 cursor-pointer"
                               @click="abrirProduto"
                               :href="linkProduto">
                                <fz-produto-preco
                                    :produto="produto"
                                    :preco-destaque="precoDestaque"
                                    :somente-orcamentos="somenteOrcamentos"
                                    :precos-restritos="precosRestritos"
                                    :pagina-live="paginaLive"
                                    :ativar-simulador-parcelas="ativarSimuladorParcelas"
                                    alinhamento="esquerda">
                                </fz-produto-preco>
                            </a>

                            <!-- Simulador de Parcelas - Melhor Parcelamento -->
                            <div v-if="!somenteOrcamentos && ativarSimuladorParcelas && !produto.venda_externa" class="fz-produto__simulador w-100 pt-2 pb-0">
                                <fz-simulador-parcelas-melhor-parcelamento
                                    :produto="produto"
                                    :simulacao="produto.simulacao_parcelas"
                                    :abrir-modal="true"
                                    alinhamento="esquerda">
                                </fz-simulador-parcelas-melhor-parcelamento>
                            </div>

                            <!-- Botão de ação -->
                            <div v-if="!deveExibirVariacoesDiretoPagina" class="fz-produto__botao-container w-100 pt-2 pb-0">
                                <fz-produto-botao-compra
                                    :produto="produto"
                                    :texto-botao="textoBotaoAcao"
                                    :icone-botao="iconeBotaoAcao"
                                    :precos-restritos="precosRestritos"
                                    :pagina-live="paginaLive"
                                    :habilitar-avise-me-quando-chegar="habilitarAviseMeQuandoChegar"
                                    @click="abrirProduto">
                                </fz-produto-botao-compra>
                            </div>
                        </div>
                    </div>

                    <!-- Variações Direto na Página -->
                        <component
                            :is="determinarComponenteVariacao"
                            v-if="deveExibirVariacoesDiretoPagina && determinarComponenteVariacao"
                            :produto="produto"
                            :catalogo-id="configsLoja.catalogoId"
                            :carrinho="configsLoja.carrinho"
                            :somente-orcamentos="somenteOrcamentos"
                            :precos-restritos="precosRestritos"
                            :exibir-preco="true"
                            :exibir-sku="true"
                            :exibir-divisoria="true"
                            :exibir-descontos="true"
                            :video-ativo="false"
                            :variacoes-isoladas="true">
                        </component>
                </div>
    </div>
    `},FZComponents.Produto={components:{"produto-grid":FZComponents.ProdutoGrid,"produto-grid-novo":FZComponents.ProdutoGridNovo,"produto-grid-2":FZComponents.ProdutoGrid2,"produto-clean":FZComponents.ProdutoClean,"produto-clean-2":FZComponents.ProdutoClean2,"produto-color":FZComponents.ProdutoColor,"produto-fancy":FZComponents.ProdutoFancy,"produto-video":FZComponents.ProdutoVideo,"produto-lista":FZComponents.ProdutoLista},props:{layout:{type:String,default:"grid_novo",validator:value=>["grid","grid_novo","grid_2","lista","clean","clean_2","color","fancy","video"].includes(value)},abrirLinkDireto:{type:Boolean,default:!1},class:{type:String,default:""},produto:{type:Object,required:!0},prefixoSlider:{type:String,default:""},exibirSlideImagens:{type:Boolean,default:!0},precoDestaque:{type:String,default:"preco_original"},precosRestritos:{type:Boolean,default:!1},paginaLive:{type:Boolean,default:!1},ocultarDestaque:{type:Boolean,default:!1},somenteOrcamentos:{type:Boolean,default:!1},mostrarQuantidadeVenda:{type:Boolean,default:!1},habilitarCurtidas:{type:Boolean,default:!1},habilitarPerguntas:{type:Boolean,default:!1},permitirCompartilharProduto:{type:Boolean,default:!1},ativarSimuladorParcelas:{type:Boolean,default:!1},textoBotaoAcaoProdutos:{type:String,default:"Comprar"},iconeBotaoAcaoProdutos:{type:String,default:"pi pi-shopping-cart"},habilitarAviseMeQuandoChegar:{type:Boolean,default:!1},gridFormatoImagem:{type:String,default:"original"},exibirVariacoesDiretoPagina:{type:Boolean,default:!1},campanhaPromocionalAtivaNoMomento:{type:Boolean,default:!1},campanhaPromocionalTagProdutosAtivada:{type:Boolean,default:!1},campanhaPromocionalTagProdutosTexto:{type:String,default:""},campanhaPromocionalTagProdutosCorFundo:{type:String,default:"#28a745"},campanhaPromocionalTagProdutosCorTexto:{type:String,default:"#ffffff"}},computed:{componentName(){return{grid:"produto-grid",grid_novo:"produto-grid-novo",grid_2:"produto-grid-2",lista:"produto-lista",clean:"produto-clean",clean_2:"produto-clean-2",fancy:"produto-fancy",color:"produto-color",video:"produto-video"}[this.layout]||"produto-grid-novo"}},template:`
        <component
            :is="componentName"
            v-bind="$props">
        </component>
    `};

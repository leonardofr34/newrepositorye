FZComponents.ProdutoModalSkeletonDetalhes={components:{"p-skeleton":PrimeVue.Skeleton},template:`
    <div class="fz-produto-conteudo__skeleton-detalhes">
        <!-- Preço -->
        <div class="py-3">
            <p-skeleton width="35%" height="2.5rem" class="mb-0"></p-skeleton>
        </div>

        <!-- Divisória -->
        <div class="w-100 mb-3">
            <p-skeleton width="40%" height="1.25rem" class="mt-2"></p-skeleton>
        </div>

        <!-- Variações -->
        <div class="fz-produto-conteudo__skeleton-variacoes">
            <p-skeleton v-for="n in 3" :key="n" width="100%" height="3.5rem" class="mb-2"></p-skeleton>
        </div>

        <!-- Botão -->
        <div class="mt-4 d-flex justify-content-center">
            <p-skeleton width="250px" height="2.5rem" border-radius="6px"></p-skeleton>
        </div>
    </div>
    `},FZComponents.ProdutoModalSkeleton={components:{"p-skeleton":PrimeVue.Skeleton,"fz-produto-modal-skeleton-detalhes":FZComponents.ProdutoModalSkeletonDetalhes},template:`
    <div class="fz-produto-conteudo__skeleton">
        <div class="row">
            <!-- Left Column - Gallery Skeleton -->
            <div class="col-12 col-lg-6 mb-4 mb-lg-0">
                <p-skeleton height="400px" class="fz-produto-conteudo__skeleton-galeria mb-3"></p-skeleton>
                <div class="d-flex gap-2">
                    <p-skeleton v-for="n in 4" :key="n" width="80px" height="60px" class="fz-produto-conteudo__skeleton-miniatura"></p-skeleton>
                </div>
            </div>

            <!-- Right Column - Header + Details Skeleton -->
            <div class="col-12 col-lg-6">
                <!-- Header -->
                <div class="fz-produto-conteudo__skeleton-header mb-3">
                    <p-skeleton width="70%" height="2rem" class="mb-2"></p-skeleton>
                    <p-skeleton width="40%" height="1.5rem" class="mb-0"></p-skeleton>
                </div>

                <!-- Details (reusing partial skeleton structure) -->
                <fz-produto-modal-skeleton-detalhes></fz-produto-modal-skeleton-detalhes>
            </div>
        </div>
    </div>
    `},FZComponents.DialogRegrasPrecos={components:{"p-dialog":PrimeVue.Dialog,"p-tag":PrimeVue.Tag,"p-divider":PrimeVue.Divider},mixins:[ProdutoConteudoMixin],computed:{visible:{get(){return this.conteudoStore.dialogRegrasPrecos.visible},set(value){this.conteudoStore.dialogRegrasPrecos.visible=value}},regrasCategoria(){return this.conteudoStore.dialogRegrasPrecos.regrasCategoria},regrasProduto(){return this.conteudoStore.dialogRegrasPrecos.regrasProduto},temRegras(){return this.regrasCategoria.length>0||this.regrasProduto.length>0}},template:`
    <p-dialog
        v-model:visible="visible"
        modal
        :draggable="false"
        :dismissableMask="true"
        header="Regras de Descontos"
        :style="{ width: '90vw', maxWidth: '550px' }"
        class="fz-dialog-regras-precos"
        :pt="{header: 'pb-2', content: 'pt-0'}"
    >
        <div v-if="temRegras">
            <!-- Regras da Categoria -->
            <div v-if="regrasCategoria.length > 0">
                <p-divider align="left" type="solid">
                    <i class="pi pi-tag"></i> <b>Desconto da Categoria</b>
                </p-divider>
                <div class="fz-dialog-regras-precos__lista mb-3">
                    <div v-for="(regra, index) in regrasCategoria" :key="'cat-' + index" class="fz-dialog-regras-precos__item">
                        <p class="mb-2" v-if="regra.tipoRegra === 'valor'">
                            Compras entre <strong>R$ {{ formatarPreco(regra.itensMinimo) }}</strong> e <strong>R$ {{ formatarPreco(regra.itensMaximo) }}</strong>: <strong>{{ regra.textoDesconto }}</strong>
                        </p>
                        <p class="mb-2" v-else>
                            Compras entre <strong>{{ regra.itensMinimo }}</strong> e <strong>{{ regra.itensMaximo }}</strong> itens: <strong>{{ regra.textoDesconto }}</strong>
                        </p>
                    </div>
                </div>
            </div>

            <!-- Regras do Produto -->
            <div v-if="regrasProduto.length > 0">
                <p-divider align="left" type="solid">
                    <i class="pi pi-box"></i> <b>Desconto do Produto</b>
                </p-divider>
                <div class="fz-dialog-regras-precos__lista">
                    <div v-for="(regra, index) in regrasProduto" :key="'prod-' + index" class="fz-dialog-regras-precos__item">
                        <p class="mb-2">
                            Compras entre <strong>{{ regra.itensMinimo }}</strong> e <strong>{{ regra.itensMaximo }}</strong> itens: <strong>{{ regra.textoDesconto }}</strong>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </p-dialog>
    `},FZComponents.DialogVideoExterno={components:{"p-dialog":PrimeVue.Dialog},mixins:[ProdutoConteudoMixin],data(){return{iframeLoaded:!1}},computed:{visible:{get(){return this.conteudoStore.dialogVideoExterno.visible},set(value){this.conteudoStore.dialogVideoExterno.visible=value,value||(this.iframeLoaded=!1)}},videoId(){return this.conteudoStore.dialogVideoExterno.videoId},service(){return this.conteudoStore.dialogVideoExterno.service},isInstagram(){return this.service==="instagram"},isYouTube(){return this.service==="youtube"},videoUrl(){return this.isInstagram?`https://www.instagram.com/p/${this.videoId}/embed/`:this.isYouTube?`https://www.youtube-nocookie.com/embed/${this.videoId}`:""},dialogWidth(){return this.isYouTube,"90vw"},dialogMaxWidth(){return this.isYouTube?"800px":"540px"}},watch:{visible(newVal){newVal&&this.videoUrl&&!this.iframeLoaded&&this.$nextTick(()=>{const iframe=this.$refs.videoIframe;iframe&&iframe.dataset.src&&(iframe.src=iframe.dataset.src,this.iframeLoaded=!0)})}},template:`
    <p-dialog
        v-model:visible="visible"
        modal
        :draggable="false"
        :dismissableMask="true"
        header="Vídeo do Produto"
        :style="{ width: dialogWidth, maxWidth: dialogMaxWidth }"
        class="fz-dialog-video-externo"
    >
        <div v-if="isInstagram" class="fz-dialog-video-externo__container">
            <iframe
                ref="videoIframe"
                class="fz-dialog-video-externo__iframe fz-dialog-video-externo__iframe--instagram"
                :data-src="videoUrl"
                allowtransparency="true"
                allowfullscreen="true"
                frameborder="0"
                scrolling="no"
                style="background: white; max-width: 540px; width: calc(100% - 2px); border-radius: 3px; border: 1px solid rgb(219, 219, 219); box-shadow: none; display: block; margin: 0px auto; min-width: 326px; padding: 0px; height: 510px;"
            ></iframe>
        </div>

        <div v-else-if="isYouTube" class="fz-dialog-video-externo__container">
            <iframe
                ref="videoIframe"
                class="fz-dialog-video-externo__iframe fz-dialog-video-externo__iframe--youtube"
                :data-src="videoUrl"
                width="100%"
                height="450"
                title="YouTube video player"
                frameborder="0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowfullscreen
            ></iframe>
        </div>
    </p-dialog>
    `},FZComponents.ProdutoModalHeader={components:{"p-tag":PrimeVue.Tag,"p-button":PrimeVue.Button},mixins:[ProdutoConteudoMixin],props:{produto:{type:Object,required:!0}},computed:{categoriasNomes(){if(!this.produto.categorias||!this.configsLoja.categorias)return[];const nomes=[];for(const catId of Object.keys(this.produto.categorias)){const categoria=this.configsLoja.categorias[catId];categoria!=null&&categoria.nome&&nomes.push(categoria.nome)}return nomes},exibirSku(){return this.configsLoja.mostrarCodigoReferenciaProduto&&(this.isEmpty(this.produto.disponibilidade)||!this.configsLoja.exibirSkuVariacoes)&&this.produto.sku},temVideoExterno(){var _a,_b,_c,_d;return((_b=(_a=this.produto)==null?void 0:_a.video_externo)==null?void 0:_b.id)&&((_d=(_c=this.produto)==null?void 0:_c.video_externo)==null?void 0:_d.service)}},methods:{abrirVideoExterno(){this.abrirDialogVideoExterno(this.produto)}},template:`
    <div class="fz-produto-conteudo__cabecalho">
        <div class="row pt-1 pb-1 align-items-center">
            <div class="col-12">
                <div class="d-flex justify-content-between align-items-start">
                    <div class="flex-grow-1">
                        <h4 class="fz-produto-conteudo__titulo mb-1 font-weight-bold">
                            <span class="fz-produto-conteudo__titulo-texto">{{ produto.nome }}</span>
                        </h4>
                        <div class="fz-produto-conteudo__meta d-flex flex-wrap align-items-center gap-2 mt-2">
                            <template v-if="categoriasNomes.length > 0">
                                <p-tag
                                    v-for="(categoria, index) in categoriasNomes"
                                    :key="index"
                                    :value="categoria"
                                    severity="secondary"
                                    icon="pi pi-tag"
                                    class="fz-produto-conteudo__categoria-tag"
                                ></p-tag>
                            </template>
                            <p-tag
                                v-else-if="produto.categoria_nome"
                                :value="produto.categoria_nome"
                                severity="secondary"
                                icon="pi pi-tag"
                                class="fz-produto-conteudo__categoria-tag"
                            ></p-tag>
                            <p-tag
                                v-if="exibirSku"
                                :value="produto.sku"
                                severity="secondary"
                                icon="pi pi-hashtag"
                                class="fz-produto-conteudo__sku-tag"
                            ></p-tag>
                            <p-tag
                                v-if="configsLoja.mostrarQuantidadeVenda && produto.total_vendas > 0"
                                :value="produto.total_vendas + (produto.total_vendas == 1 ? ' venda' : ' vendas')"
                                severity="secondary"
                                icon="pi pi-shopping-cart"
                                class="fz-produto-conteudo__vendas-tag"
                            ></p-tag>
                        </div>
                    </div>

                    <div v-if="temVideoExterno" class="ml-2 flex-shrink-0">
                        <p-button
                            @click="abrirVideoExterno"
                            severity="primary"
                            icon="pi pi-video"
                            label="Ver Vídeo"
                            size="small"
                            class="fz-produto-conteudo__btn-video"
                        ></p-button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    `},FZComponents.ProdutoModalCarousel={components:{"p-image":PrimeVue.Image,"p-button":PrimeVue.Button},mixins:[ProdutoConteudoMixin],emits:["slide-change"],props:{produto:{type:Object,required:!0},alturaFixa:{type:Boolean,default:!1},miniaturasHorizontais:{type:Boolean,default:!1}},data(){return{slideAtual:0,previousSlideIndex:0,swiperInstance:null,swiperThumbsInstance:null,videojsPlayer:null,playContabilizado:!1,videoPausadoManualmente:!1,videoRemovido:!1,zoomAtivo:!1,zoomX:0,zoomY:0}},computed:{imagens(){const imgs=this.produto.imagens||[];return imgs.length>0?imgs:["https://assets.facilzap.app.br/sem_foto.png"]},temVideo(){return!this.isEmpty(this.produto.video)},videoDisponivel(){return this.temVideo&&!this.videoRemovido},temMultiplasImagens(){return this.imagens.length>1||this.temVideo},carrouselId(){return`carousel_produto_${this.produto.id}`},thumbsCarrouselId(){return`thumbs_carousel_produto_${this.produto.id}`},videoId(){return`video_produto_${this.produto.id}`},formatoImagem(){var _a;const valor=(_a=this.configsLoja)==null?void 0:_a.gridFormatoImagem;return valor==="square"||valor==="original"||valor==="rectangle"?valor:"rectangle"},deveRecortarImagem(){return this.formatoImagem==="rectangle"||this.formatoImagem==="square"},estiloImagem(){const base={width:"100%",height:"auto",aspectRatio:this.formatoImagem==="rectangle"?"4 / 5":"1 / 1",cursor:"zoom-in"};return this.deveRecortarImagem?{...base,objectFit:"cover"}:{...base,objectFit:"contain"}},classeImagem(){return`fz-produto-conteudo__galeria-imagem fz-produto-conteudo__galeria-imagem--${this.formatoImagem} img-fluid rounded`}},mounted(){this.$nextTick(()=>{this.inicializarSwiper(),this.temVideo&&this.$nextTick(()=>{this.inicializarVideo()})})},watch:{"produto.id"(newId,oldId){newId!=oldId&&(this.limparInstancias(),this.$nextTick(()=>{this.inicializarSwiper(),this.temVideo&&this.$nextTick(()=>{this.inicializarVideo()})}))},"dialogDrawerStore.isOpen"(isOpen){isOpen||setTimeout(()=>{this.limparInstancias()},300)}},beforeUnmount(){this.limparInstancias()},methods:{limparInstancias(){this.destruirVideo(),this.videoRemovido=!1,this.playContabilizado=!1,this.videoPausadoManualmente=!1,this.slideAtual=0,this.previousSlideIndex=0,this.swiperThumbsInstance&&typeof this.swiperThumbsInstance.destroy=="function"&&(this.swiperThumbsInstance.destroy(!0,!0),this.swiperThumbsInstance=null),this.swiperInstance&&typeof this.swiperInstance.destroy=="function"&&(this.swiperInstance.destroy(!0,!0),this.swiperInstance=null)},inicializarSwiper(){if(!this.temMultiplasImagens)return;const swiperEl=this.$refs.swiperContainer,swiperThumbsEl=this.$refs.swiperThumbsContainer;if(swiperEl){if(swiperThumbsEl){const configuracaoMiniaturas={spaceBetween:5,slidesPerView:"auto",freeMode:!0,touchAngle:20,watchSlidesProgress:!0,observer:!0,observeSlideChildren:!0,direction:"horizontal"};this.miniaturasHorizontais||(configuracaoMiniaturas.breakpoints={350:{direction:"horizontal"},430:{direction:"horizontal"},530:{direction:"horizontal"},768:{direction:"horizontal"},992:{direction:"vertical"},1200:{direction:"vertical"}}),this.swiperThumbsInstance=new Swiper(swiperThumbsEl,configuracaoMiniaturas)}this.swiperInstance=new Swiper(swiperEl,{slidesPerView:1,spaceBetween:0,observer:!0,observeSlideChildren:!0,autoHeight:!this.alturaFixa,touchAngle:20,scrollbar:{el:".swiper-scrollbar",hide:!1},navigation:{nextEl:".swiper-button-next",prevEl:".swiper-button-prev"},thumbs:this.swiperThumbsInstance?{swiper:this.swiperThumbsInstance}:void 0,on:{slideChange:swiper=>{this.previousSlideIndex=this.slideAtual,this.slideAtual=swiper.activeIndex,this.videojsPlayer&&this.pausarVideo(),this.swiperThumbsInstance&&this.swiperThumbsInstance.update();const activeIndex=swiper.activeIndex;if(this.videoDisponivel)if(activeIndex===1)this.$emit("slide-change",{tipo:"video",imagem:null,indiceImagem:-1});else if(activeIndex===0)this.$emit("slide-change",{tipo:"imagem",imagem:this.imagens[0]||null,indiceImagem:0});else{const indiceImagem=activeIndex-1;this.$emit("slide-change",{tipo:"imagem",imagem:this.imagens[indiceImagem]||null,indiceImagem})}else this.$emit("slide-change",{tipo:"imagem",imagem:this.imagens[activeIndex]||null,indiceImagem:activeIndex})}}})}},inicializarVideo(){const videoEl=this.$refs.videoElement;if(!videoEl||typeof videojs=="undefined")return;this.videojsPlayer=videojs(videoEl,{responsive:!0,controls:!1});const Button=videojs.getComponent("Button"),viewsButton=new Button(this.videojsPlayer,{className:"vjs-views-count"});this.videojsPlayer.addChild(viewsButton),viewsButton.el().innerHTML=`<i class="fa fa-eye"></i> ${this.produto.video.views||1}`;const pauseButton=new Button(this.videojsPlayer,{className:"vjs-bottom-pause-button",clickHandler:()=>{this.videoPausadoManualmente=!0,this.videojsPlayer.pause()}});this.videojsPlayer.addChild(pauseButton);const muteButton=new Button(this.videojsPlayer,{className:"vjs-bottom-mute-toggle-button muted",clickHandler:()=>{this.videojsPlayer.muted(!this.videojsPlayer.muted())}});this.videojsPlayer.addChild(muteButton),this.videojsPlayer.ready(()=>{$(this.videojsPlayer.bigPlayButton.el()).show(),this.videojsPlayer.trigger("loadedmetadata"),this.videojsPlayer.on("volumechange",()=>{const muteBtn=$(this.videojsPlayer.el()).find(".vjs-bottom-mute-toggle-button");this.videojsPlayer.muted()?muteBtn.addClass("muted"):muteBtn.removeClass("muted")}),this.videojsPlayer.on("timeupdate",()=>{const duration=this.videojsPlayer.duration()||100,percentage=(this.videojsPlayer.currentTime()||0)/duration*100;percentage>=30&&percentage<=40&&(this.playContabilizado||(this.playContabilizado=!0,this.contabilizarPlayVideo())),percentage>=90&&(this.playContabilizado=!1)})}),this.videojsPlayer.on("loadedmetadata",()=>{this.ajustarAlturaVideo()}),this.videojsPlayer.on("play",()=>{this.videoPausadoManualmente=!1;const swiper=this.videojsPlayer.el().closest(".swiper"),pagination=swiper==null?void 0:swiper.querySelector(".swiper-pagination");pagination&&$(pagination).removeClass("d-block").addClass("d-none"),$(this.videojsPlayer.bigPlayButton.el()).hide(),$(".vjs-bottom-pause-button",this.videojsPlayer.el()).show(),this.videojsPlayer.trigger("volumechange")}),this.videojsPlayer.on("pause",()=>{const swiper=this.videojsPlayer.el().closest(".swiper"),pagination=swiper==null?void 0:swiper.querySelector(".swiper-pagination");pagination&&$(pagination).removeClass("d-none").addClass("d-block"),$(this.videojsPlayer.bigPlayButton.el()).show(),$(".vjs-bottom-pause-button",this.videojsPlayer.el()).hide()}),this.videojsPlayer.on("error",()=>{var _a;const error=this.videojsPlayer.error();if(console.error("Video error:",error),this.swiperInstance){const videoSlide=this.videojsPlayer.el().closest(".swiper-slide");if(videoSlide){const slideIndex=Array.from(videoSlide.parentElement.children).indexOf(videoSlide);this.swiperInstance.removeSlide(slideIndex),(_a=this.swiperThumbsInstance)==null||_a.removeSlide(slideIndex),this.videoRemovido=!0}}else this.videoRemovido=!0})},pausarVideo(){this.videojsPlayer&&(this.videojsPlayer.pause(),this.videojsPlayer.currentTime(0))},ajustarAlturaVideo(tentativa=0){if(!this.videojsPlayer)return;if(tentativa>10){console.warn("Tentativas de ajustar altura do vídeo excedidas");return}const videoHeight=this.videojsPlayer.videoHeight(),videoWidth=this.videojsPlayer.videoWidth(),videoProportion=videoHeight/videoWidth,playerWidth=this.videojsPlayer.currentWidth();if(!videoHeight||!videoWidth||!playerWidth||playerWidth===0||videoHeight===0||videoWidth===0){setTimeout(()=>{this.ajustarAlturaVideo(tentativa+1)},500);return}const playerHeight=playerWidth*videoProportion,videoElement=this.videojsPlayer.el();videoElement&&($(videoElement).height(playerHeight),$(videoElement).css("height",playerHeight+"px")),this.swiperInstance&&this.$nextTick(()=>{this.swiperInstance.update()})},destruirVideo(){this.videojsPlayer&&(this.videojsPlayer.dispose(),this.videojsPlayer=null)},contabilizarPlayVideo(){try{const url=this.obterLinkCatalogo("");$.post(url,{acao:"contabilizar_play_video",produto_id:this.produto.id,loja_id:this.produto.loja||0})}catch(error){console.error("Erro ao contabilizar play:",error)}},baixarMidia(url,filename){const downloadUrl=url+"?response-content-disposition=attachment;filename="+encodeURIComponent(filename||"download");window.open(downloadUrl,"_blank")},handleMouseMove(event){if(!this.zoomAtivo)return;const rect=event.currentTarget.getBoundingClientRect();this.zoomX=(event.clientX-rect.left)/rect.width,this.zoomY=(event.clientY-rect.top)/rect.height},handleMouseEnter(){window.innerWidth<768||(this.zoomAtivo=!0)},handleMouseLeave(){this.zoomAtivo=!1,this.zoomX=0,this.zoomY=0},rolarThumbsPara(combinedIndex){if(!this.swiperThumbsInstance)return;const previousThumbIndex=this.previousSlideIndex,totalThumbs=this.imagens.length+(this.videoDisponivel?1:0),isClickingForward=combinedIndex>previousThumbIndex,isClickingBackward=combinedIndex<previousThumbIndex;this.$nextTick(()=>{if(this.swiperThumbsInstance){if(isClickingForward&&combinedIndex<totalThumbs-1)this.swiperThumbsInstance.slideTo(combinedIndex);else if(isClickingBackward&&previousThumbIndex>0){const targetScroll=Math.max(0,combinedIndex-1);this.swiperThumbsInstance.slideTo(targetScroll)}}})},onVideoThumbClick(){this.videoDisponivel&&(this.swiperInstance&&this.swiperInstance.slideTo(1),this.rolarThumbsPara(1))},onThumbClick(index){const targetIndex=this.videoDisponivel?index===0?0:index+1:index;this.swiperInstance&&this.swiperInstance.slideTo(targetIndex),this.rolarThumbsPara(targetIndex)},getZoomStyle(){if(!this.zoomAtivo)return{transform:"scale(1)",transformOrigin:"center center",transition:"transform 0.3s"};const originX=this.zoomX*100,originY=this.zoomY*100;return{transform:"scale(2)",transformOrigin:`${originX}% ${originY}%`}}},template:`
    <div class="fz-produto-conteudo__galeria">
        <div v-if="!temMultiplasImagens" class="fz-produto-conteudo__galeria-unica position-relative">
            <div
                class="fz-produto-conteudo__galeria-zoom-container"
                @mouseenter="handleMouseEnter"
                @mouseleave="handleMouseLeave"
                @mousemove="handleMouseMove"
                style="overflow: hidden; border-radius: 0.25rem;"
            >
                <p-image
                    :src="obterURLArquivos(imagens[0])"
                    :alt="produto.nome"
                    :image-class="classeImagem"
                    preview
                    @error="handleImageError"
                    :image-style="[
                        estiloImagem,
                        getZoomStyle()
                    ]"
                >
                    <template #previewicon>
                        <span></span>
                    </template>
                </p-image>
            </div>
            <p-button
                v-if="configsLoja.permitirBaixarMidiaCatalogo"
                class="fz-produto-conteudo__btn-download"
                icon="pi pi-download"
                severity="contrast"
                rounded
                @click="baixarMidia(obterURLArquivos(imagens[0]), produto.nome + '.jpg')"
                aria-label="Baixar Imagem"
            ></p-button>
        </div>

        <div v-else class="fz-produto-conteudo__galeria-multipla pos-relative">
            <div class="fz-produto-conteudo__galeria-com-thumbs">
                <div ref="swiperThumbsContainer" class="fz-produto-conteudo__galeria-miniaturas swiper swiper-thumbs" :id="thumbsCarrouselId">
                    <div class="swiper-wrapper">
                        <template v-if="temVideo">
                            <div
                                :key="'thumb-0'"
                                class="fz-produto-conteudo__galeria-miniatura swiper-slide"
                                @click="onThumbClick(0)"
                            >
                                <img
                                    :src="obterURLArquivos(imagens[0])"
                                    :alt="'Thumb 1'"
                                    class="fz-produto-conteudo__galeria-miniatura-imagem img-fluid"
                                    @error="handleImageError"
                                    style="width: 100%; height: auto; object-fit: cover; cursor: pointer;"
                                />
                            </div>

                            <div :key="'thumb-video'" class="fz-produto-conteudo__galeria-miniatura fz-produto-conteudo__galeria-miniatura--video swiper-slide" @click="onVideoThumbClick">
                                <div
                                    class="rounded bg-white d-flex justify-content-center align-items-center border w-100 h-100"
                                    :style="{
                                        cursor: 'pointer',
                                        backgroundImage: produto.video.thumb ? 'url(' + obterURLArquivos(produto.video.thumb) + ')' : 'none',
                                        backgroundSize: 'cover',
                                        backgroundPosition: 'center'
                                    }"
                                >
                                    <i class="fa fa-play-circle m-0 f-36 align-middle text-success"></i>
                                </div>
                            </div>

                            <div
                                v-for="(imagem, idx) in imagens.slice(1)"
                                :key="'thumb-' + (idx + 1)"
                                class="fz-produto-conteudo__galeria-miniatura swiper-slide"
                                @click="onThumbClick(idx + 1)"
                            >
                                <img
                                    :src="obterURLArquivos(imagem)"
                                    :alt="'Thumb ' + (idx + 2)"
                                    class="fz-produto-conteudo__galeria-miniatura-imagem img-fluid"
                                    @error="handleImageError"
                                    style="width: 100%; height: auto; object-fit: cover; cursor: pointer;"
                                />
                            </div>
                        </template>

                        <template v-else>
                            <div
                                v-for="(imagem, index) in imagens"
                                :key="'thumb-' + index"
                                class="fz-produto-conteudo__galeria-miniatura swiper-slide"
                                @click="onThumbClick(index)"
                            >
                                <img
                                    :src="obterURLArquivos(imagem)"
                                    :alt="'Thumb ' + (index + 1)"
                                    class="fz-produto-conteudo__galeria-miniatura-imagem img-fluid"
                                    @error="handleImageError"
                                    style="width: 100%; height: auto; object-fit: cover; cursor: pointer;"
                                />
                            </div>
                        </template>
                    </div>
                </div>

                <div ref="swiperContainer" class="fz-produto-conteudo__galeria-principal swiper carrousel_produtos" :id="carrouselId" :data-produto-id="produto.id">
                    <div class="swiper-wrapper">
                    <template v-if="temVideo">
                        <div
                            :key="'img-0'"
                            class="fz-produto-conteudo__galeria-slide swiper-slide position-relative"
                        >
                            <div
                                class="fz-produto-conteudo__galeria-zoom-container"
                                @mouseenter="handleMouseEnter"
                                @mouseleave="handleMouseLeave"
                                @mousemove="handleMouseMove"
                                style="overflow: hidden; border-radius: 0.25rem;"
                            >
                                <p-image
                                    :src="obterURLArquivos(imagens[0])"
                                    :alt="produto.nome + ' - Imagem 1'"
                                    :image-class="classeImagem"
                                    preview
                                    @error="handleImageError"
                                    :image-style="[
                                        estiloImagem,
                                        getZoomStyle()
                                    ]"
                                >
                                    <template #previewicon>
                                        <span></span>
                                    </template>
                                </p-image>
                            </div>

                            <p-button
                                v-if="configsLoja.permitirBaixarMidiaCatalogo"
                                class="fz-produto-conteudo__btn-download"
                                icon="pi pi-download"
                                severity="contrast"
                                rounded
                                @click="baixarMidia(obterURLArquivos(imagens[0]), produto.nome + '.jpg')"
                                aria-label="Baixar Imagem"
                            ></p-button>
                        </div>

                        <div :key="'slide-video'" class="fz-produto-conteudo__galeria-slide fz-produto-conteudo__galeria-slide--video swiper-slide position-relative">
                            <video
                                ref="videoElement"
                                :id="videoId"
                                class="fz-produto-conteudo__galeria-video video-js w-100 vjs-show-big-play-button-on-pause"
                                :data-loja-id="produto.loja|| 0"
                                :data-views="produto.video.views || 1"
                                data-setup="{}"
                                controls
                                preload="metadata"
                                loop
                                playsinline
                                :poster="produto.video.thumb ? obterURLArquivos(produto.video.thumb) : ''"
                            >
                                <source :src="obterURLArquivos(produto.video.url)" type="video/mp4">
                            </video>

                            <p-button
                                v-if="configsLoja.permitirBaixarMidiaCatalogo"
                                class="fz-produto-conteudo__btn-download"
                                icon="pi pi-download"
                                severity="contrast"
                                rounded
                                @click="baixarMidia(obterURLArquivos(produto.video.url), produto.nome + '.mp4')"
                                aria-label="Baixar Vídeo"
                            ></p-button>
                        </div>

                        <div
                            v-for="(imagem, idx) in imagens.slice(1)"
                            :key="'img-' + (idx + 1)"
                            class="fz-produto-conteudo__galeria-slide swiper-slide position-relative"
                        >
                            <div
                                class="fz-produto-conteudo__galeria-zoom-container"
                                @mouseenter="handleMouseEnter"
                                @mouseleave="handleMouseLeave"
                                @mousemove="handleMouseMove"
                                style="overflow: hidden; border-radius: 0.25rem;"
                            >
                                <p-image
                                    :src="obterURLArquivos(imagem)"
                                    :alt="produto.nome + ' - Imagem ' + (idx + 2)"
                                    :image-class="classeImagem"
                                    preview
                                    @error="handleImageError"
                                    :image-style="[
                                        estiloImagem,
                                        getZoomStyle()
                                    ]"
                                >
                                    <template #previewicon>
                                        <span></span>
                                    </template>
                                </p-image>
                            </div>

                            <p-button
                                v-if="configsLoja.permitirBaixarMidiaCatalogo"
                                class="fz-produto-conteudo__btn-download"
                                icon="pi pi-download"
                                severity="contrast"
                                rounded
                                @click="baixarMidia(obterURLArquivos(imagem), produto.nome + '.jpg')"
                                aria-label="Baixar Imagem"
                            ></p-button>
                        </div>
                    </template>

                    <template v-else>
                        <div
                            v-for="(imagem, index) in imagens"
                            :key="'img-' + index"
                            class="fz-produto-conteudo__galeria-slide swiper-slide position-relative"
                        >
                            <div
                                class="fz-produto-conteudo__galeria-zoom-container"
                                @mouseenter="handleMouseEnter"
                                @mouseleave="handleMouseLeave"
                                @mousemove="handleMouseMove"
                                style="overflow: hidden; border-radius: 0.25rem;"
                            >
                                <p-image
                                    :src="obterURLArquivos(imagem)"
                                    :alt="produto.nome + ' - Imagem ' + (index + 1)"
                                    :image-class="classeImagem"
                                    preview
                                    @error="handleImageError"
                                    :image-style="[
                                        estiloImagem,
                                        getZoomStyle()
                                    ]"
                                >
                                    <template #previewicon>
                                        <span></span>
                                    </template>
                                </p-image>
                            </div>

                            <p-button
                                v-if="configsLoja.permitirBaixarMidiaCatalogo"
                                class="fz-produto-conteudo__btn-download"
                                icon="pi pi-download"
                                severity="contrast"
                                rounded
                                @click="baixarMidia(obterURLArquivos(imagem), produto.nome + '.jpg')"
                                aria-label="Baixar Imagem"
                            ></p-button>
                        </div>
                    </template>
                </div>
                    <div class="fz-produto-conteudo__galeria-scrollbar swiper-scrollbar"></div>
                    <div class="fz-produto-conteudo__galeria-nav-proximo fz-seta-slider swiper-button-next d-none d-lg-flex"></div>
                    <div class="fz-produto-conteudo__galeria-nav-anterior fz-seta-slider swiper-button-prev d-none d-lg-flex"></div>
                </div>
            </div>
        </div>
    </div>
    `},FZComponents.ProdutoKitComponentes={components:{"p-image":PrimeVue.Image,"p-message":PrimeVue.Message,"p-select":PrimeVue.Select},mixins:[ProdutoConteudoMixin],props:{produto:{type:Object,required:!0}},computed:{isKit(){return KitProdutoHelper.isKit(this.produto)},componentes(){return KitProdutoHelper.componentes(this.produto)},selecoes(){return KitProdutoHelper.selecoes(this.conteudoStore,this.produto)},kitCompleto(){return KitProdutoHelper.completo(this.produto,this.selecoes)},kitPrecoReal(){return KitProdutoHelper.preco(this.produto,this.selecoes)},kitEstoqueReal(){return KitProdutoHelper.estoque(this.produto,this.selecoes)},textoEstoqueKit(){return this.produto.kit_estoque_ilimitado?"Disponível":`${this.kitEstoqueReal} disponíveis`},selecaoBloqueada(){var _a;return Number(((_a=this.conteudoStore.quantidadesSelecionadas[this.produto.id])==null?void 0:_a[0])||0)>0}},watch:{produto:{handler(){this.inicializarSelecoes(),this.atualizarPrecoProduto()},immediate:!0},kitPrecoReal(){this.atualizarPrecoProduto()}},methods:{inicializarSelecoes(){var _a;!this.isKit||!((_a=this.produto)!=null&&_a.id)||(this.hidratarKitSelecoesStore(),this.conteudoStore.kitSelecoes[this.produto.id]||(this.conteudoStore.kitSelecoes[this.produto.id]={}))},selecionarComponente(indice,valor){this.inicializarSelecoes(),this.conteudoStore.kitSelecoes[this.produto.id][indice]=valor,this.atualizarPrecoProduto()},precoComponente(comp){let precoUnitario=Number(comp.preco_unitario||0);if(Array.isArray(comp.variacoes_opcoes)&&this.selecoes[comp.indice]!==void 0){const opcao=comp.variacoes_opcoes.find(op=>String(op.vid)===String(this.selecoes[comp.indice]));opcao&&(precoUnitario=Number(opcao.preco||precoUnitario))}return precoUnitario*Math.max(1,parseInt(comp.quantidade)||1)},atualizarPrecoProduto(){if(!this.isKit||!this.produto)return;const preco=Number(this.kitPrecoReal||this.produto.preco||0);this.produto.preco=preco,this.produto.precos_produto||(this.produto.precos_produto={}),this.produto.precos_produto.padrao=preco,this.produto.precos_produto.promocional=null,this.produto.precos_produto.preco_a_partir=null},imagemComponente(comp){return comp.imagem?this.obterURLArquivos(comp.imagem):"https://assets.facilzap.app.br/sem_foto.png"},nomeOpcao(opcao){return`${opcao.nome} - ${opcao.disponivel?"R$ "+this.formatarPreco(opcao.preco):"Indisponível"}`}},template:`
    <section v-if="isKit" class="fz-produto-kit my-3" aria-label="Componentes do kit">
        <div class="fz-produto-kit__cabecalho d-flex justify-content-between align-items-center mb-3">
            <h5 class="fz-produto-kit__titulo mb-0">Este kit contém</h5>
            <span class="fz-produto-kit__estoque badge badge-light" v-if="kitCompleto || kitEstoqueReal > 0">
                {{ textoEstoqueKit }}
            </span>
        </div>

        <p-message v-if="selecaoBloqueada" severity="info" icon="pi pi-info-circle" size="small" :closable="false" class="fz-produto-kit__pendente mb-3" aria-live="polite">
            Para trocar a variação, remova o kit do carrinho e adicione novamente.
        </p-message>

        <div class="fz-produto-kit__lista">
            <div v-for="comp in componentes" :key="comp.indice" class="fz-produto-kit__item">
                <p-image
                    :src="imagemComponente(comp)"
                    :alt="comp.nome"
                    image-class="fz-produto-kit__imagem"
                    preview
                    @error="handleImageError"
                ></p-image>

                <div class="fz-produto-kit__info">
                    <strong class="fz-produto-kit__nome">{{ comp.quantidade }}x {{ comp.nome }}</strong>

                    <span v-if="comp.variacao_id" class="fz-produto-kit__meta">
                        Variação: {{ comp.variacao_nome || comp.variacao_id }}
                    </span>
                    <span v-else-if="!comp.variacoes_opcoes || comp.variacoes_opcoes.length === 0" class="fz-produto-kit__meta">
                        Produto inteiro
                    </span>

                    <label v-if="comp.variacoes_opcoes && comp.variacoes_opcoes.length > 0" class="fz-produto-kit__label" :for="'kit-comp-' + produto.id + '-' + comp.indice">
                        Escolha uma variação
                    </label>
                    <p-select
                        v-if="comp.variacoes_opcoes && comp.variacoes_opcoes.length > 0"
                        class="fz-produto-kit__select"
                        :input-id="'kit-comp-' + produto.id + '-' + comp.indice"
                        :model-value="selecoes[comp.indice] || null"
                        :options="comp.variacoes_opcoes"
                        :option-label="nomeOpcao"
                        option-value="vid"
                        :option-disabled="opcao => !opcao.disponivel"
                        placeholder="Selecione"
                        aria-required="true"
                        :disabled="selecaoBloqueada"
                        fluid
                        @update:model-value="selecionarComponente(comp.indice, $event)"
                    >
                    </p-select>
                </div>

                <div class="fz-produto-kit__preco">R$ {{ formatarPreco(precoComponente(comp)) }}</div>
            </div>
        </div>

        <p-message v-if="!kitCompleto" severity="warn" icon="pi pi-exclamation-circle" size="small" :closable="false" class="fz-produto-kit__pendente mt-3 mb-0" aria-live="polite">
            Selecione todas as variações do kit para continuar.
        </p-message>
    </section>
    `},FZComponents.ProdutoModalFooter={components:{"p-button":PrimeVue.Button,"fz-produto-acoes":FZComponents.ProdutoAcoes},mixins:[ProdutoConteudoMixin],props:{produto:{type:Object,required:!0},contexto:{type:String,required:!1}},computed:{isKit(){return KitProdutoHelper.isKit(this.produto)},kitSelecoesProduto(){return KitProdutoHelper.selecoes(this.conteudoStore,this.produto)},kitCompleto(){return KitProdutoHelper.completo(this.produto,this.kitSelecoesProduto)},kitEstoqueReal(){return KitProdutoHelper.estoque(this.produto,this.kitSelecoesProduto)},qtdMinMax(){var _a,_b,_c,_d;if(this.isKit)return{min:0,max:this.kitEstoqueReal};const catalogoId=this.configsLoja.catalogoId;return{min:parseInt((_b=(_a=this.produto.qtds_minimas)==null?void 0:_a[catalogoId])==null?void 0:_b[0])||0,max:parseInt((_d=(_c=this.produto.qtds_maximas)==null?void 0:_c[catalogoId])==null?void 0:_d[0])||0}},produtoIndisponivelEstoque(){var _a;if(this.isKit)return this.produto.kit_quebrado||this.kitEstoqueReal<=0;if(this.produto.controlar_estoque!="1")return!1;const estoque=parseInt((_a=this.produto.estoque)==null?void 0:_a[0])||parseInt(this.produto.total_estoque)||0,gradeQuebradaBloqueia=!!this.produto.grade_quebrada&&!this.produto.grade_permitir_individual;return estoque<=0||gradeQuebradaBloqueia},exibirBotaoAdicionar(){return!this.produto.venda_externa&&!this.configsLoja.precosRestritos&&!this.produtoIndisponivelEstoque},linkWhatsApp(){if(!this.configsLoja.linkWhatsApp)return null;const mensagem=encodeURIComponent(`Gostaria de mais informações sobre o produto: ${this.produto.nome}`);return`${this.configsLoja.linkWhatsApp}${mensagem}`},carregandoCarrinho(){return CarrinhoStore.aguardandoAtualizacao}},methods:{validarQuantidadesSelecionadas(fecharModal=!1,abrirCarrinho=!1){if(this.isKit&&!this.kitCompleto)return showNotification("Selecione todas as variações do kit para continuar.","","warning"),!1;const produtoId=this.produto.id,min=Number(this.qtdMinMax.min),max=Number(this.qtdMinMax.max),quantidades={...this.conteudoStore.quantidadesSelecionadas[produtoId]||{}};let totalQtd=0;const qtdGrades=Number(quantidades.grade)||0;if(qtdGrades>0&&this.produto.grade&&!this.isEmpty(this.produto.grade)){const pecasPorGrade=Number(this.produto.qtd_grade)||0;pecasPorGrade>0&&(totalQtd+=qtdGrades*pecasPorGrade,delete quantidades.grade)}return Object.values(quantidades).forEach(qtd=>{totalQtd+=Number(qtd)||0}),totalQtd===0&&!fecharModal?(showNotification("Selecione a quantidade para adicionar ao carrinho!","","error"),!1):totalQtd<min&&totalQtd>0?(fecharModal?this.removerProdutoValidacaoQuantidade(produtoId,min):showNotification(`A quantidade mínima para este produto são ${min} unidades.`,"","error"),!1):totalQtd>max&&max>0?(showNotification(`A quantidade máxima para este produto são ${max} unidades.`,"","error"),!1):(this.pausarVideo(),this.dialogDrawerStore.isOpen=!1,abrirCarrinho&&typeof verCarrinho=="function"&&verCarrinho(),!0)},async removerProdutoValidacaoQuantidade(min){showConfirmation(`A quantidade mínima para este produto são ${min} unidades.`,"Deseja removê-lo do carrinho?",async()=>{typeof facilZapEventos!="undefined"&&facilZapEventos.removerDoCarrinho&&facilZapEventos.removerDoCarrinho(this.produto.id,this.produto.nome,this.produto.preco),showLoading("","Removendo produto do carrinho...","");try{const formData=new FormData;formData.append("acao","remover_produto"),formData.append("pid",this.produto.id);const trimmedData=(await(await fetch(this.configsLoja.urlCatalogo,{method:"POST",body:formData})).text()).trim();closeLoading(),trimmedData!=="ok"?showNotification("Erro","Tivemos um problema ao remover o produto do seu carrinho.<br/>Atualize a página e tente novamente!","error"):(this.dialogDrawerStore.isOpen=!1,typeof totalCarrinho=="function"&&totalCarrinho())}catch(error){console.error("Erro ao remover produto:",error),closeLoading(),showNotification("Erro","Tivemos um problema ao remover o produto do seu carrinho.<br/>Atualize a página e tente novamente!","error")}})},pausarVideo(){var _a,_b;const carousel=(_b=(_a=this.$parent)==null?void 0:_a.$refs)==null?void 0:_b.carousel;carousel&&typeof carousel.pausarVideo=="function"&&carousel.pausarVideo()},adicionarAoCarrinho(){if(this.validarQuantidadesSelecionadas(!1,!1)){if(CarrinhoManager.autenticacaoObrigatoria(this.configsLoja))return abrirModalLoginVisitante("atualizar_store_vue");verCarrinho()}}},template:`
    <div class="fz-produto-conteudo__rodape py-4">
        <div v-if="exibirBotaoAdicionar" class="fz-produto-conteudo__acoes fz-produto-conteudo__acoes-primarias d-flex justify-content-center gap-2 mb-3">
            <p-button
                @click="adicionarAoCarrinho"
                severity="primary"
                icon="pi pi-shopping-cart"
                class="fz-produto-conteudo__btn-adicionar-carrinho"
                label="Adicionar ao Carrinho"
                :loading="carregandoCarrinho"
                :disabled="isKit && !kitCompleto"
            ></p-button>
        </div>

        <div v-else-if="produto.venda_externa" class="fz-produto-conteudo__acoes d-flex justify-content-center gap-2 mb-3">
            <p-button
                :href="produto.link_externo"
                as="a"
                target="_blank"
                severity="primary"
                class="fz-produto-conteudo__btn-externo"
                icon="pi pi-external-link"
                :label="produto.texto_botao_acao || 'Comprar'"
            ></p-button>
        </div>

        <div v-else-if="configsLoja.precosRestritos" class="fz-produto-conteudo__acoes d-flex justify-content-center gap-2 mb-3">
            <p-button
                :href="obterLinkCatalogo('login')"
                as="a"
                severity="primary"
                class="fz-produto-conteudo__btn-login"
                icon="pi pi-lock"
                label="Ver Preços"
            ></p-button>
        </div>

        <div class="fz-produto-conteudo__acoes-sociais d-flex justify-content-center gap-3 mt-2">
            <fz-produto-acoes
                :produto="produto"
                :habilitar-curtidas="configsLoja.habilitarCurtidas"
                :habilitar-perguntas="configsLoja.habilitarPerguntas"
                :permitir-compartilhar-produto="configsLoja.permitirCompartilharProduto"
                :habilitar-whats-app="!!linkWhatsApp"
                :link-whats-app="linkWhatsApp"
                :link-produto="linkProduto"
                size="large"
            ></fz-produto-acoes>
        </div>
    </div>
    `},FZComponents.ProdutoModalAudioDescricao={components:{},mixins:[ProdutoConteudoMixin],props:{audioPath:{type:String,required:!0},produtoId:{type:[String,Number],required:!0},vendedorNome:{type:String,default:""},vendedorFoto:{type:String,default:""},totalPlays:{type:Number,default:0}},data(){return{audio:null,tocando:!1,duracao:"0:00",tempoAtual:"0:00",progresso:0,playContabilizado:!1,interval:null,audioWaveUrl:"https://assets.facilzap.app.br/audio_wave2.png"}},computed:{audioUrl(){return this.obterURLArquivos(this.audioPath)},vendedorInicial(){return this.vendedorNome?this.vendedorNome[0]:""},vendedorImagem(){return this.vendedorFoto?this.obterURLArquivos(this.vendedorFoto):""},horaAtual(){const now=new Date;return now.getHours().toString().padStart(2,"0")+":"+now.getMinutes().toString().padStart(2,"0")},totalPlaysExibicao(){return this.playContabilizado?this.totalPlays+1:this.totalPlays}},mounted(){this.initAudio()},beforeUnmount(){this.destroyAudio()},methods:{initAudio(){this.audio=new Audio(this.audioUrl),this.audio.volume=1,this.audio.addEventListener("durationchange",()=>{this.duracao=this.formatarTempo(this.audio.duration)}),this.audio.addEventListener("ended",()=>{this.pararAudio()}),this.audio.addEventListener("error",e=>{console.error("Erro ao carregar áudio:",e)})},destroyAudio(){this.interval&&clearInterval(this.interval),this.audio&&(this.audio.pause(),this.audio=null)},formatarTempo(segundos){if(!segundos||isNaN(segundos))return"0:00";const hrs=~~(segundos/3600),mins=~~(segundos%3600/60),secs=~~(segundos%60);let ret="";return hrs>0&&(ret+=hrs+":"+(mins<10?"0":"")),ret+=mins+":"+(secs<10?"0":""),ret+=secs,ret},toggleAudio(){this.tocando?this.pararAudio():this.tocarAudio()},tocarAudio(){this.audio&&(this.tocando=!0,this.audio.play(),this.interval=setInterval(()=>{this.atualizarProgresso()},100),this.playContabilizado||this.contabilizarPlay())},pararAudio(){this.audio&&(this.tocando=!1,this.audio.pause(),this.audio.currentTime=0,this.interval&&clearInterval(this.interval),this.progresso=0,this.tempoAtual="0:00",this.duracao=this.formatarTempo(this.audio.duration))},atualizarProgresso(){this.audio&&(this.tempoAtual=this.formatarTempo(this.audio.currentTime),this.progresso=this.audio.currentTime/this.audio.duration*100)},async contabilizarPlay(){this.playContabilizado=!0;try{const url=this.configsLoja.baseUrl+"/api/catalogo/contabilizar_play_audio";await fetch(url,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({tipo:"produto",produto:this.produtoId})})}catch(error){console.error("Erro ao contabilizar play:",error)}}},template:`
    <div class="fz-produto-conteudo__audio-descricao mb-1">
        <div class="fz-produto-conteudo__audio-container">
            <div class="fz-produto-conteudo__audio-box">
                <div class="fz-produto-conteudo__audio-conteudo">
                    <!-- Botão Play/Pause -->
                    <div class="fz-produto-conteudo__audio-btn-play">
                        <button
                            type="button"
                            @click="toggleAudio"
                            class="fz-produto-conteudo__audio-btn"
                            :aria-label="tocando ? 'Pausar áudio' : 'Reproduzir áudio'"
                        >
                            <i class="fa fa-fw" :class="tocando ? 'fa-pause' : 'fa-play'"></i>
                        </button>
                    </div>

                    <!-- Waveform e controles -->
                    <div class="fz-produto-conteudo__audio-wave-container">
                        <div
                            class="fz-produto-conteudo__audio-wave"
                            :style="{
                                backgroundImage: 'url(' + audioWaveUrl + '), linear-gradient(90deg, rgb(0, 0, 0) ' + progresso + '%, rgb(125, 125, 125) ' + progresso + '%)'
                            }"
                        ></div>

                        <div class="fz-produto-conteudo__audio-info">
                            <span class="fz-produto-conteudo__audio-duracao">{{ tocando ? tempoAtual : duracao }}</span>
                            <span class="fz-produto-conteudo__audio-plays">
                                <svg version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 485 485" class="fz-produto-conteudo__audio-icon-mic">
                                    <g>
                                        <path d="M242.5,0C160.048,0,92.969,67.079,92.969,149.531h30C122.969,83.621,176.59,30,242.5,30s119.531,53.621,119.531,119.531
                                            c0,14.859-2.692,29.357-8.002,43.09l-82.446,213.207C260.208,435.239,231.383,455,199.854,455h-51.885v30h51.885
                                            c21.999,0,43.13-6.637,61.111-19.191c17.554-12.258,30.901-29.257,38.599-49.16l82.446-213.207
                                            c6.65-17.197,10.022-35.336,10.022-53.91C392.031,67.079,324.952,0,242.5,0z"/>
                                        <path d="M167.969,316.563h-20v30h20c35.583,0,64.531-28.948,64.531-64.531c0-30.42-21.158-55.992-49.531-62.771v-69.729
                                            C182.969,116.706,209.674,90,242.5,90s59.531,26.706,59.531,59.531h30C332.031,100.163,291.868,60,242.5,60
                                            s-89.531,40.163-89.531,89.531V247.5h15c19.041,0,34.531,15.49,34.531,34.531S187.009,316.563,167.969,316.563z"/>
                                    </g>
                                </svg>
                                {{ totalPlaysExibicao }}
                            </span>
                            <span class="fz-produto-conteudo__audio-hora">{{ horaAtual }}</span>
                        </div>
                    </div>

                    <!-- Foto do vendedor -->
                    <div class="fz-produto-conteudo__audio-vendedor">
                        <div
                            class="fz-produto-conteudo__audio-vendedor-foto"
                            :style="vendedorImagem ? { backgroundImage: 'url(' + vendedorImagem + ')' } : {}"
                        >
                            <span v-if="!vendedorImagem" class="fz-produto-conteudo__audio-vendedor-inicial">
                                {{ vendedorInicial }}
                            </span>
                        </div>
                        <i class="fa fa-microphone fz-produto-conteudo__audio-vendedor-icone"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    `},FZComponents.ProdutoModalDescricao={components:{"p-divider":PrimeVue.Divider,"p-button":PrimeVue.Button},mixins:[ProdutoConteudoMixin],props:{descricao:{type:String,required:!0},produtoId:{type:[String,Number],required:!0},exibirTitulo:{type:Boolean,default:!0}},data(){return{expandido:!1,alturaMaxima:150,mostrarBotao:!1}},mounted(){this.$nextTick(()=>{this.verificarAltura()})},methods:{verificarAltura(){if(this.$refs.conteudoDescricao){const altura=this.$refs.conteudoDescricao.scrollHeight;this.mostrarBotao=altura>this.alturaMaxima}}},template:`
    <div class="fz-produto-conteudo__descricao mt-4">
        <p-divider v-if="exibirTitulo" align="left" type="solid" class="fz-produto-conteudo__divisoria">
            <i class="pi pi-align-left"></i> <b>Descrição do Produto</b>
        </p-divider>

        <div class="fz-produto-conteudo__descricao-wrapper">
            <div
                ref="conteudoDescricao"
                class="fz-produto-conteudo__descricao-conteudo"
                :class="{
                    'fz-produto-conteudo__descricao-conteudo--expandido': expandido,
                    'fz-produto-conteudo__descricao-conteudo--truncado': mostrarBotao && !expandido
                }"
                :style="!expandido && mostrarBotao ? { maxHeight: alturaMaxima + 'px', overflow: 'hidden' } : {}"
                v-html="descricao"
            ></div>

            <div v-if="mostrarBotao" class="fz-produto-conteudo__descricao-toggle mt-3 text-center">
                <p-button
                    :label="expandido ? 'Ler Menos' : 'Ler Mais'"
                    :icon="expandido ? 'pi pi-chevron-up' : 'pi pi-chevron-down'"
                    text
                    severity="primary"
                    @click="expandido = !expandido"
                    class="fz-produto-conteudo__btn-ler-mais"
                ></p-button>
            </div>
        </div>
    </div>`},FZComponents.ProdutoModalGuiaMedidas={components:{"p-divider":PrimeVue.Divider},mixins:[ProdutoConteudoMixin],props:{produto:{type:Object,required:!0},exibirTitulo:{type:Boolean,default:!0}},computed:{guiaMedidas(){return this.obterDescricaoGuiaMedidas(this.produto)}},template:`
    <div class="fz-produto-conteudo__guia-medidas mt-4">
        <p-divider v-if="exibirTitulo" align="left" type="solid" class="fz-produto-conteudo__divisoria">
            <i class="ti-ruler-alt"></i> <b>Guia de Medidas</b>
        </p-divider>

        <div class="fz-produto-conteudo__guia-medidas-conteudo" v-html="guiaMedidas"></div>
    </div>`},FZComponents.ProdutoModalWidgets={components:{"p-divider":PrimeVue.Divider},mixins:[ProdutoConteudoMixin],props:{produto:{type:Object,required:!0},exibirTitulo:{type:Boolean,default:!0}},computed:{widgets(){return this.obterWidgetsProduto(this.produto)}},mounted(){window.addEventListener("message",this.receberAlturaWidget)},beforeUnmount(){window.removeEventListener("message",this.receberAlturaWidget)},methods:{receberAlturaWidget(event){var _a;if(((_a=event.data)==null?void 0:_a.tipo)!=="facilzap-widget-altura")return;const iframe=(Array.isArray(this.$refs.iframes)?this.$refs.iframes:[this.$refs.iframes]).find(item=>(item==null?void 0:item.contentWindow)===event.source),altura=Number(event.data.altura);if(!iframe||!Number.isFinite(altura))return;const alturaAlvo=Math.min(Math.max(altura,120),2500),alturaAtual=parseFloat(iframe.style.height)||0;Math.abs(alturaAlvo-alturaAtual)<2||(window.requestAnimationFrame?window.requestAnimationFrame(()=>{iframe.style.height=`${alturaAlvo}px`}):iframe.style.height=`${alturaAlvo}px`)}},template:`
    <div class="fz-produto-conteudo__widgets mt-4">
        <p-divider v-if="exibirTitulo" align="left" type="solid" class="fz-produto-conteudo__divisoria">
            <i class="pi pi-box"></i> <b>Informações adicionais</b>
        </p-divider>

        <article v-for="widget in widgets" :key="widget.id" class="fz-produto-conteudo__widget">
            <iframe
                ref="iframes"
                :title="widget.nome || 'Widget do produto'"
                sandbox="allow-forms allow-popups allow-popups-to-escape-sandbox allow-scripts"
                referrerpolicy="no-referrer"
                loading="lazy"
                :srcdoc="montarDocumentoWidget(widget)"
            ></iframe>
        </article>
    </div>`},FZComponents.ProdutoModalSimuladorFrete={components:{"p-divider":PrimeVue.Divider,"fz-simulador-frete-formulario":FZComponents.SimuladorFreteFormulario},mixins:[ProdutoConteudoMixin],props:{produto:{type:Object,required:!0},exibirTitulo:{type:Boolean,default:!0}},computed:{quantidadeTotal(){const catalogoId=this.configsLoja.catalogoId,quantidades=this.conteudoStore.quantidadesSelecionadas[this.produto.id]||{};let total=0;return Object.values(quantidades).forEach(qtd=>{total+=parseInt(qtd)||0}),total},quantidadesSelecionadas(){const quantidades={...this.conteudoStore.quantidadesSelecionadas[this.produto.id]||{}},grade=this.produto.grade;if(grade&&typeof grade=="object"&&!Array.isArray(grade)&&Object.keys(grade).length>0){const quantidadeGrade=Math.max(1,Number(quantidades.grade)||0);quantidades.grade=quantidadeGrade,Object.entries(grade).forEach(([variacaoId,quantidade])=>{quantidades[variacaoId]=(Number(quantidade)||0)*quantidadeGrade})}return quantidades},precoTotal(){return(parseFloat(this.produto.preco_venda)||0)*this.quantidadeTotal}},methods:{async handleSimular({cep,pais}){if(typeof CarrinhoManager!="undefined"&&typeof CarrinhoManager.flush=="function")try{await CarrinhoManager.flush(this.configsLoja)}catch(e){console.error("Erro ao sincronizar carrinho antes de calcular frete:",e)}this.abrirDialogSimuladorFrete(cep,pais,this.produto.id,this.quantidadeTotal,this.precoTotal)}},template:`
    <div class="fz-produto-conteudo__frete mt-4 mb-3">
        <p-divider v-if="exibirTitulo" align="left" type="solid" class="fz-produto-conteudo__divisoria">
            <i class="pi pi-truck"></i> <b>Simular Frete</b>
        </p-divider>

        <slot v-else name="cabecalho"></slot>

        <fz-simulador-frete-formulario
            :produto-id="produto.id"
            :quantidades="quantidadesSelecionadas"
            :compact="true"
            @simular="handleSimular"
        ></fz-simulador-frete-formulario>
    </div>`},FZComponents.ProdutoCupons={components:{"p-button":PrimeVue.Button,"p-dialog":PrimeVue.Dialog},mixins:[ProdutoConteudoMixin],props:{cupons:{type:Array,default:()=>[]},produto:{type:Object,default:null}},data(){return{codigoCopiado:null,timeoutCopiado:null,cuponsExpandidos:!1,cupomSelecionado:null,dialogRegrasVisivel:!1}},computed:{cuponsExibiveis(){return Array.isArray(this.cupons)?this.cupons.filter(cupom=>(cupom==null?void 0:cupom.codigo)&&this.cupomCompativelComProduto(cupom)):[]},cuponsVisiveis(){return this.cuponsExpandidos?this.cuponsExibiveis:this.cuponsExibiveis.slice(0,1)},exibirToggleCupons(){return this.cuponsExibiveis.length>1}},beforeUnmount(){this.timeoutCopiado&&clearTimeout(this.timeoutCopiado)},methods:{obterIdsCategorias(valor){return valor==null||valor===""?[]:Array.isArray(valor)?valor.flatMap(item=>this.obterIdsCategorias(item)):typeof valor=="object"?Object.entries(valor).flatMap(([id,subcategorias])=>[String(id),...this.obterIdsCategorias(subcategorias)]):String(valor).split(",").map(id=>id.trim()).filter(Boolean)},cupomCompativelComProduto(cupom){const categoriasCupom=this.obterIdsCategorias(cupom.categorias);if(categoriasCupom.length===0||!this.produto)return!0;const categoriasProduto=new Set(this.obterIdsCategorias(this.produto.categorias));return categoriasCupom.some(categoria=>categoriasProduto.has(categoria))},cupomTemCatalogoRestrito(cupom){return this.obterIdsCategorias(cupom.catalogos).length>0},regrasCupom(cupom){const regras=[];if(!cupom)return regras;const valorMinimo=Number(cupom.valor_minimo_pedido||0),limiteUsoTotal=parseInt(cupom.limite_uso_total,10)||0,limiteUsoIndividual=parseInt(cupom.limite_uso_individual,10)||0,quantidadePedidos=parseInt(cupom.valor_quantidade_pedidos,10)||0;valorMinimo>0&&regras.push(`Pedido mínimo de R$ ${this.formatarPreco(valorMinimo)}`),cupom.tipo_quantidade_pedidos==="nenhum"?regras.push("Válido para a primeira compra"):cupom.tipo_quantidade_pedidos==="minimo"&&quantidadePedidos>0?regras.push(`Válido para clientes com no mínimo ${quantidadePedidos} pedido(s)`):cupom.tipo_quantidade_pedidos==="maximo"&&quantidadePedidos>=0&&regras.push(`Válido para clientes com no máximo ${quantidadePedidos} pedido(s)`),this.obterIdsCategorias(cupom.categorias).length>0&&regras.push("Válido para categorias selecionadas");const diasSemana=this.obterIdsCategorias(cupom.dias_semana);if(diasSemana.length>0){const nomesDias={1:"segunda-feira",2:"terça-feira",3:"quarta-feira",4:"quinta-feira",5:"sexta-feira",6:"sábado",7:"domingo"};regras.push(`Válido ${diasSemana.map(dia=>nomesDias[dia]).filter(Boolean).join(", ")}`)}const estados=this.obterIdsCategorias(cupom.estados);return estados.length>0&&regras.push(`Entrega válida para: ${estados.join(", ")}`),this.cupomTemCatalogoRestrito(cupom)&&regras.push("Válido neste catálogo"),limiteUsoTotal>0&&regras.push(`Limite de ${limiteUsoTotal} uso(s)`),limiteUsoIndividual>0&&regras.push(`Limite de ${limiteUsoIndividual} uso(s) por cliente`),cupom.limite_data_termino&&regras.push(`Válido até ${cupom.limite_data_termino}`),regras},abrirDialogRegras(cupom){this.cupomSelecionado=cupom,this.dialogRegrasVisivel=!0},descricaoCupom(cupom){return cupom.descricao?cupom.descricao:cupom.tipo_valor==="porcentagem"?`${Number(cupom.valor||0)}% OFF`:cupom.tipo_valor==="fixo"?`R$ ${this.formatarPreco(cupom.valor)} OFF`:cupom.tipo_valor==="frete_gratis"?"Frete grátis":cupom.tipo_valor==="fixo_frete"?`R$ ${this.formatarPreco(cupom.valor)} OFF no frete`:cupom.tipo_valor==="porcentagem_frete"?`${Number(cupom.valor||0)}% OFF no frete`:"Desconto especial"},labelCupom(cupom){return cupom.tipo_quantidade_pedidos==="nenhum"?"CUPOM PRIMEIRA COMPRA":"CUPOM DE DESCONTO"},async copiarCodigo(codigo){var _a;const codigoCupom=String(codigo);try{(_a=navigator.clipboard)!=null&&_a.writeText?await navigator.clipboard.writeText(codigoCupom):this.copiarCodigoLegado(codigoCupom)}catch(error){try{this.copiarCodigoLegado(codigoCupom)}catch(fallbackError){console.error("Erro ao copiar cupom:",fallbackError);return}}this.codigoCopiado=codigoCupom,clearTimeout(this.timeoutCopiado),this.timeoutCopiado=setTimeout(()=>{this.codigoCopiado=null},1800)},copiarCodigoLegado(codigo){const input=document.createElement("textarea");input.value=codigo,input.setAttribute("readonly",""),input.style.position="fixed",input.style.opacity="0",document.body.appendChild(input),input.select();const copiado=document.execCommand("copy");if(input.remove(),!copiado)throw new Error("Não foi possível copiar o cupom")}},template:`
    <section v-if="cuponsExibiveis.length" class="fz-produto-cupons" aria-label="Cupons disponíveis">
        <transition-group name="fz-produto-cupons" tag="div" class="fz-produto-cupons__lista">
            <article v-for="(cupom, indice) in cuponsVisiveis" :key="cupom.codigo + indice" class="fz-produto-cupom">
                <div class="fz-produto-cupom__info">
                    <span class="fz-produto-cupom__icone" aria-hidden="true">
                        <svg viewBox="0 0 64 64" focusable="false">
                            <path d="M14 14h36a4 4 0 0 1 4 4v7.2c-3.7.7-6.5 3.9-6.5 7.8s2.8 7.1 6.5 7.8V46a4 4 0 0 1-4 4H14a4 4 0 0 1-4-4v-5.2c3.7-.7 6.5-3.9 6.5-7.8S13.7 25.9 10 25.2V18a4 4 0 0 1 4-4Z"/>
                            <path d="M32 17v30" stroke-dasharray="4 4"/>
                            <circle cx="24.5" cy="25.5" r="3.2"/>
                            <circle cx="39.5" cy="38.5" r="3.2"/>
                            <path d="M22 41.5 42 21.5"/>
                        </svg>
                    </span>
                    <div class="fz-produto-cupom__texto">
                        <span class="fz-produto-cupom__label">{{ labelCupom(cupom) }}</span>
                        <strong class="fz-produto-cupom__beneficio">{{ descricaoCupom(cupom) }}</strong>
                        <button
                            v-if="regrasCupom(cupom).length"
                            type="button"
                            class="fz-produto-cupom__regras-link"
                            aria-haspopup="dialog"
                            @click="abrirDialogRegras(cupom)">
                            Regras de Uso
                        </button>
                    </div>
                </div>

                <button
                    type="button"
                    class="fz-produto-cupom__copiar"
                    :class="{ 'fz-produto-cupom__copiar--copiado': codigoCopiado === cupom.codigo }"
                    :aria-label="'Copiar cupom ' + cupom.codigo"
                    @click="copiarCodigo(cupom.codigo)">
                    <span class="fz-produto-cupom__codigo">{{ cupom.codigo }}</span>
                    <span class="fz-produto-cupom__acao">
                        <svg viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                            <rect x="8" y="8" width="11" height="11" rx="2"/>
                            <path d="M16 8V6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h2"/>
                        </svg>
                        <span>{{ codigoCopiado === cupom.codigo ? 'Copiado' : 'Copiar' }}</span>
                    </span>
                </button>
            </article>
        </transition-group>
        <p-button
            v-if="exibirToggleCupons"
            type="button"
            :label="cuponsExpandidos ? 'Ver menos cupons' : 'Ver mais cupons'"
            :icon="cuponsExpandidos ? 'pi pi-chevron-up' : 'pi pi-chevron-down'"
            outlined
            severity="primary"
            class="fz-produto-cupons__toggle"
            :aria-expanded="cuponsExpandidos"
            @click="cuponsExpandidos = !cuponsExpandidos"
        ></p-button>
        <p-dialog
            v-model:visible="dialogRegrasVisivel"
            modal
            :draggable="false"
            :dismissableMask="true"
            header="Regras de Uso"
            :style="{ width: '90vw', maxWidth: '460px' }"
            class="fz-dialog-regras-cupom"
            :pt="{ header: 'pb-2', content: 'pt-0' }">
            <div v-if="cupomSelecionado" class="fz-dialog-regras-cupom__conteudo">
                <div class="fz-dialog-regras-cupom__cabecalho">
                    <span class="fz-dialog-regras-cupom__label">{{ labelCupom(cupomSelecionado) }}</span>
                    <strong>{{ descricaoCupom(cupomSelecionado) }}</strong>
                    <span class="fz-dialog-regras-cupom__codigo">Cupom: {{ cupomSelecionado.codigo }}</span>
                </div>
                <ul v-if="regrasCupom(cupomSelecionado).length" class="fz-dialog-regras-cupom__lista">
                    <li v-for="regra in regrasCupom(cupomSelecionado)" :key="regra">{{ regra }}</li>
                </ul>
                <p v-else class="fz-dialog-regras-cupom__sem-regras">
                    Este cupom não possui condições adicionais cadastradas.
                </p>
            </div>
        </p-dialog>
        <span class="sr-only" aria-live="polite">{{ codigoCopiado ? 'Cupom ' + codigoCopiado + ' copiado.' : '' }}</span>
    </section>
    `},FZComponents.ProdutoModalProdutosRelacionados={components:{"p-divider":PrimeVue.Divider,"fz-produto-skeleton":FZComponents.ProdutoSkeleton,"fz-produto":FZComponents.Produto},mixins:[ProdutoConteudoMixin],props:{produto:{type:Object,required:!0},exibirTitulo:{type:Boolean,default:!0},abrirLinkDireto:{type:Boolean,default:!1}},data(){return{produtosRelacionados:[],carregando:!1,erro:null,swiperRelacionados:null}},computed:{layoutProduto(){return["clean","clean_2","color","grid_novo","grid_2","fancy"].includes(configsLoja.layoutProdutos)?configsLoja.layoutProdutos:"grid_novo"},produtos(){return this.produtosRelacionados.length>0?this.produtosRelacionados:Array.isArray(this.produto.produtos_relacionados)&&this.produto.produtos_relacionados.length>0?this.produto.produtos_relacionados:[]},temProdutos(){return this.produtos.length>0},exibirSecao(){return this.carregando||this.temProdutos||!this.erro&&this.produtosRelacionados.length===0&&!this.produto.produtos_relacionados}},mounted(){this.carregando=!0,setTimeout(()=>{this.carregando=!1,this.carregarProdutosRelacionados()},1e3)},beforeUnmount(){this.swiperRelacionados&&this.swiperRelacionados.destroy(!0,!0)},methods:{async carregarProdutosRelacionados(){var _a;if(Array.isArray(this.produto.produtos_relacionados)&&this.produto.produtos_relacionados.length>0){this.produtosRelacionados=this.produto.produtos_relacionados,this.$nextTick(()=>{this.initSwiper()});return}const cache=(_a=this.conteudoStore.cacheProdutos[this.produto.id])==null?void 0:_a.relacionados;if(cache&&Array.isArray(cache.produtos)){this.produtosRelacionados=cache.produtos,this.$nextTick(()=>{this.produtosRelacionados.length>0&&this.initSwiper()});return}this.carregando=!0,this.erro=null;try{const url=this.obterLinkCatalogo(`produto/${this.produto.id}`)+"?relacionados",data=await(await fetch(url)).json();this.produtosRelacionados=data.produtos_relacionados||[],this.conteudoStore.cacheProdutos[this.produto.id]||(this.conteudoStore.cacheProdutos[this.produto.id]={}),this.conteudoStore.cacheProdutos[this.produto.id].relacionados={produtos:this.produtosRelacionados}}catch(error){console.error("[Produtos Relacionados] Erro ao carregar:",error),this.erro="Erro ao carregar produtos relacionados."}finally{this.carregando=!1,this.$nextTick(()=>{this.temProdutos&&this.initSwiper()})}},initSwiper(){const elem=this.$refs.swiperRelacionados;!elem||typeof Swiper=="undefined"||(this.swiperRelacionados&&this.swiperRelacionados.destroy(!0,!0),this.swiperRelacionados=new Swiper(elem,{slidesPerView:"auto",spaceBetween:12,observer:!0,observeParents:!0,observeSlideChildren:!0,watchOverflow:!0,autoplay:{delay:4e3,disableOnInteraction:!0},navigation:{nextEl:this.$refs.nextRelacionados,prevEl:this.$refs.prevRelacionados}}))}},template:`
    <div v-if="exibirSecao && !erro" class="fz-produto-conteudo__relacionados mt-4">
        <p-divider v-if="exibirTitulo" align="left" type="solid" class="fz-produto-conteudo__divisoria">
            <i class="ti-layout-grid2"></i> <b>Produtos Relacionados</b>
        </p-divider>

        <!-- Loading Skeleton -->
        <div v-if="carregando" class="fz-produto-conteudo__relacionados-loading">
            <div class="row">
                <div v-for="n in 3" :key="n" class="col-12 col-sm-6 col-md-4">
                    <fz-produto-skeleton></fz-produto-skeleton>
                </div>
            </div>
        </div>

        <!-- Lista de Produtos -->
        <div v-else-if="temProdutos" ref="swiperRelacionados" class="fz-produto-conteudo__relacionados-carousel swiper" style="position: relative;">
            <div class="swiper-wrapper">
                <div v-for="produtoRelacionado in produtos" :key="produtoRelacionado.id" class="swiper-slide fz-produto-conteudo__relacionados-item">
                    <fz-produto
                        :produto="produtoRelacionado"
                        :layout="layoutProduto"
                        :catalogo-url="baseUrlCatalogo"
                        :abrir-link-direto="abrirLinkDireto"
                        :somente-orcamentos="configsLoja.somenteOrcamentos"
                        :precos-restritos="configsLoja.precosRestritos"
                        :preco-destaque="configsLoja.precoDestaque"
                        :mostrar-quantidade-venda="configsLoja.mostrarQuantidadeVenda"
                        :habilitar-curtidas="configsLoja.habilitarCurtidas"
                        :habilitar-perguntas="configsLoja.habilitarPerguntas"
                        :permitir-compartilhar-produto="configsLoja.permitirCompartilharProduto"
                        :ativar-simulador-parcelas="configsLoja.ativarSimuladorParcelas"
                        :texto-botao-acao-produtos="configsLoja.textoBotaoAcaoProdutos"
                        :icone-botao-acao-produtos="configsLoja.iconeBotaoAcaoProdutos"
                        :grid-formato-imagem="configsLoja.gridFormatoImagem"
                        :campanha-promocional-ativa-no-momento="configsLoja.campanhaPromocionalAtivaNoMomento"
                        :campanha-promocional-tag-produtos-ativada="configsLoja.campanhaPromocionalTagProdutosAtivada"
                        :campanha-promocional-tag-produtos-texto="configsLoja.campanhaPromocionalTagProdutosTexto"
                        :campanha-promocional-tag-produtos-cor-fundo="configsLoja.campanhaPromocionalTagProdutosCorFundo"
                        :campanha-promocional-tag-produtos-cor-texto="configsLoja.campanhaPromocionalTagProdutosCorTexto"
                    ></fz-produto>
                </div>
            </div>
            <div v-if="produtos.length > 1" ref="nextRelacionados" class="fz-produto-conteudo__relacionados-nav-proximo fz-seta-slider swiper-button-next relacionados"></div>
            <div v-if="produtos.length > 1" ref="prevRelacionados" class="fz-produto-conteudo__relacionados-nav-anterior fz-seta-slider swiper-button-prev relacionados"></div>
        </div>
    </div>`},FZComponents.ProdutoModalComentarios={components:{"p-divider":PrimeVue.Divider,"p-skeleton":PrimeVue.Skeleton,"p-paginator":PrimeVue.Paginator,"p-textarea":PrimeVue.Textarea,"p-button":PrimeVue.Button,"p-message":PrimeVue.Message},mixins:[ProdutoConteudoMixin],props:{produto:{type:Object,required:!0},exibirTitulo:{type:Boolean,default:!0},layout:{type:String,default:"modelo1",validator:value=>["modelo1","modelo2"].includes(value)}},data(){return{perguntas:[],carregando:!1,novoComentario:"",enviando:!1,erro:null,paginaAtual:1,totalRegistros:0,porPagina:10,busca:"",perguntaAberta:null,mostrarFormulario:!1,timeoutBusca:null,requisicaoComentariosId:0}},computed:{temPerguntas(){return this.perguntas.length>0},podeEnviarComentario(){return this.configsLoja.clienteLogado||this.configsLoja.visitanteLogado},caracteresRestantes(){var _a;return 500-(((_a=this.novoComentario)==null?void 0:_a.length)||0)},buscaNormalizada(){return this.busca.trim()},totalPaginas(){return Math.ceil(this.totalRegistros/this.porPagina)},temMaisPerguntas(){return this.perguntas.length<this.totalRegistros}},beforeUnmount(){clearTimeout(this.timeoutBusca)},mounted(){this.carregarComentarios(1)},methods:{chaveCacheComentarios(pagina){return`comentarios_${this.produto.id}_${pagina}_${this.buscaNormalizada.toLowerCase()}`},async carregarComentarios(pagina=1,anexar=!1){var _a;const requisicaoId=++this.requisicaoComentariosId,chaveCache=this.chaveCacheComentarios(pagina),cache=(_a=this.conteudoStore.cacheProdutos[this.produto.id])==null?void 0:_a[chaveCache];if(cache&&Date.now()-cache.timestamp<6e4){this.perguntas=anexar?[...this.perguntas,...cache.perguntas]:cache.perguntas,this.totalRegistros=cache.total,this.paginaAtual=pagina,this.abrirPrimeiraPerguntaRespondida();return}this.carregando=!0,this.erro=null;try{const busca=this.buscaNormalizada?`&busca=${encodeURIComponent(this.buscaNormalizada)}`:"",url=this.obterLinkCatalogo(`produto/${this.produto.id}`)+`?comentarios&pagina=${pagina}${busca}`,data=await(await fetch(url)).json();if(requisicaoId!==this.requisicaoComentariosId)return;const perguntas=data.perguntas||[];this.perguntas=anexar?[...this.perguntas,...perguntas]:perguntas,this.totalRegistros=data.total||0,this.porPagina=data.porPagina||10,this.paginaAtual=pagina,this.conteudoStore.cacheProdutos[this.produto.id]||(this.conteudoStore.cacheProdutos[this.produto.id]={}),this.conteudoStore.cacheProdutos[this.produto.id][chaveCache]={perguntas,total:this.totalRegistros,timestamp:Date.now()},this.abrirPrimeiraPerguntaRespondida()}catch(error){if(requisicaoId!==this.requisicaoComentariosId)return;console.error("[Comentários] Erro ao carregar comentários:",error),this.erro="Erro ao carregar perguntas."}finally{requisicaoId===this.requisicaoComentariosId&&(this.carregando=!1)}},limparCache(){const cacheProduto=this.conteudoStore.cacheProdutos[this.produto.id];if(cacheProduto)for(const chave of Object.keys(cacheProduto))chave.startsWith("comentarios_")&&delete cacheProduto[chave]},formatarData(data){return new Date(data).toLocaleDateString("pt-BR")},getNomePergunta(pergunta){return pergunta.nome?this.limitarNome(pergunta.nome):pergunta.cliente_nome?this.limitarNome(pergunta.cliente_nome):"Anônimo"},limitarNome(nome){const primeiroNome=nome.split(" ")[0];return primeiroNome.length>15?primeiroNome.substring(0,15):primeiroNome},getTelefone(pergunta){return pergunta.cliente_whatsapp?pergunta.cliente_whatsapp:pergunta.whatsapp?pergunta.whatsapp:""},parseMensagem(mensagem){if(!mensagem)return"";try{return JSON.parse(mensagem).replace(/\n/g,"<br>")}catch(e){return mensagem.replace(/\n/g,"<br>")}},textoPergunta(pergunta){return this.parseMensagem(pergunta.mensagem).replace(/<br\s*\/?\s*>/gi," ")},chavePergunta(pergunta,index){return`${pergunta.created_at||"sem-data"}-${index}-${this.textoPergunta(pergunta)}`},perguntaEstaAberta(pergunta,index){return this.perguntaAberta===this.chavePergunta(pergunta,index)},alternarPergunta(pergunta,index){const chave=this.chavePergunta(pergunta,index);this.perguntaAberta=this.perguntaAberta===chave?null:chave},abrirPrimeiraPerguntaRespondida(){if(this.perguntaAberta||this.layout!=="modelo2")return;const index=this.perguntas.findIndex(pergunta=>pergunta.resposta);index>=0&&(this.perguntaAberta=this.chavePergunta(this.perguntas[index],index))},agendarBusca(){clearTimeout(this.timeoutBusca),this.timeoutBusca=setTimeout(()=>{this.perguntaAberta=null,this.carregarComentarios(1)},250)},carregarMaisPerguntas(){this.carregando||!this.temMaisPerguntas||this.carregarComentarios(this.paginaAtual+1,!0)},alternarFormulario(){if(!this.podeEnviarComentario){this.abrirLoginVisitante();return}this.mostrarFormulario=!this.mostrarFormulario},async enviarComentario(){if(!this.novoComentario.trim()){this.showNotification("Digite a pergunta!","info");return}if(this.novoComentario.length>500){this.showNotification("A pergunta deve ter no máximo 500 caracteres.","warn");return}this.enviando=!0,this.erro=null;try{const formData=new FormData;formData.append("acao","enviar_pergunta"),formData.append("produto",this.produto.id),formData.append("pergunta",this.novoComentario.trim());const data=await(await fetch(this.configsLoja.urlCatalogo,{method:"POST",body:formData})).json();data.sucesso?(this.novoComentario="",this.mostrarFormulario=!1,this.showNotification("Pergunta enviada com sucesso!","success"),this.limparCache(),this.carregarComentarios(1)):this.showNotification((data==null?void 0:data.mensagem)||"Houve um erro! Tente novamente mais tarde.","error")}catch(error){this.showNotification("Erro ao enviar pergunta. Tente novamente.","error")}finally{this.enviando=!1}},onPageChange(event){this.carregarComentarios(event.page+1)},showNotification(message,type){typeof showNotification2=="function"&&showNotification2(message,type)},abrirLoginVisitante(){typeof abrirModalLoginVisitante=="function"&&(this.dialogDrawerStore.isOpen=!1,abrirModalLoginVisitante("recarregar"))}},template:`
    <div class="fz-produto-conteudo__comentarios mt-4" :class="'fz-produto-conteudo__comentarios--' + layout">
        <template v-if="layout === 'modelo2'">
            <div class="fz-produto-perguntas-modelo2__toolbar">
                <input
                    v-model="busca"
                    type="search"
                    class="fz-produto-perguntas-modelo2__busca"
                    placeholder="Buscar: tamanho, garantia, frete..."
                    aria-label="Buscar perguntas"
                    @input="agendarBusca"
                />
                <button type="button" class="fz-produto-perguntas-modelo2__perguntar" @click="alternarFormulario">
                    Fazer uma pergunta
                </button>
            </div>

            <div v-if="carregando && !temPerguntas" class="fz-produto-conteudo__comentarios-loading">
                <p-skeleton v-for="n in 3" :key="n" height="54px" class="mb-2"></p-skeleton>
            </div>

            <template v-else>
                <p v-if="erro" class="fz-produto-perguntas-modelo2__erro">{{ erro }}</p>
                <div v-else-if="temPerguntas" class="fz-produto-perguntas-modelo2__lista">
                    <article v-for="(pergunta, index) in perguntas" :key="chavePergunta(pergunta, index)" class="fz-produto-perguntas-modelo2__item">
                        <button
                            type="button"
                            class="fz-produto-perguntas-modelo2__pergunta"
                            :aria-expanded="perguntaEstaAberta(pergunta, index)"
                            @click="alternarPergunta(pergunta, index)"
                        >
                            <span>
                                <strong>{{ textoPergunta(pergunta) }}</strong>
                                <small>{{ pergunta.resposta ? 'Respondida' : 'Aguardando resposta' }} · {{ formatarData(pergunta.resposta ? pergunta.resposta_data : pergunta.created_at) }}</small>
                            </span>
                            <i :class="perguntaEstaAberta(pergunta, index) ? 'pi pi-chevron-up' : 'pi pi-chevron-down'" aria-hidden="true"></i>
                        </button>
                        <div v-if="perguntaEstaAberta(pergunta, index)" class="fz-produto-perguntas-modelo2__resposta">
                            <strong>{{ pergunta.resposta ? 'Resposta da loja' : 'Aguardando resposta da loja' }}</strong>
                            <div v-if="pergunta.resposta" v-html="parseMensagem(pergunta.resposta)"></div>
                            <div v-else>Sua pergunta foi enviada e será respondida em breve.</div>
                        </div>
                    </article>
                </div>
                <div v-else class="fz-produto-conteudo__sem-comentarios p-3 rounded text-center">
                    <p class="mb-0 text-muted">Nenhuma pergunta encontrada para este produto.</p>
                </div>

                <button
                    v-if="temMaisPerguntas"
                    type="button"
                    class="fz-produto-perguntas-modelo2__mais"
                    :disabled="carregando"
                    @click="carregarMaisPerguntas"
                >
                    {{ carregando ? 'Carregando...' : 'Ver mais perguntas' }}
                </button>
            </template>

            <div v-if="mostrarFormulario" class="fz-produto-perguntas-modelo2__formulario">
                <p-textarea
                    v-model="novoComentario"
                    rows="5"
                    :disabled="enviando"
                    placeholder="Digite sua dúvida sobre o produto..."
                    :maxlength="500"
                    class="w-100"
                    :auto-resize="true"
                ></p-textarea>
                <div class="fz-produto-perguntas-modelo2__formulario-rodape">
                    <small>{{ caracteresRestantes }} caracteres restantes</small>
                    <p-button
                        label="Enviar pergunta"
                        :loading="enviando"
                        :disabled="enviando || !novoComentario.trim()"
                        @click="enviarComentario"
                    ></p-button>
                </div>
            </div>
        </template>

        <template v-else>
            <p-divider v-if="exibirTitulo" align="left" type="solid">
                <i class="pi pi-comments"></i> <b>Perguntas</b>
            </p-divider>
            <div v-if="carregando" class="fz-produto-conteudo__comentarios-loading">
                <p-skeleton v-for="n in 2" :key="n" height="40px" class="mb-3"></p-skeleton>
            </div>
            <div v-else class="fz-produto-conteudo__comentarios-lista mb-3">
                <template v-if="temPerguntas">
                    <div v-for="(pergunta, index) in perguntas" :key="index" class="fz-produto-conteudo__comentario">
                        <div class="d-flex justify-content-between align-items-start mb-2">
                            <div class="d-flex align-items-center gap-2">
                                <i class="fa fa-user-circle text-muted" style="font-size: 1.2rem;"></i>
                                <div class="font-weight-bold" style="font-size: 14px;">{{ getNomePergunta(pergunta) }}</div>
                            </div>
                            <small class="text-muted"><i class="fa fa-calendar"></i> {{ formatarData(pergunta.created_at) }}</small>
                        </div>
                        <div class="fz-produto-conteudo__comentario-mensagem" v-html="parseMensagem(pergunta.mensagem)"></div>
                        <div v-if="pergunta.resposta" class="fz-produto-conteudo__comentario-resposta mt-2">
                            <div class="font-weight-bold text-success mb-2"><i class="fa fa-store"></i> {{ configsLoja.nomeLoja }}</div>
                            <div class="text-dark" v-html="parseMensagem(pergunta.resposta)"></div>
                        </div>
                    </div>
                </template>
                <div v-else class="fz-produto-conteudo__sem-comentarios p-3 rounded text-center">
                    <p class="mb-0 text-muted">Nenhuma pergunta neste produto ainda.<br/>Que tal enviar a primeira pergunta?</p>
                </div>
            </div>
            <p-paginator
                v-if="totalPaginas > 1"
                :rows="porPagina"
                :totalRecords="totalRegistros"
                :first="(paginaAtual - 1) * porPagina"
                @page="onPageChange"
                class="mb-3"
            ></p-paginator>
            <div class="fz-produto-conteudo__novo-comentario">
                <div v-if="!podeEnviarComentario" class="text-center">
                    <p-button label="Enviar Pergunta" icon="fa fa-sign-in" severity="primary" @click="abrirLoginVisitante"></p-button>
                </div>
                <div v-else class="fz-produto-conteudo__form-comentario">
                    <label class="font-weight-bold mb-2">Envie uma Pergunta:</label>
                    <p-textarea v-model="novoComentario" rows="4" :disabled="enviando" placeholder="Digite sua pergunta aqui..." :maxlength="500" class="w-100 mb-1" :auto-resize="true"></p-textarea>
                    <small class="fz-produto-conteudo__contador-caracteres text-muted d-block mb-2">{{ caracteresRestantes }} caracteres restantes</small>
                    <div class="text-center">
                        <p-button label="Enviar Pergunta" icon="fa fa-paper-plane" severity="primary" :loading="enviando" :disabled="enviando || !novoComentario.trim()" @click="enviarComentario"></p-button>
                    </div>
                </div>
            </div>
        </template>
    </div>
    `},FZComponents.ProdutoModalAviseMeForm={components:{"p-message":PrimeVue.Message,"p-inputtext":PrimeVue.InputText,"p-button":PrimeVue.Button,"fz-input-phone":FZComponents.InputPhone},mixins:[ProdutoConteudoMixin],props:{produto:{type:Object,required:!0},exibirTitulo:{type:Boolean,default:!0}},data(){return{nome:"",whatsapp:{raw:"",e164:"",ddi:"",country:"",valid:!1},enviando:!1,sucesso:!1,erro:null}},computed:{formularioValido(){return this.nome&&this.whatsapp.valid}},methods:{async enviarAviseMe(){if(!this.formularioValido){this.erro="Preencha todos os campos corretamente";return}this.enviando=!0,this.erro=null;try{const formData=new FormData;formData.append("acao","avise_me"),formData.append("produto",this.produto.id),formData.append("nome",this.nome),formData.append("whatsapp",this.whatsapp.raw),formData.append("whatsapp_e164",this.whatsapp.e164),formData.append("whatsapp_ddi",this.whatsapp.ddi),formData.append("whatsapp_country",this.whatsapp.country);const result=await(await fetch(this.obterLinkCatalogo(""),{method:"POST",body:formData})).json();result.success?(this.sucesso=!0,this.nome="",this.whatsapp={raw:"",e164:"",ddi:"",country:"",valid:!1}):this.erro=result.erro||"Erro ao enviar solicitação"}catch(error){this.erro="Erro ao enviar solicitação",console.error(error)}finally{this.enviando=!1}}},template:`
    <div class="fz-produto-conteudo__avise-me p-3 bg-light rounded">
        <h5 class="fz-produto-conteudo__avise-me-titulo mb-3">
            <i class="fz-produto-conteudo__avise-me-icone pi pi-bell"></i> Avise-me quando chegar
        </h5>

        <p-message
            v-if="sucesso"
            severity="success"
            size="small"
            :closable="false"
            icon="pi pi-check"
            class="mb-3"
        >
            Solicitação enviada com sucesso! Você será notificado quando o produto estiver disponível.
        </p-message>

        <form v-else @submit.prevent="enviarAviseMe" class="fz-produto-conteudo__avise-me-formulario">
            <div class="fz-produto-conteudo__avise-me-campo mb-3">
                <label class="fz-produto-conteudo__avise-me-label form-label">Nome:</label>
                <p-inputtext
                    v-model="nome"
                    type="text"
                    placeholder="Seu nome"
                    :required="true"
                    class="w-100"
                ></p-inputtext>
            </div>

            <div class="fz-produto-conteudo__avise-me-campo mb-3">
                <label class="fz-produto-conteudo__avise-me-label form-label">WhatsApp:</label>
                <fz-input-phone
                    v-model="whatsapp"
                    placeholder="(00) 00000-0000"
                    :required="true"
                    :disabled="enviando"
                    size="normal"
                ></fz-input-phone>
                <p-message
                    v-if="whatsapp.raw && !whatsapp.valid"
                    severity="error"
                    size="small"
                    :closable="false"
                    icon="pi pi-exclamation-triangle"
                    class="mt-2"
                >
                    Número de telefone inválido
                </p-message>
            </div>

            <p-message
                v-if="erro"
                severity="error"
                size="small"
                :closable="false"
                icon="pi pi-exclamation-triangle"
                class="mb-3"
            >
                {{ erro }}
            </p-message>

            <p-button
                type="submit"
                :label="enviando ? 'Enviando...' : 'Avise-me'"
                icon="pi pi-bell"
                :loading="enviando"
                :disabled="!formularioValido"
                severity="primary"
                class="w-100"
            ></p-button>
        </form>
    </div>
    `},FZComponents.ProdutoAvaliacoes={components:{"p-image":PrimeVue.Image,"p-button":PrimeVue.Button,"p-textarea":PrimeVue.Textarea},mixins:[ProdutoConteudoMixin],props:{produto:{type:Object,required:!0},exibirTitulo:{type:Boolean,default:!0},layout:{type:String,default:"modelo1",validator:value=>["modelo1","modelo2"].includes(value)}},data(){return{avaliacoes:[],carregando:!1,paginaAtual:1,temMais:!1,mostrarFormularioAvaliacao:!1,notaAvaliacao:0,textoAvaliacao:"",enviandoAvaliacao:!1,erroAvaliacao:null,sucessoAvaliacao:!1,resumoAvaliacao:null}},computed:{totalAvaliacoes(){var _a,_b;return Number((_b=(_a=this.resumoAvaliacao)==null?void 0:_a.total)!=null?_b:this.produto.total_avaliacoes)||0},mediaAvaliacoes(){var _a,_b;return Number((_b=(_a=this.resumoAvaliacao)==null?void 0:_a.media)!=null?_b:this.produto.media_avaliacoes)||0},estrelas(){const nota=Math.round(this.mediaAvaliacoes);return Array.from({length:5},(_,i)=>i<nota)},exibir(){var _a;return this.totalAvaliacoes>0||((_a=this.configsLoja)==null?void 0:_a.permitirAvaliacoesAvulsas)},exibirBotaoAvaliar(){var _a;return!!((_a=this.configsLoja)!=null&&_a.permitirAvaliacoesAvulsas)},distribuicaoAvaliacoes(){var _a;const distribuicao=((_a=this.resumoAvaliacao)==null?void 0:_a.distribuicao)||{};return[5,4,3,2,1].map(nota=>({nota,total:Number(distribuicao[nota])||0}))}},mounted(){this.exibir&&this.carregarAvaliacoes()},methods:{async carregarAvaliacoes(){if(!this.carregando){this.carregando=!0;try{const url=`${this.configsLoja.baseUrl}/api/avaliacoes_pedidos/listar_produto/${this.produto.id}?p=${this.paginaAtual}`,response=await fetch(url);if(!response.ok){if(response.status===400){this.temMais=!1;return}throw new Error("Erro ao carregar avaliações")}const data=await response.json(),novas=Array.isArray(data)?data:data.data||[];data!=null&&data.resumo&&(this.resumoAvaliacao=data.resumo),this.paginaAtual===1?this.avaliacoes=novas:this.avaliacoes.push(...novas),this.temMais=novas.length>=10}catch(error){console.error("Erro ao carregar avaliações do produto:",error)}finally{this.carregando=!1}}},carregarMais(){this.carregando||!this.temMais||(this.paginaAtual++,this.carregarAvaliacoes())},formatarData(dataStr){if(!dataStr)return"";const data=new Date(dataStr.replace(" ","T"));if(isNaN(data.getTime()))return dataStr;const diffMs=new Date-data,diffDias=Math.floor(diffMs/(1e3*60*60*24));return diffDias<1?"hoje":diffDias===1?"há 1 dia":diffDias<7?`há ${diffDias} dias`:diffDias<14?"há 1 semana":diffDias<30?`há ${Math.floor(diffDias/7)} semanas`:diffDias<60?"há 1 mês":diffDias<365?`há ${Math.floor(diffDias/30)} meses`:diffDias<730?"há 1 ano":`há ${Math.floor(diffDias/365)} anos`},nomeExibicao(avaliacao){const partes=[];return avaliacao.nome&&partes.push(avaliacao.nome),avaliacao.whatsapp&&partes.push(avaliacao.whatsapp.replace(/&hellip;/g,"...")),partes.length===0?"Cliente":partes.join(" · ")},obterIniciais(nome){return nome?nome.split(" ").map(p=>p[0]).slice(0,2).join("").toUpperCase():"C"},obterEstrelas(nota){const n=Math.round(Number(nota)||0);return Array.from({length:5},(_,i)=>i<n)},obterFotos(avaliacao){return avaliacao.fotos?avaliacao.fotos:[]},percentualDistribuicao(total){return this.totalAvaliacoes?`${Math.round(total/this.totalAvaliacoes*100)}%`:"0%"},abrirFormularioAvaliacao(){var _a,_b;if(!((_a=this.configsLoja)!=null&&_a.clienteLogado)&&!((_b=this.configsLoja)!=null&&_b.visitanteLogado)){typeof abrirModalLoginVisitante=="function"&&abrirModalLoginVisitante();return}this.mostrarFormularioAvaliacao=!0,this.notaAvaliacao=0,this.textoAvaliacao="",this.erroAvaliacao=null,this.sucessoAvaliacao=!1},selecionarNota(n){this.notaAvaliacao=n},async enviarAvaliacaoAvulsa(){if(this.notaAvaliacao<=0||this.notaAvaliacao>5){this.erroAvaliacao="Selecione uma nota entre 1 e 5.";return}this.enviandoAvaliacao=!0,this.erroAvaliacao=null;try{const formData=new FormData;formData.append("produto_id",this.produto.id),formData.append("variacao_id",0),formData.append("nota",this.notaAvaliacao),formData.append("avaliacao",this.textoAvaliacao.trim());const data=await(await fetch(`${this.configsLoja.baseUrl}/avaliacao/avulsa`,{method:"POST",body:formData})).json();data.sucesso?(this.sucessoAvaliacao=!0,this.notaAvaliacao=0,this.textoAvaliacao="",this.paginaAtual=1,this.carregarAvaliacoes()):this.erroAvaliacao=data.mensagem||"Erro ao enviar avaliação."}catch(error){console.error("Erro ao enviar avaliação avulsa:",error),this.erroAvaliacao="Erro ao enviar avaliação. Tente novamente."}finally{this.enviandoAvaliacao=!1}}},template:`
    <div v-if="exibir" class="fz-produto-avaliacoes" :class="'fz-produto-avaliacoes--' + layout">
        <div class="fz-avaliacoes-section">
            <template v-if="layout === 'modelo2'">
                <div class="fz-produto-avaliacoes-modelo2__resumo">
                    <div class="fz-produto-avaliacoes-modelo2__nota">
                        <strong>{{ mediaAvaliacoes.toFixed(1).replace('.', ',') }}</strong>
                        <span class="fz-produto-avaliacoes-modelo2__estrelas">
                            <span v-for="(cheia, index) in estrelas" :key="index" :class="cheia ? 'fz-estrela-cheia' : 'fz-estrela-vazia'">★</span>
                        </span>
                        <small>{{ totalAvaliacoes }} {{ totalAvaliacoes === 1 ? 'avaliação' : 'avaliações' }}</small>
                    </div>
                    <div class="fz-produto-avaliacoes-modelo2__barras">
                        <div v-for="item in distribuicaoAvaliacoes" :key="item.nota" class="fz-produto-avaliacoes-modelo2__barra">
                            <span>{{ item.nota }}★</span>
                            <i><i :style="{ width: percentualDistribuicao(item.total) }"></i></i>
                            <b>{{ item.total }}</b>
                        </div>
                    </div>
                </div>

                <div v-if="exibirBotaoAvaliar && !mostrarFormularioAvaliacao" class="fz-produto-avaliacoes-modelo2__acoes">
                    <button type="button" @click="abrirFormularioAvaliacao">Avaliar produto</button>
                </div>

                <div v-if="mostrarFormularioAvaliacao" class="fz-produto-avaliacoes-modelo2__formulario">
                    <div v-if="sucessoAvaliacao" class="text-success">Avaliação enviada com sucesso! Em breve ela será exibida na página do produto.</div>
                    <template v-else>
                        <strong>Sua avaliação</strong>
                        <div class="fz-produto-avaliacoes-modelo2__seletor-estrelas">
                            <button v-for="n in 5" :key="n" type="button" :class="n <= notaAvaliacao ? 'fz-estrela-cheia' : 'fz-estrela-vazia'" @click="selecionarNota(n)">★</button>
                        </div>
                        <p-textarea v-model="textoAvaliacao" class="w-100" rows="4" :maxlength="500" placeholder="Conte sua experiência com o produto..." :auto-resize="true"></p-textarea>
                        <p v-if="erroAvaliacao" class="text-danger mb-2">{{ erroAvaliacao }}</p>
                        <div class="fz-produto-avaliacoes-modelo2__formulario-acoes">
                            <p-button type="button" :label="enviandoAvaliacao ? 'Enviando...' : 'Enviar avaliação'" :loading="enviandoAvaliacao" :disabled="enviandoAvaliacao || notaAvaliacao === 0" @click="enviarAvaliacaoAvulsa"></p-button>
                            <button type="button" @click="mostrarFormularioAvaliacao = false">Cancelar</button>
                        </div>
                    </template>
                </div>

                <div v-if="avaliacoes.length" class="fz-produto-avaliacoes-modelo2__lista">
                    <article v-for="(avaliacao, index) in avaliacoes" :key="index" class="fz-produto-avaliacoes-modelo2__item">
                        <div class="fz-produto-avaliacoes-modelo2__item-cabecalho">
                            <strong>{{ nomeExibicao(avaliacao) }}</strong>
                            <time>{{ formatarData(avaliacao.created_at) }}</time>
                        </div>
                        <div class="fz-produto-avaliacoes-modelo2__item-estrelas">
                            <span v-for="(cheia, idx) in obterEstrelas(avaliacao.nota)" :key="idx" :class="cheia ? 'fz-estrela-cheia' : 'fz-estrela-vazia'">★</span>
                        </div>
                        <p v-if="avaliacao.descricao">{{ avaliacao.descricao }}</p>
                        <small v-if="avaliacao.pedido">Compra verificada</small>
                    </article>
                </div>

                <button v-if="temMais" type="button" class="fz-produto-avaliacoes-modelo2__mais" :disabled="carregando" @click="carregarMais">
                    {{ carregando ? 'Carregando...' : 'Ver mais avaliações' }}
                </button>
            </template>

            <template v-else>
            <div class="fz-avaliacoes-cabecalho">
                <h2 v-if="exibirTitulo" class="fz-avaliacoes-titulo">Avaliações dos Clientes</h2>
                <p v-if="totalAvaliacoes > 0" class="fz-avaliacoes-subtitulo">Veja fotos e opiniões de quem já comprou este produto.</p>
                <p v-else class="fz-avaliacoes-subtitulo">Este produto ainda não possui avaliações.</p>
                <div class="fz-avaliacoes-resumo">
                    <span v-if="totalAvaliacoes > 0" class="fz-avaliacoes-nota">{{ mediaAvaliacoes.toFixed(1).replace('.', ',') }}</span>
                    <span v-if="totalAvaliacoes > 0" class="fz-avaliacoes-estrelas">
                        <span v-for="(cheia, index) in estrelas" :key="index" :class="cheia ? 'fz-estrela-cheia' : 'fz-estrela-vazia'">★</span>
                    </span>
                    <span v-if="totalAvaliacoes > 0" class="fz-avaliacoes-total">{{ totalAvaliacoes }} {{ totalAvaliacoes === 1 ? 'avaliação' : 'avaliações' }}</span>
                </div>
                <p-button
                    v-if="exibirBotaoAvaliar && !mostrarFormularioAvaliacao"
                    type="button"
                    icon="pi pi-star"
                    severity="primary"
                    label="Avaliar Produto"
                    class="mt-3"
                    @click="abrirFormularioAvaliacao"
                ></p-button>
            </div>

            <!-- Formulario Avulso -->
            <div v-if="mostrarFormularioAvaliacao" class="fz-avaliacao-formulario p-3 mb-3" style="border: 1px solid #ececec; border-radius: 10px; background: #fff;">
                <div v-if="sucessoAvaliacao" class="text-center">
                    <p class="text-success mb-0"><i class="pi pi-check"></i> Avaliação enviada com sucesso! Em breve ela será exibida na página do produto.</p>
                </div>
                <template v-else>
                    <h5 class="mb-2" style="font-size: 14px; font-weight: 700; color: #2f3441;">Sua avaliação</h5>
                    <div class="fz-avaliacao-modal-estrelas mb-2">
                        <span v-for="n in 5" :key="n" @click="selecionarNota(n)" :class="{ 'fz-estrela-cheia': n <= notaAvaliacao, 'fz-estrela-vazia': n > notaAvaliacao }" style="cursor:pointer; font-size: 28px; margin-right: 4px;">★</span>
                    </div>
                    <p-textarea
                        v-model="textoAvaliacao"
                        class="w-100 mb-2"
                        rows="3"
                        :maxlength="500"
                        placeholder="Conte sua experiência com o produto..."
                        :auto-resize="true"
                    ></p-textarea>
                    <p v-if="erroAvaliacao" class="text-danger mb-2" style="font-size: 12px;">{{ erroAvaliacao }}</p>
                    <div class="d-flex gap-2">
                        <p-button
                            type="button"
                            severity="primary"
                            :label="enviandoAvaliacao ? 'Enviando...' : 'Enviar Avaliação'"
                            :loading="enviandoAvaliacao"
                            :disabled="enviandoAvaliacao || notaAvaliacao === 0"
                            @click="enviarAvaliacaoAvulsa"
                        ></p-button>
                        <p-button
                            type="button"
                            severity="secondary"
                            variant="outlined"
                            label="Cancelar"
                            @click="mostrarFormularioAvaliacao = false"
                        ></p-button>
                    </div>
                </template>
            </div>

            <!-- List -->
            <div class="fz-avaliacao-lista">
                <div v-for="(avaliacao, index) in avaliacoes" :key="index" :class="['fz-avaliacao-item', { 'fz-avaliacao-item--sem-fotos': !obterFotos(avaliacao).length, 'fz-avaliacao-item--uma-foto': obterFotos(avaliacao).length === 1 }]">
                    <div class="fz-avaliacao-conteudo">
                        <div class="fz-avaliacao-topo">
                            <div class="fz-avaliacao-cliente">
                                <div class="fz-avaliacao-avatar">{{ obterIniciais(avaliacao.nome) }}</div>
                                <div class="fz-avaliacao-info">
                                    <strong class="fz-avaliacao-nome">{{ nomeExibicao(avaliacao) }}</strong>
                                    <span class="fz-avaliacao-verificado">{{ avaliacao.pedido ? 'Compra verificada' : '' }}</span>
                                </div>
                            </div>
                            <span class="fz-avaliacao-data">{{ formatarData(avaliacao.created_at) }}</span>
                        </div>

                        <div class="fz-avaliacao-estrelas">
                            <span v-for="(cheia, idx) in obterEstrelas(avaliacao.nota)" :key="idx" :class="cheia ? 'fz-estrela-cheia' : 'fz-estrela-vazia'">★</span>
                        </div>

                        <p v-if="avaliacao.descricao_aprovada" class="fz-avaliacao-texto">{{ avaliacao.descricao_aprovada }}</p>
                        <p v-else-if="avaliacao.descricao" class="fz-avaliacao-texto">{{ avaliacao.descricao }}</p>

                        <div v-if="avaliacao.produto_nome || avaliacao.variacao_nome" class="fz-avaliacao-meta">
                            <span v-if="avaliacao.variacao_nome">{{ avaliacao.variacao_nome }}</span>
                            <span v-else-if="avaliacao.produto_nome">{{ avaliacao.produto_nome }}</span>
                        </div>
                    </div>

                    <!-- Photos -->
                    <div v-if="obterFotos(avaliacao).length > 0" :class="['fz-avaliacao-fotos', { 'fz-avaliacao-fotos--uma': obterFotos(avaliacao).length === 1 }]">
                        <p-image
                            v-for="(foto, fIndex) in obterFotos(avaliacao)"
                            :key="fIndex"
                            :src="obterURLArquivos(foto)"
                            preview
                            image-class="fz-avaliacao-foto-img"
                            :image-style="{ cursor: 'pointer', objectFit: 'cover', width: '100%', height: '100%' }"
                            :pt="{ root: { style: 'display: block; width: 100%; height: 100%;' } }"
                        >
                            <template #previewicon><span></span></template>
                        </p-image>
                    </div>
                </div>
            </div>

            <!-- Load More -->
            <div v-if="temMais" class="fz-avaliacao-carregar-mais">
                <p-button
                    type="button"
                    severity="primary"
                    :label="carregando ? 'Carregando...' : 'Carregar mais avaliações'"
                    :loading="carregando"
                    :disabled="carregando"
                    @click="carregarMais"
                ></p-button>
            </div>
            </template>
        </div>
    </div>
    `};

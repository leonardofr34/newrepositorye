FZComponents.VariacaoQuantidade={inject:["configsLoja"],components:{"p-inputnumber":PrimeVue.InputNumber},props:{modelValue:{type:Number,default:0},min:{type:Number,default:0},max:{type:Number,default:999999},step:{type:Number,default:1},disabled:{type:Boolean,default:!1},modeloCondensado:{type:Boolean,default:!1}},emits:["update:modelValue"],data(){return{valorAnterior:0,inputElement:null,_handleFocusInCapture:null,ignorandoProximoFoco:!1}},methods:{handleFocusInCapture(e){e.target===this.inputElement&&this.ignorandoProximoFoco&&(console.warn("[VariacaoQuantidade] ⚠ focusin (capture) vindo do botão — fazendo blur"),this.inputElement.blur(),this.ignorandoProximoFoco=!1)},handleInputMousedown(){this.ignorandoProximoFoco=!1},reanexarListenersNoInput(novoInput){this.inputElement&&this.inputElement!==novoInput&&(this.inputElement.removeEventListener("focus",this.handleFocusInCapture),this.inputElement.removeEventListener("mousedown",this.handleInputMousedown)),this.inputElement=novoInput,this.inputElement.addEventListener("focus",this.handleFocusInCapture),this.inputElement.addEventListener("mousedown",this.handleInputMousedown)}},computed:{quantidade:{get(){return this.modelValue},set(value){let novoValor=parseInt(value)||0;novoValor=Math.max(this.min,Math.min(this.max,novoValor)),novoValor!==this.valorAnterior&&(AudioManager.playClick(),this.valorAnterior=novoValor),this.configsLoja.carrinhoAbandonadoAtivo&&this.configsLoja.carrinhoAbandonadoSolicitarLoginVisitante&&!this.configsLoja.clienteLogado&&!this.configsLoja.visitanteLogado&&typeof abrirModalLoginVisitante=="function"&&abrirModalLoginVisitante("atualizar_store_vue"),this.$emit("update:modelValue",novoValor)}},botoesQuantidadePassthrough(){const marcarIgnorarTouch=()=>{this.ignorandoProximoFoco=!0},marcarIgnorarMouse=e=>{this.ignorandoProximoFoco=!0,e.preventDefault()};return{incrementButton:{onTouchstart:marcarIgnorarTouch,onMousedown:marcarIgnorarMouse},decrementButton:{onTouchstart:marcarIgnorarTouch,onMousedown:marcarIgnorarMouse}}}},mounted(){this.valorAnterior=this.modelValue,this._handleFocusInCapture=e=>this.handleFocusInCapture(e),document.addEventListener("focusin",this._handleFocusInCapture,!0),console.log("[VariacaoQuantidade] listener focusin (capture) instalado no document"),this.$nextTick(()=>{const input=this.$el.querySelector("input.p-inputnumber-input");input?(this.reanexarListenersNoInput(input),console.log("[VariacaoQuantidade] input encontrado, listeners anexados")):console.warn("[VariacaoQuantidade] input.p-inputnumber-input não encontrado em mounted()")})},updated(){const input=this.$el.querySelector("input.p-inputnumber-input");input&&input!==this.inputElement&&(console.warn("[VariacaoQuantidade] ⚠ input foi recriado — re-anexando listeners"),this.reanexarListenersNoInput(input))},beforeUnmount(){this._handleFocusInCapture&&(document.removeEventListener("focusin",this._handleFocusInCapture,!0),this._handleFocusInCapture=null),this.inputElement&&(this.inputElement.removeEventListener("focus",this.handleFocusInCapture),this.inputElement.removeEventListener("mousedown",this.handleInputMousedown),this.inputElement=null)},template:`
    <p-inputnumber
        v-model="quantidade"
        :min="min"
        :max="max"
        :step="step"
        :disabled="disabled"
        size="small"
        show-buttons
        button-layout="horizontal"
        fluid
        input-class="text-center"
        :class="[
            'qty-format-' + (configsLoja.botoesQuantidadeFormato || 'arredondado'),
            { 'fz-variacao-quantidade--condensada': modeloCondensado }
        ]"
        style="max-width: 200px;"
        :pt="botoesQuantidadePassthrough"
    >
        <template #incrementicon>
            <i class="ti-plus"></i>
        </template>
        <template #decrementicon>
            <i class="ti-minus"></i>
        </template>
    </p-inputnumber>
    `},FZComponents.VariacaoSemVariacao={components:{"p-divider":PrimeVue.Divider,"p-button":PrimeVue.Button,"p-tag":PrimeVue.Tag,"fz-variacao-quantidade":FZComponents.VariacaoQuantidade},mixins:[ProdutoConteudoMixin],props:{produto:{type:Object,required:!0},catalogoId:{type:[String,Number],required:!0},carrinho:{type:Object,default:()=>({})},exibirSku:{type:Boolean,default:!0},exibirDescontos:{type:Boolean,default:!0},modeloCondensado:{type:Boolean,default:!1},usarSubgruposComoLista:{type:Boolean,default:!1}},data(){return{quantidade:0,inicializandoQuantidade:!0}},computed:{qtdMinima(){var _a,_b;const catalogoId=this.catalogoId;return parseInt((_b=(_a=this.produto.qtds_minimas)==null?void 0:_a[catalogoId])==null?void 0:_b[0])||0},qtdMaxima(){var _a,_b,_c;if(this.isKit)return this.kitEstoqueReal||0;const catalogoId=this.catalogoId,max=parseInt((_b=(_a=this.produto.qtds_maximas)==null?void 0:_a[catalogoId])==null?void 0:_b[0])||0,estoque=parseInt((_c=this.produto.estoque)==null?void 0:_c[0])||parseInt(this.produto.total_estoque)||0;return this.produto.controlar_estoque=="1"&&estoque>0?max>0?Math.min(max,estoque):estoque:max||999999},produtoDisponivel(){var _a;return this.isKit?!this.produto.kit_quebrado&&this.kitEstoqueReal>0:this.produto.controlar_estoque!=="1"?!0:(parseInt((_a=this.produto.estoque)==null?void 0:_a[0])||parseInt(this.produto.total_estoque)||0)>0},multiplicador(){var _a,_b;return parseInt((_b=(_a=this.produto.multiplicador)==null?void 0:_a.padrao)==null?void 0:_b[0])||1},estoqueAtual(){var _a;return this.isKit?this.kitEstoqueReal:parseInt((_a=this.produto.estoque)==null?void 0:_a[0])||parseInt(this.produto.total_estoque)||0},max2(){return this.isKit?this.kitEstoqueReal:this.produto.controlar_estoque=="1"?this.estoqueAtual:0},isKit(){return KitProdutoHelper.isKit(this.produto)},kitSelecoesProduto(){return KitProdutoHelper.selecoes(this.conteudoStore,this.produto)},kitSelecoesAssinatura(){return JSON.stringify(this.kitSelecoesProduto)},kitCompleto(){return KitProdutoHelper.completo(this.produto,this.kitSelecoesProduto)},kitEstoqueReal(){return KitProdutoHelper.estoque(this.produto,this.kitSelecoesProduto)},temDesconto(){var _a,_b;if(!this.exibirDescontos)return!1;if(!this.isEmpty(this.produto.regras_desconto))return!0;if(!this.isEmpty((_b=(_a=this.produto.precos_produto)==null?void 0:_a.regras_precos)==null?void 0:_b[0])){const regrasPrecos=this.produto.precos_produto.regras_precos[0],dataAtual=Date.now()/1e3;for(const regra of Object.values(regrasPrecos)){let regraAtiva=!0;if(regra.data_inicio){const inicio=new Date(regra.data_inicio.split("/").reverse().join("-")).getTime()/1e3;dataAtual<inicio&&(regraAtiva=!1)}if(regra.data_termino){const termino=new Date(regra.data_termino.split("/").reverse().join("-")).getTime()/1e3+86399;dataAtual>termino&&(regraAtiva=!1)}if(regraAtiva)return!0}}return!1},mostrarSku(){return this.exibirSku&&this.configsLoja.mostrarCodigoReferenciaProduto&&(this.isEmpty(this.produto.disponibilidade)||!this.configsLoja.exibirSkuVariacoes)&&this.produto.sku}},mounted(){var _a;this.hidratarKitSelecoesStore();const qtdCarrinho=parseInt((_a=this.carrinho[this.produto.id])==null?void 0:_a[0])||0;this.quantidade=qtdCarrinho,this.$nextTick(()=>{this.inicializandoQuantidade=!1}),AudioManager.init(this.configsLoja)},watch:{carrinho:{handler(newVal){var _a;const qtdCarrinho=parseInt((_a=newVal[this.produto.id])==null?void 0:_a[0])||0;this.quantidade!==qtdCarrinho&&(this.quantidade=qtdCarrinho)},deep:!0},quantidade(newVal,oldVal){if(this.inicializandoQuantidade){this.conteudoStore.quantidadesSelecionadas[this.produto.id]={0:newVal};return}if(this.isKit&&!this.kitCompleto&&Number(newVal)>0){showNotification("Selecione as variações do kit para continuar.","","warning"),this.quantidade=0;return}this.conteudoStore.quantidadesSelecionadas[this.produto.id]={0:newVal};const resultado=CarrinhoManager.validarQuantidade(newVal,this.qtdMinima,this.qtdMaxima,this.max2,this.multiplicador);if(resultado.valor!==newVal){this.quantidade=resultado.valor,resultado.atingiuMaximo&&CarrinhoManager.notificarMaximo(resultado.maxDefinido),resultado.produtoIndisponivel&&CarrinhoManager.notificarProdutoIndisponivel();return}newVal!==oldVal&&oldVal!==void 0&&CarrinhoManager.atualizarQuantidade(this.produto.id,0,newVal,this.produto.nome,this.produto.preco,this.configsLoja,this.isKit?this.kitSelecoesProduto:null)},kitSelecoesAssinatura(newVal,oldVal){!this.isKit||!this.kitCompleto||Number(this.quantidade)<=0||oldVal===void 0||CarrinhoManager.atualizarQuantidade(this.produto.id,0,this.quantidade,this.produto.nome,this.produto.preco,this.configsLoja,this.kitSelecoesProduto)}},methods:{abrirModalRegrasPrecos(){this.abrirDialogRegrasPrecos(this.produto,0)},exibirNotificacaoEstoque(){typeof showNotification=="function"&&showNotification("Quantidade disponível em estoque","","info")}},template:`
    <div class="fz-produto-conteudo__variacao-simples">
        <div v-if="!produtoDisponivel" class="fz-produto-conteudo__alerta fz-produto-conteudo__alerta--aviso alert alert-warning">
            <i class="ti-alert"></i> Produto indisponível no momento
        </div>
        <div v-else class="fz-produto-conteudo__variacao-simples-controle bloco-mensagem bloco-variacao w-100" style="box-shadow:0 0 0;border-top:1px solid #eee;margin-bottom: 0;">
            <div class="container-fluid pl-1">
                <div class="row align-items-center">
                    <label class="fz-produto-conteudo__quantidade-label col mb-0 text-center text-sm-left" style="font-weight: 500;">
                        <span class="fz-produto-conteudo__variacao-nome variacao_nome">Quantidade</span>

                        <!-- Badge de Estoque -->
                        <p-tag
                            v-if="!modeloCondensado && configsLoja.mostrarQuantidadeEstoque && produto.controlar_estoque == '1'"
                            @click="exibirNotificacaoEstoque"
                            :value="estoqueAtual"
                            severity="secondary"
                            icon="pi pi-box"
                            class="fz-produto-conteudo__variacao-estoque-tag ml-1"
                            style="font-size: 12px; cursor: help;"
                        ></p-tag>

                        <!-- Ícone de Desconto -->
                        <span
                            v-if="temDesconto"
                            class="fz-produto-conteudo__variacao-desconto fa-stack ml-1"
                            style="cursor:pointer;font-size: 14px;"
                            @click="abrirModalRegrasPrecos">
                            <i class="fa fa-tag fa-stack-2x text-success"></i>
                            <i class="fa fa-percent fa-stack-1x fa-inverse" style="font-size: 0.8em;"></i>
                        </span>

                        <!-- SKU do Produto -->
                        <div v-if="mostrarSku">
                            <p-tag
                                :value="produto.sku"
                                severity="secondary"
                                icon="pi pi-hashtag"
                                class="fz-produto-conteudo__quantidade-sku-tag"
                                style="font-size: 0.75rem;"
                            ></p-tag>
                        </div>
                    </label>

                    <div
                        class="fz-produto-conteudo__quantidade-input input-group col mx-auto mt-0 mt-sm-0 mb-0"
                        :class="{ 'fz-produto-conteudo__seletor-quantidade--condensado': modeloCondensado }"
                        style="max-width: 140px;padding: 0;">
                        <fz-variacao-quantidade
                            v-model="quantidade"
                            :min="qtdMinima"
                            :max="qtdMaxima"
                            :step="multiplicador"
                            :modelo-condensado="modeloCondensado"
                            class="w-100"
                        ></fz-variacao-quantidade>
                    </div>
                </div>
            </div>
        </div>
    </div>
    `},FZComponents.VariacaoComVariacao={components:{"p-divider":PrimeVue.Divider,"p-button":PrimeVue.Button,"p-tag":PrimeVue.Tag,"p-image":PrimeVue.Image,"fz-variacao-quantidade":FZComponents.VariacaoQuantidade},mixins:[ProdutoConteudoMixin],props:{produto:{type:Object,required:!0},catalogoId:{type:[String,Number],required:!0},carrinho:{type:Object,default:()=>({})},somenteOrcamentos:{type:Boolean,default:!1},precosRestritos:{type:Boolean,default:!1},exibirPreco:{type:Boolean,default:!0},exibirSku:{type:Boolean,default:!0},exibirDivisoria:{type:Boolean,default:!0},exibirDescontos:{type:Boolean,default:!0},videoAtivo:{type:Boolean,default:!1},variacoesDestaque:{type:Array,default:()=>[]},modeloCondensado:{type:Boolean,default:!1},usarSubgruposComoLista:{type:Boolean,default:!1}},data(){return{quantidades:{}}},computed:{variacoesDisponiveis(){var _a,_b,_c,_d,_e,_f,_g,_h;const variacoes=[];let variacoesArray=[];if(this.produto.variacoes&&Object.keys(this.produto.variacoes).length>0)variacoesArray=Array.isArray(this.produto.variacoes)?this.produto.variacoes:Object.values(this.produto.variacoes);else if(this.usarSubgruposComoLista&&this.produto.subgrupos_variacoes)for(const variacoesSubgrupo of Object.values(this.produto.subgrupos_variacoes))variacoesArray.push(...Array.isArray(variacoesSubgrupo)?variacoesSubgrupo:Object.values(variacoesSubgrupo||{}));if(variacoesArray.length===0)return variacoes;for(const variacao of variacoesArray){if(((_a=this.produto.disponibilidade)==null?void 0:_a[variacao.id])!="1"){console.info(`Variação ID ${variacao.id} do produto ID ${this.produto.id} está marcada como indisponível e será ignorada na exibição.`);continue}const estoque=parseInt((_b=this.produto.estoque)==null?void 0:_b[variacao.id])||0,qtdMinima=this.obterQtdMinimaVariacao(variacao.id);if(this.produto.controlar_estoque=="1"&&(estoque<=0||estoque<qtdMinima)){console.info(`Variação ID ${variacao.id} do produto ID ${this.produto.id} está sem estoque suficiente e será ignorada na exibição.`,{estoqueDisponivel:estoque,qtdMinima});continue}const qtdMaxima=this.obterQtdMaximaVariacao({...variacao,estoque});variacoes.push({...variacao,estoque,qtdMinima,qtdMaxima,multiplicador:parseInt((_d=(_c=this.produto.multiplicador)==null?void 0:_c.padrao)==null?void 0:_d[0])||1,precoVariacao:this.obterPrecoVariacao(variacao.id),temDesconto:this.verificarDescontoVariacao(variacao.id),sku:((_e=this.produto.sku_variacoes)==null?void 0:_e[variacao.id])||"",imagem:((_f=this.produto.imagens_variacoes)==null?void 0:_f[variacao.id])||null,imagemConfig:((_g=this.produto.imagens_variacoes_configs)==null?void 0:_g[variacao.id])||{},posicaoImagem:((_h=this.produto.posicao_imagem_variacao)==null?void 0:_h[variacao.id])||0})}return variacoes.sort((a,b)=>{const ordemA=parseInt(a.ordem)||0,ordemB=parseInt(b.ordem)||0;if(ordemA!==ordemB)return ordemA-ordemB;const nomeA=(a.nome_tratado||a.nome||"").toString(),nomeB=(b.nome_tratado||b.nome||"").toString();return nomeA.localeCompare(nomeB,"pt-BR",{sensitivity:"base"})}),variacoes},temDescontoGeral(){return this.exibirDescontos&&!this.isEmpty(this.produto.regras_desconto)},exibirPrecos(){var _a;return((_a=this.produto.precos_produto)==null?void 0:_a.precos_variacoes)!==!1&&!this.somenteOrcamentos&&!this.precosRestritos&&this.exibirPreco}},mounted(){var _a;for(const variacao of this.variacoesDisponiveis)this.quantidades[variacao.id]=parseInt((_a=this.carrinho[this.produto.id])==null?void 0:_a[variacao.id])||0;AudioManager.init(this.configsLoja),this.$nextTick(()=>{for(const variacao of this.variacoesDisponiveis)this.$watch(()=>this.quantidades[variacao.id],(newVal,oldVal)=>{if(newVal===oldVal||oldVal===void 0)return;this.conteudoStore.quantidadesSelecionadas[this.produto.id]={...this.quantidades};const max2=this.produto.controlar_estoque=="1"?variacao.estoque:0,resultado=CarrinhoManager.validarQuantidade(newVal,variacao.qtdMinima,this.obterQtdMaximaVariacao(variacao),max2,variacao.multiplicador,this.isRegraQuantidadeGeral()&&this.obterQtdMaximaProduto()>0);if(resultado.valor!==newVal){this.quantidades[variacao.id]=resultado.valor,resultado.atingiuMaximo&&CarrinhoManager.notificarMaximo(resultado.maxDefinido),resultado.produtoIndisponivel&&CarrinhoManager.notificarProdutoIndisponivel();return}CarrinhoManager.atualizarQuantidade(this.produto.id,variacao.id,newVal,this.produto.nome,this.produto.preco,this.configsLoja)})})},watch:{carrinho:{handler(newVal){var _a;for(const variacao of this.variacoesDisponiveis){const qtdCarrinho=parseInt((_a=newVal[this.produto.id])==null?void 0:_a[variacao.id])||0;this.quantidades[variacao.id]!==qtdCarrinho&&(this.quantidades[variacao.id]=qtdCarrinho)}},deep:!0},quantidades:{handler(newVal){this.conteudoStore.quantidadesSelecionadas[this.produto.id]={...newVal}},deep:!0}},methods:{obterPrecoVariacao(variacaoId){var _a,_b;return((_b=(_a=this.produto.precos_produto)==null?void 0:_a.variacoes)==null?void 0:_b[variacaoId])||this.produto.precos_produto||{}},verificarDescontoVariacao(variacaoId){var _a,_b;if(!this.exibirDescontos)return!1;const regrasPrecos=(_b=(_a=this.produto.precos_produto)==null?void 0:_a.regras_precos)==null?void 0:_b[variacaoId];if(!regrasPrecos)return!1;const dataAtual=Date.now()/1e3;for(const regra of Object.values(regrasPrecos)){let regraAtiva=!0;if(regra.data_inicio){const inicio=new Date(regra.data_inicio.split("/").reverse().join("-")).getTime()/1e3;dataAtual<inicio&&(regraAtiva=!1)}if(regra.data_termino){const termino=new Date(regra.data_termino.split("/").reverse().join("-")).getTime()/1e3+86399;dataAtual>termino&&(regraAtiva=!1)}if(regraAtiva)return!0}return!1},irParaImagem(posicao){!posicao||posicao<1||ProdutoConteudoMixin.methods.irParaImagem.call(this,posicao-1,this.produto.id,this.videoAtivo?1:0)},abrirModalRegrasPrecos(variacaoId){this.abrirDialogRegrasPrecos(this.produto,variacaoId)},exibirNotificacaoEstoque(estoque){showNotification("Quantidade disponível em estoque",`Existem ${estoque} unidades disponíveis.`,"info")},variacaoDestacada(variacaoId){return this.variacoesDestaque.map(String).includes(String(variacaoId))}},template:`
    <div class="fz-produto-conteudo__variacoes">
        <p-divider v-if="exibirDivisoria" align="left" type="solid" class="fz-produto-conteudo__divisoria">
            <b>Escolha as Variações</b>
        </p-divider>

        <div v-for="variacao in variacoesDisponiveis" :key="variacao.id" class="fz-produto-conteudo__variacao" :class="{ 'fz-produto-conteudo__variacao--destacada': variacaoDestacada(variacao.id) }" :data-variacao-id="variacao.id">
            <div class="fz-produto-conteudo__variacao-bloco bloco-mensagem bloco-variacao w-100" style="box-shadow:0 0 0;border-top:1px solid #eee;margin-bottom: 0;">
                <div class="container-fluid px-1"><div class="row align-items-center">
                    <div :class="exibirPrecos ? 'col mb-0 text-left' : 'col mb-0 text-left'" :style="exibirPrecos ? '' : 'font-weight: 500;'">
                        <p-image
                            v-if="variacao.imagem"
                            :id="'img-variacao-'+produto.id+'-'+variacao.id"
                            :src="obterURLArquivos(variacao.imagem)"
                            preview
                            image-class="fz-produto-conteudo__variacao-imagem img-30 align-middle mr-1 img-variacoes"
                            :image-style="{ cursor: 'pointer' }"
                            @error="handleImageError"
                            @click="irParaImagem(variacao.posicaoImagem)"
                            :pt="{ root: { style: 'display: inline-block; vertical-align: middle; margin-right: 0.25rem;' } }"
                        >
                            <template #previewicon>
                                <span></span>
                            </template>
                        </p-image>
                        <div class="fz-produto-conteudo__variacao-info d-inline-block align-middle">
                            <span :style="exibirPrecos ? 'font-weight: 500;' : ''">
                                <i v-if="variacao.cor" class="fz-produto-conteudo__variacao-cor mr-1" :style="'color:'+variacao.cor+';background: '+variacao.cor+';'"></i>
                                <span class="fz-produto-conteudo__variacao-nome variacao_nome">{{ variacao.nome_tratado || variacao.nome }}</span>
                                <span v-if="temDescontoGeral" class="fz-produto-conteudo__variacao-desconto fa-stack ml-1" style="cursor:pointer;font-size: 14px;" @click="abrirModalRegrasPrecos(0)"><i class="fa fa-tag fa-stack-2x text-success"></i><i class="fa fa-percent fa-stack-1x fa-inverse" style="font-size: 0.8em;"></i></span>
                                <span v-else-if="variacao.temDesconto" class="fz-produto-conteudo__variacao-desconto fa-stack ml-1" style="cursor:pointer;font-size: 14px;" @click="abrirModalRegrasPrecos(variacao.id)"><i class="fa fa-tag fa-stack-2x text-success"></i><i class="fa fa-percent fa-stack-1x fa-inverse" style="font-size: 0.8em;"></i></span>

                                <p-tag
                                    v-if="!modeloCondensado && configsLoja.mostrarQuantidadeEstoque && produto.controlar_estoque == '1'"
                                    @click="exibirNotificacaoEstoque(variacao.estoque)"
                                    :value="variacao.estoque"
                                    severity="secondary"
                                    icon="pi pi-box"
                                    class="fz-produto-conteudo__variacao-estoque-tag ml-1"
                                ></p-tag>
                            </span>
                            <template v-if="exibirPrecos"><br/>
                                <span class="fz-produto-conteudo__variacao-preco">
                                    <template v-if="variacao.precoVariacao.promocional !== false && variacao.precoVariacao.promocional !== null">De: <del>R$ {{ formatarPreco(variacao.precoVariacao.padrao) }}</del><br/>Por: R$ {{ formatarPreco(variacao.precoVariacao.promocional) }}</template>
                                    <template v-else>R$ {{ formatarPreco(variacao.precoVariacao.padrao) }}</template>
                                </span>
                            </template>
                            <div v-if="exibirSku && configsLoja.mostrarCodigoReferenciaProduto && configsLoja.exibirSkuVariacoes && variacao.sku" class="mt-1">
                                <p-tag
                                    :value="variacao.sku"
                                    severity="secondary"
                                    icon="pi pi-hashtag"
                                    class="fz-produto-conteudo__variacao-sku-tag"
                                    style="font-size: 0.75rem;"
                                ></p-tag>
                            </div>
                        </div>
                    </div>
                    <div
                        class="fz-produto-conteudo__variacao-quantidade input-group col mx-auto mt-0 mt-sm-0 mb-0"
                        :class="{ 'fz-produto-conteudo__seletor-quantidade--condensado': modeloCondensado }"
                        style="max-width: 140px;padding: 0;">
                        <fz-variacao-quantidade v-model="quantidades[variacao.id]" :min="variacao.qtdMinima" :max="obterQtdMaximaVariacao(variacao)" :step="variacao.multiplicador" :modelo-condensado="modeloCondensado" class="w-100"></fz-variacao-quantidade>
                    </div>
                </div></div>
            </div>
        </div>
    </div>`},FZComponents.VariacaoComSubgruposVariacao={components:{"p-divider":PrimeVue.Divider,"p-tabs":PrimeVue.Tabs,"p-tablist":PrimeVue.TabList,"p-tab":PrimeVue.Tab,"p-tabpanels":PrimeVue.TabPanels,"p-tabpanel":PrimeVue.TabPanel,"p-button":PrimeVue.Button,"p-tag":PrimeVue.Tag,"p-image":PrimeVue.Image,"fz-variacao-quantidade":FZComponents.VariacaoQuantidade},mixins:[ProdutoConteudoMixin],props:{produto:{type:Object,required:!0},catalogoId:{type:[String,Number],required:!0},carrinho:{type:Object,default:()=>({})},somenteOrcamentos:{type:Boolean,default:!1},precosRestritos:{type:Boolean,default:!1},exibirPreco:{type:Boolean,default:!0},exibirSku:{type:Boolean,default:!0},exibirDivisoria:{type:Boolean,default:!0},exibirDescontos:{type:Boolean,default:!0},videoAtivo:{type:Boolean,default:!1},variacoesIsoladas:{type:Boolean,default:!0},tabAtiva:{type:[String,Number],default:null},variacoesDestaque:{type:Array,default:()=>[]},rolarAbaAtiva:{type:Boolean,default:!0},modeloCondensado:{type:Boolean,default:!1},usarSubgruposComoLista:{type:Boolean,default:!1}},data(){return{quantidades:{},activeTab:"0"}},computed:{subgruposDisponiveis(){var _a;const subgrupos=[];if(!this.produto.subgrupos_variacoes)return subgrupos;let subgrupoId=1;for(const[nomeSubgrupo,variacoes]of Object.entries(this.produto.subgrupos_variacoes))variacoes.some(v=>{var _a2,_b;if(((_a2=this.produto.disponibilidade)==null?void 0:_a2[v.id])!="1")return!1;const estoque=parseInt((_b=this.produto.estoque)==null?void 0:_b[v.id])||0,qtdMinima=this.obterQtdMinimaVariacao(v.id);return!(this.produto.controlar_estoque=="1"&&(estoque<=0||estoque<qtdMinima))})&&subgrupos.push({id:subgrupoId,nome:nomeSubgrupo,cor:((_a=this.produto.subgrupos_variacoes_cores)==null?void 0:_a[nomeSubgrupo])||null,variacoes:this.obterVariacoesSubgrupo(variacoes)}),subgrupoId++;return subgrupos},temDescontoGeral(){return this.exibirDescontos&&!this.isEmpty(this.produto.regras_desconto)},exibirPrecos(){var _a;return((_a=this.produto.precos_produto)==null?void 0:_a.precos_variacoes)!==!1&&!this.somenteOrcamentos&&!this.precosRestritos&&this.exibirPreco},estiloBloco(){return this.produto.total_disponibilidade>this.configsLoja.maxVariacoesMostrar||this.variacoesIsoladas===!1?"box-shadow:0 0 0;padding:0;margin-bottom: 0;":""}},mounted(){var _a;for(const subgrupo of this.subgruposDisponiveis)for(const variacao of subgrupo.variacoes)this.quantidades[variacao.id]=parseInt((_a=this.carrinho[this.produto.id])==null?void 0:_a[variacao.id])||0;AudioManager.init(this.configsLoja),this.$nextTick(()=>{for(const subgrupo of this.subgruposDisponiveis)for(const variacao of subgrupo.variacoes){const variacaoCapturada=variacao;this.$watch(()=>this.quantidades[variacaoCapturada.id],(newVal,oldVal)=>{if(newVal===oldVal||oldVal===void 0)return;this.conteudoStore.quantidadesSelecionadas[this.produto.id]={...this.quantidades};const max2=this.produto.controlar_estoque=="1"?variacaoCapturada.estoque:0,resultado=CarrinhoManager.validarQuantidade(newVal,variacaoCapturada.qtdMinima,this.obterQtdMaximaVariacao(variacaoCapturada),max2,variacaoCapturada.multiplicador,this.isRegraQuantidadeGeral()&&this.obterQtdMaximaProduto()>0);if(resultado.valor!==newVal){this.quantidades[variacaoCapturada.id]=resultado.valor,resultado.atingiuMaximo&&CarrinhoManager.notificarMaximo(resultado.maxDefinido),resultado.produtoIndisponivel&&CarrinhoManager.notificarProdutoIndisponivel();return}CarrinhoManager.atualizarQuantidade(this.produto.id,variacaoCapturada.id,newVal,this.produto.nome,this.produto.preco,this.configsLoja)})}})},beforeUnmount(){},watch:{carrinho:{handler(newVal){var _a;for(const subgrupo of this.subgruposDisponiveis)for(const variacao of subgrupo.variacoes){const qtdCarrinho=parseInt((_a=newVal[this.produto.id])==null?void 0:_a[variacao.id])||0;this.quantidades[variacao.id]!==qtdCarrinho&&(this.quantidades[variacao.id]=qtdCarrinho)}},deep:!0},quantidades:{handler(newVal){this.conteudoStore.quantidadesSelecionadas[this.produto.id]={...newVal}},deep:!0},tabAtiva(newVal){newVal!=null&&(this.activeTab=String(newVal),this.rolarAbaAtiva&&this.$nextTick(()=>this.scrollAbaAtivaParaVisivel()))}},methods:{scrollAbaAtivaParaVisivel(){const root=this.$el;if(!root)return;const ativa=root.querySelector('.fz-produto-conteudo__subgrupos-tabs [data-p-active="true"]');ativa&&typeof ativa.scrollIntoView=="function"&&ativa.scrollIntoView({behavior:"smooth",inline:"center",block:"nearest"})},obterVariacoesSubgrupo(variacoes){var _a,_b,_c,_d,_e,_f,_g,_h;const resultado=[];for(const variacao of variacoes){if(((_a=this.produto.disponibilidade)==null?void 0:_a[variacao.id])!="1")continue;const estoque=parseInt((_b=this.produto.estoque)==null?void 0:_b[variacao.id])||0,qtdMinima=this.obterQtdMinimaVariacao(variacao.id);if(this.produto.controlar_estoque=="1"&&(estoque<=0||estoque<qtdMinima))continue;const qtdMaxima=this.obterQtdMaximaVariacao({...variacao,estoque});resultado.push({...variacao,estoque,qtdMinima,qtdMaxima,multiplicador:parseInt((_d=(_c=this.produto.multiplicador)==null?void 0:_c.padrao)==null?void 0:_d[0])||1,precoVariacao:this.obterPrecoVariacao(variacao.id),temDesconto:this.verificarDescontoVariacao(variacao.id),sku:((_e=this.produto.sku_variacoes)==null?void 0:_e[variacao.id])||"",imagem:((_f=this.produto.imagens_variacoes)==null?void 0:_f[variacao.id])||null,imagemConfig:((_g=this.produto.imagens_variacoes_configs)==null?void 0:_g[variacao.id])||{},posicaoImagem:((_h=this.produto.posicao_imagem_variacao)==null?void 0:_h[variacao.id])||0})}return resultado.sort((a,b)=>{const ordemA=parseInt(a.ordem)||0,ordemB=parseInt(b.ordem)||0;if(ordemA!==ordemB)return ordemA-ordemB;const nomeA=(a.nome_tratado||a.nome||"").toString(),nomeB=(b.nome_tratado||b.nome||"").toString();return nomeA.localeCompare(nomeB,"pt-BR",{sensitivity:"base"})}),resultado},obterPrecoVariacao(variacaoId){var _a,_b;return((_b=(_a=this.produto.precos_produto)==null?void 0:_a.variacoes)==null?void 0:_b[variacaoId])||this.produto.precos_produto||{}},verificarDescontoVariacao(variacaoId){var _a,_b;if(!this.exibirDescontos)return!1;const regrasPrecos=(_b=(_a=this.produto.precos_produto)==null?void 0:_a.regras_precos)==null?void 0:_b[variacaoId];if(!regrasPrecos)return!1;const dataAtual=Date.now()/1e3,regrasArray=Array.isArray(regrasPrecos)?regrasPrecos:Object.values(regrasPrecos);for(const regra of regrasArray){let regraAtiva=!0;if(regra.data_inicio){const inicio=new Date(regra.data_inicio.split("/").reverse().join("-")+" 00:00:00").getTime()/1e3;dataAtual<inicio&&(regraAtiva=!1)}if(regra.data_termino){const termino=new Date(regra.data_termino.split("/").reverse().join("-")+" 23:59:59").getTime()/1e3;dataAtual>termino&&(regraAtiva=!1)}if(regraAtiva)return!0}return!1},irParaImagem(posicao){!posicao||posicao<1||ProdutoConteudoMixin.methods.irParaImagem.call(this,posicao-1,this.produto.id,this.videoAtivo?1:0)},abrirModalRegrasPrecos(variacaoId){this.abrirDialogRegrasPrecos(this.produto,variacaoId||0)},exibirNotificacaoEstoque(estoque){showNotification("Quantidade disponível em estoque",`Existem ${estoque} unidades disponíveis.`,"info")},variacaoDestacada(variacaoId){return this.variacoesDestaque.map(String).includes(String(variacaoId))}},template:`
    <div class="fz-produto-conteudo__subgrupos">
        <p-divider v-if="exibirDivisoria" align="left" type="solid" class="fz-produto-conteudo__divisoria">
            <b>Escolha as Variações</b>
        </p-divider>

        <p-tabs v-model:value="activeTab" scrollable class="fz-produto-conteudo__subgrupos-tabs">
            <p-tablist>
                <p-tab v-for="(subgrupo, index) in subgruposDisponiveis" :key="subgrupo.id" :value="String(index)">
                    <i v-if="subgrupo.cor" class="fz-produto-conteudo__subgrupo-cor mr-1" :style="'color:'+subgrupo.cor+';background: '+subgrupo.cor+';'"></i>
                    <span class="fz-produto-conteudo__subgrupo-nome">{{ subgrupo.nome }}</span>
                </p-tab>
            </p-tablist>
            <p-tabpanels>
                <p-tabpanel v-for="(subgrupo, index) in subgruposDisponiveis" :key="subgrupo.id" :value="String(index)">
                    <div class="fz-produto-conteudo__subgrupo-variacoes">
                        <div v-for="variacao in subgrupo.variacoes" :key="variacao.id" class="fz-produto-conteudo__variacao row" :class="{ 'fz-produto-conteudo__variacao--destacada': variacaoDestacada(variacao.id) }" :data-variacao-id="variacao.id">
                            <div class="fz-produto-conteudo__variacao-bloco bloco-mensagem bloco-variacao w-100" :style="(produto.total_disponibilidade > configsLoja.maxVariacoesMostrar || variacoesIsoladas === false)?'box-shadow:0 0 0;border-top:1px solid #eee;margin-bottom: 0;':''">
                                <div class="container-fluid px-1"><div class="row align-items-center">
                                    <div class="col mb-0 text-left" :class="exibirPrecos ? '' : 'font-weight-500'">
                                        <p-image
                                            v-if="variacao.imagem"
                                            :id="'img-variacao-'+produto.id+'-'+variacao.id"
                                            :src="obterURLArquivos(variacao.imagem)"
                                            preview
                                            image-class="fz-produto-conteudo__variacao-imagem img-30 align-middle mr-1 img-variacoes"
                                            :image-style="{ cursor: 'pointer' }"
                                            @error="handleImageError"
                                            @click="irParaImagem(variacao.posicaoImagem)"
                                            :pt="{ root: { style: 'display: inline-block; vertical-align: middle; margin-right: 0.25rem;' } }"
                                        >
                                            <template #previewicon><span></span></template>
                                        </p-image>
                                        <div class="fz-produto-conteudo__variacao-info d-inline-block align-middle">
                                            <span :class="exibirPrecos ? 'font-weight-500' : ''">
                                                <i v-if="variacao.cor" class="fz-produto-conteudo__variacao-cor mr-1" :style="'color:'+variacao.cor+';background: '+variacao.cor+';'"></i>
                                                <span class="fz-produto-conteudo__variacao-nome variacao_nome">{{ variacao.nome_tratado || variacao.nome }}</span>
                                                <span v-if="temDescontoGeral" class="fz-produto-conteudo__variacao-desconto fa-stack ml-1" style="cursor:pointer;font-size: 14px;" @click="abrirModalRegrasPrecos(0)"><i class="fa fa-tag fa-stack-2x text-success"></i><i class="fa fa-percent fa-stack-1x fa-inverse" style="font-size: 0.8em;"></i></span>
                                                <span v-else-if="variacao.temDesconto" class="fz-produto-conteudo__variacao-desconto fa-stack ml-1" style="cursor:pointer;font-size: 14px;" @click="abrirModalRegrasPrecos(variacao.id)"><i class="fa fa-tag fa-stack-2x text-success"></i><i class="fa fa-percent fa-stack-1x fa-inverse" style="font-size: 0.8em;"></i></span>

                                                <p-tag
                                                    v-if="!modeloCondensado && configsLoja.mostrarQuantidadeEstoque && produto.controlar_estoque == '1'"
                                                    @click="exibirNotificacaoEstoque(variacao.estoque)"
                                                    :value="variacao.estoque"
                                                    severity="secondary"
                                                    icon="pi pi-box"
                                                    class="fz-produto-conteudo__variacao-estoque-tag ml-1"
                                                ></p-tag>
                                            </span>
                                            <template v-if="exibirPrecos"><br/>
                                                <span class="fz-produto-conteudo__variacao-preco">
                                                    <template v-if="variacao.precoVariacao.promocional !== false && variacao.precoVariacao.promocional !== null">De: <del>R$ {{ formatarPreco(variacao.precoVariacao.padrao) }}</del><br/>Por: R$ {{ formatarPreco(variacao.precoVariacao.promocional) }}</template>
                                                    <template v-else>R$ {{ formatarPreco(variacao.precoVariacao.padrao) }}</template>
                                                </span>
                                            </template>
                                            <div v-if="exibirSku && configsLoja.mostrarCodigoReferenciaProduto && configsLoja.exibirSkuVariacoes && variacao.sku" class="mt-1">
                                                <p-tag
                                                    :value="variacao.sku"
                                                    severity="secondary"
                                                    icon="pi pi-hashtag"
                                                    class="fz-produto-conteudo__variacao-sku-tag"
                                                    style="font-size: 0.75rem;"
                                                ></p-tag>
                                            </div>
                                        </div>
                                    </div>
                                    <div
                                        class="fz-produto-conteudo__variacao-quantidade input-group col mx-auto mt-0 mt-sm-0 mb-0"
                                        :class="{ 'fz-produto-conteudo__seletor-quantidade--condensado': modeloCondensado }"
                                        style="max-width: 140px;padding: 0;">
                                        <fz-variacao-quantidade v-model="quantidades[variacao.id]" :min="variacao.qtdMinima" :max="obterQtdMaximaVariacao(variacao)" :step="variacao.multiplicador" :modelo-condensado="modeloCondensado" class="w-100"></fz-variacao-quantidade>
                                    </div>
                                </div></div>
                            </div>
                        </div>
                    </div>
                </p-tabpanel>
            </p-tabpanels>
        </p-tabs>
    </div>`},FZComponents.VariacaoComGrade={components:{"p-divider":PrimeVue.Divider,"p-button":PrimeVue.Button,"p-tag":PrimeVue.Tag,"p-inputnumber":PrimeVue.InputNumber,"p-image":PrimeVue.Image,"fz-variacao-quantidade":FZComponents.VariacaoQuantidade},mixins:[ProdutoConteudoMixin],props:{produto:{type:Object,required:!0},catalogoId:{type:[String,Number],required:!0},carrinho:{type:Object,default:()=>({})},exibirSku:{type:Boolean,default:!0},exibirDescontos:{type:Boolean,default:!0},videoAtivo:{type:Boolean,default:!1},variacoesIsoladas:{type:Boolean,default:!0},modeloCondensado:{type:Boolean,default:!1},usarSubgruposComoLista:{type:Boolean,default:!1}},data(){return{quantidadeGrade:0}},computed:{composicaoGrade(){var _a,_b,_c,_d;const composicao=[];if(!this.produto.variacoes)return composicao;const variacoesArray=Array.isArray(this.produto.variacoes)?this.produto.variacoes:Object.values(this.produto.variacoes);for(const variacao of variacoesArray){const qtdGrade=parseInt((_a=this.produto.grade)==null?void 0:_a[variacao.id])||0;qtdGrade>0&&((_b=this.produto.disponibilidade)==null?void 0:_b[variacao.id])=="1"&&composicao.push({...variacao,qtdGrade,imagem:((_c=this.produto.imagens_variacoes)==null?void 0:_c[variacao.id])||null,posicaoImagem:((_d=this.produto.posicao_imagem_variacao)==null?void 0:_d[variacao.id])||0})}return composicao.sort((a,b)=>{const ordemA=parseInt(a.ordem)||0,ordemB=parseInt(b.ordem)||0;return ordemA-ordemB}),composicao},maxGrade(){var _a;return this.produto.controlar_estoque=="1"?parseInt((_a=this.produto.estoque)==null?void 0:_a.grade)||0:999999},temDesconto(){return this.exibirDescontos&&!this.isEmpty(this.produto.regras_desconto)},estiloBloco(){return this.variacoesIsoladas?"":"box-shadow:0 0 0;border-top:1px solid #eee;margin-bottom: 0;"}},mounted(){var _a;this.quantidadeGrade=parseInt((_a=this.carrinho[this.produto.id])==null?void 0:_a.grade)||0,AudioManager.init(this.configsLoja)},watch:{quantidadeGrade(newVal,oldVal){if(this.conteudoStore.quantidadesSelecionadas[this.produto.id]={grade:newVal},oldVal===void 0)return;const resultado=CarrinhoManager.validarQuantidade(newVal,0,this.maxGrade,0,1);if(resultado.valor!==newVal){this.quantidadeGrade=resultado.valor,resultado.atingiuMaximo&&CarrinhoManager.notificarMaximo(resultado.maxDefinido),resultado.produtoIndisponivel&&CarrinhoManager.notificarProdutoIndisponivel();return}CarrinhoManager.atualizarQuantidade(this.produto.id,"grade",newVal,this.produto.nome,this.produto.preco,this.configsLoja)}},methods:{irParaImagem(posicao){!posicao||posicao<1||ProdutoConteudoMixin.methods.irParaImagem.call(this,posicao-1,this.produto.id,this.videoAtivo?1:0)},abrirModalRegrasPrecos(){this.abrirDialogRegrasPrecos(this.produto,0)},mostrarInfoGrade(){typeof showNotification=="function"&&showNotification("Venda em Grade","Para você comprar este produto, você precisa comprar a grade completa composta por uma quantidade fixa de cada variação do produto.","info")}},template:`
    <div class="fz-produto-conteudo__grade">
        <div class="fz-produto-conteudo__grade-controle  bloco-variacao w-100" :style="estiloBloco"><div class="container-fluid pl-1"><div class="row align-items-center">
            <label class="fz-produto-conteudo__grade-label col mb-0 text-center text-sm-left" style="font-weight: 500;">
                <span class="fz-produto-conteudo__grade-titulo" style="cursor: help;" @click="mostrarInfoGrade">
                    <i class="fz-produto-conteudo__grade-icone ti-layout-grid2 mr-1 align-middle"></i>
                    <span class="fz-produto-conteudo__grade-nome variacao_nome">Grade</span>
                    <i class="fa fa-question-circle text-info mr-1 p-1" style="font-size: 18px;"></i>
                </span>
                <span v-if="temDesconto" class="fz-produto-conteudo__grade-desconto fa-stack ml-1" style="cursor:pointer;font-size: 14px;" @click="abrirModalRegrasPrecos"><i class="fa fa-tag fa-stack-2x text-success"></i><i class="fa fa-percent fa-stack-1x fa-inverse" style="font-size: 0.8em;"></i></span>
                <div v-if="exibirSku && produto.sku" class="mt-1">
                    <p-tag
                        :value="produto.sku"
                        severity="secondary"
                        icon="pi pi-hashtag"
                        class="fz-produto-conteudo__grade-sku-tag"
                        style="font-size: 0.75rem;"
                    ></p-tag>
                </div>
            </label>
            <div
                class="fz-produto-conteudo__grade-quantidade input-group col mx-auto mt-0 mt-sm-0 mb-0"
                :class="{ 'fz-produto-conteudo__seletor-quantidade--condensado': modeloCondensado }"
                style="max-width: 140px;padding: 0;">
                <fz-variacao-quantidade v-model="quantidadeGrade" :min="0" :max="maxGrade" :step="1" :modelo-condensado="modeloCondensado" class="w-100"></fz-variacao-quantidade>
            </div>
        </div></div></div>

        <p-divider align="left" type="solid" class="fz-produto-conteudo__divisoria" @click="mostrarInfoGrade" style="cursor: help;">
            <b>Composição da Grade</b> <i class="fa fa-question-circle text-info" style="font-size: 18px;vertical-align: middle;"></i>
        </p-divider>

        <table class="fz-produto-conteudo__grade-tabela table table-bordered table-sm text-center mb-0" :style="estiloBloco">
            <tbody>
                <tr class="fz-produto-conteudo__grade-tabela-cabecalho">
                    <td class="px-2 py-1 w-50" style="font-weight: 500;">Variação</td>
                    <td class="px-2 py-1 w-50" style="font-weight: 500;">Qtd. por Grade</td>
                </tr>
                <tr v-for="variacao in composicaoGrade" :key="variacao.id" class="fz-produto-conteudo__grade-variacao">
                    <td class="fz-produto-conteudo__grade-variacao-info px-2 py-1 text-left">
                        <p-image v-if="variacao.imagem" :id="'img-variacao-'+produto.id+'-'+variacao.id" :src="obterURLArquivos(variacao.imagem)" preview image-class="fz-produto-conteudo__grade-variacao-imagem img-30 align-middle mr-1 img-variacoes" :image-style="{ cursor: 'pointer' }" @error="handleImageError" @click="irParaImagem(variacao.posicaoImagem)" :pt="{ root: { style: 'display: inline-block; vertical-align: middle; margin-right: 0.25rem;' } }"><template #previewicon><span></span></template></p-image>
                        <i v-if="variacao.cor" class="fz-produto-conteudo__grade-variacao-cor mr-1" :style="'color:'+variacao.cor+';background: '+variacao.cor+';'"></i>
                        <span class="fz-produto-conteudo__grade-variacao-nome">{{ variacao.nome }}</span>
                    </td>
                    <td class="fz-produto-conteudo__grade-variacao-qtd px-2 py-1">{{ variacao.qtdGrade }}</td>
                </tr>
            </tbody>
        </table>
    </div>`},FZComponents.VariacaoGradeComAbas={components:{"p-tabs":PrimeVue.Tabs,"p-tablist":PrimeVue.TabList,"p-tab":PrimeVue.Tab,"p-tabpanels":PrimeVue.TabPanels,"p-tabpanel":PrimeVue.TabPanel,"fz-variacao-com-grade":FZComponents.VariacaoComGrade,"fz-variacao-com-variacao":FZComponents.VariacaoComVariacao,"fz-variacao-com-subgrupos-variacao":FZComponents.VariacaoComSubgruposVariacao},props:{produto:{type:Object,required:!0},catalogoId:{type:[String,Number],required:!0},carrinho:{type:Object,default:()=>({})},configsLoja:{type:Object,default:null},somenteOrcamentos:{type:Boolean,default:!1},precosRestritos:{type:Boolean,default:!1},exibirPreco:{type:Boolean,default:!0},exibirSku:{type:Boolean,default:!0},exibirDivisoria:{type:Boolean,default:!0},exibirDescontos:{type:Boolean,default:!0},videoAtivo:{type:Boolean,default:!1},variacoesIsoladas:{type:Boolean,default:!1},tabAtiva:{type:[String,Number],default:null},variacoesDestaque:{type:Array,default:()=>[]},modeloCondensado:{type:Boolean,default:!1},usarSubgruposComoLista:{type:Boolean,default:!1}},data(){return{aba:"grade"}},computed:{temSubgrupos(){return this.produto.subgrupos_variacoes&&Object.keys(this.produto.subgrupos_variacoes).length>0},temVariacoes(){return this.produto.variacoes&&Object.keys(this.produto.variacoes).length>0}},methods:{trocarAba(novaAba){if(novaAba!==this.aba){try{typeof CarrinhoManager!="undefined"&&typeof CarrinhoManager.flush=="function"&&this.configsLoja&&CarrinhoManager.flush(this.configsLoja)}catch(e){}this.aba=novaAba}}},template:`
    <div class="fz-produto-conteudo__grade-hibrida">
        <p-tabs :value="aba" @update:value="trocarAba">
            <p-tablist>
                <p-tab value="grade">Grade</p-tab>
                <p-tab value="individual">Individual</p-tab>
            </p-tablist>
            <p-tabpanels>
                <p-tabpanel value="grade">
                    <fz-variacao-com-grade
                        :produto="produto"
                        :catalogo-id="catalogoId"
                        :carrinho="carrinho"
                        :exibir-sku="exibirSku"
                        :exibir-descontos="exibirDescontos"
                        :video-ativo="videoAtivo"
                        :variacoes-isoladas="variacoesIsoladas"
                        :modelo-condensado="modeloCondensado"
                        :usar-subgrupos-como-lista="usarSubgruposComoLista"
                    ></fz-variacao-com-grade>
                </p-tabpanel>
                <p-tabpanel value="individual">
                    <fz-variacao-com-subgrupos-variacao
                        v-if="temSubgrupos"
                        :produto="produto"
                        :catalogo-id="catalogoId"
                        :carrinho="carrinho"
                        :somente-orcamentos="somenteOrcamentos"
                        :precos-restritos="precosRestritos"
                        :exibir-preco="exibirPreco"
                        :exibir-sku="exibirSku"
                        :exibir-divisoria="exibirDivisoria"
                        :exibir-descontos="exibirDescontos"
                        :video-ativo="videoAtivo"
                        :variacoes-isoladas="variacoesIsoladas"
                        :tab-ativa="tabAtiva"
                        :variacoes-destaque="variacoesDestaque"
                        :modelo-condensado="modeloCondensado"
                        :usar-subgrupos-como-lista="usarSubgruposComoLista"
                    ></fz-variacao-com-subgrupos-variacao>
                    <fz-variacao-com-variacao
                        v-else-if="temVariacoes"
                        :produto="produto"
                        :catalogo-id="catalogoId"
                        :carrinho="carrinho"
                        :somente-orcamentos="somenteOrcamentos"
                        :precos-restritos="precosRestritos"
                        :exibir-preco="exibirPreco"
                        :exibir-sku="exibirSku"
                        :exibir-divisoria="exibirDivisoria"
                        :exibir-descontos="exibirDescontos"
                        :video-ativo="videoAtivo"
                        :variacoes-isoladas="variacoesIsoladas"
                        :modelo-condensado="modeloCondensado"
                        :usar-subgrupos-como-lista="usarSubgruposComoLista"
                    ></fz-variacao-com-variacao>
                </p-tabpanel>
            </p-tabpanels>
        </p-tabs>
    </div>`};

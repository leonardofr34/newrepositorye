if(typeof FZComponents=="undefined")var FZComponents={};(function(){var ultimoGatilho=null;document.addEventListener("click",function(evento){evento.target instanceof Element&&(ultimoGatilho=evento.target.closest('a, button, [role="button"]'))},!0),FZComponents.ContaVisitantePopover={inject:["configsLoja"],data:function(){return{aberto:!1,posicaoPainel:{top:"74px",right:"16px",left:"auto"},elementoAlvo:null,saindo:!1,saiu:!1,timerConfirmacaoSaida:null,timerRedirecionamentoSaida:null}},computed:{nomeVisitante:function(){return String(this.configsLoja.visitanteNome||"Cliente")},whatsappVisitante:function(){return String(this.configsLoja.visitanteWhatsapp||"WhatsApp conectado")},iniciaisVisitante:function(){return this.nomeVisitante.trim().split(/\s+/).filter(Boolean).slice(0,2).map(function(nome){return Array.from(nome)[0]||""}).join("").toUpperCase()||"C"},precisaValidarWhatsapp:function(){return!this.configsLoja.visitanteWhatsappValidado}},beforeUnmount:function(){window.clearTimeout(this.timerConfirmacaoSaida),window.clearTimeout(this.timerRedirecionamentoSaida),this.removerListeners()},methods:{abrir:function(elemento){return this.configsLoja.visitanteLogado?(this.saindo=!1,this.saiu=!1,this.elementoAlvo=elemento||ultimoGatilho||null,this.posicaoPainel=this.obterPosicaoPainel(this.elementoAlvo),this.aberto=!0,this.$nextTick(()=>{this.removerListeners(),document.addEventListener("click",this.aoClicarFora,!0),document.addEventListener("keydown",this.aoTecla)}),!0):!1},fechar:function(){this.aberto=!1,this.elementoAlvo=null,this.removerListeners()},obterPosicaoPainel:function(elemento){if(window.innerWidth<=480)return{top:"74px",right:"12px",left:"12px"};var margem=16,retangulo=null;if(elemento&&typeof elemento.getBoundingClientRect=="function"){var retangulosVisiveis=elemento.getClientRects();retangulosVisiveis&&retangulosVisiveis.length&&retangulosVisiveis[0].width>0&&retangulosVisiveis[0].height>0&&(retangulo=retangulosVisiveis[0])}var top,right;retangulo?(top=Math.max(margem,retangulo.bottom+14),right=Math.max(margem,window.innerWidth-retangulo.right)):(top=74,right=margem);var larguraMaxima=Math.min(390,window.innerWidth-margem*2);right=Math.min(right,window.innerWidth-larguraMaxima-margem),right=Math.max(right,margem);var alturaMinima=320;return top=Math.min(top,Math.max(margem,window.innerHeight-alturaMinima-margem)),top=Math.max(top,margem),{top:top+"px",right:right+"px",left:"auto"}},removerListeners:function(){document.removeEventListener("click",this.aoClicarFora,!0),document.removeEventListener("keydown",this.aoTecla)},aoClicarFora:function(evento){var painel=this.$refs.painel,alvo=this.elementoAlvo;painel&&painel.contains(evento.target)||alvo&&typeof alvo.contains=="function"&&alvo.contains(evento.target)||this.fechar()},aoTecla:function(evento){evento.key==="Escape"&&this.fechar()},abrirAcessoVisitante:function(){if(this.fechar(),this.precisaValidarWhatsapp){typeof window.abrirModalValidacaoWhatsApp=="function"&&window.abrirModalValidacaoWhatsApp("pedidos_whatsapp");return}this.configsLoja.urlPedidosWhatsApp&&(window.location.href=this.configsLoja.urlPedidosWhatsApp)},sairDaConta:function(){this.saindo||this.saiu||!this.configsLoja.urlSairConta||(this.saindo=!0,window.fetch(this.configsLoja.urlSairConta,{method:"GET",credentials:"include",cache:"no-store"}).catch(function(){}),this.timerConfirmacaoSaida=window.setTimeout(()=>{this.saindo=!1,this.saiu=!0},240),this.timerRedirecionamentoSaida=window.setTimeout(()=>{window.location.href=this.configsLoja.urlSairConta},1400))}},template:`
            <teleport to="body">
                <transition name="fz-conta-visitante-popover">
                    <section v-if="aberto" ref="painel" class="fz-conta-visitante-popover" :style="posicaoPainel" role="dialog" aria-label="Minha conta">
                        <section v-if="!saiu" class="fz-conta-visitante" :class="{ 'is-logging-out': saindo }">
                            <header class="fz-conta-visitante__cabecalho">
                                <div>
                                    <p class="fz-conta-visitante__sobretitulo">Área do cliente</p>
                                    <h2>Minha conta</h2>
                                    <p>Gerencie suas compras e seus dados nesta loja.</p>
                                </div>
                                <button type="button" class="fz-conta-visitante__fechar" aria-label="Fechar minha conta" @click="fechar">
                                    <i class="pi pi-times" aria-hidden="true"></i>
                                </button>
                            </header>

                            <div class="fz-conta-visitante__cliente">
                                <span class="fz-conta-visitante__avatar" aria-hidden="true">{{ iniciaisVisitante }}</span>
                                <div>
                                    <small>Cliente identificado</small>
                                    <strong>{{ nomeVisitante }}</strong>
                                </div>
                                <span class="fz-conta-visitante__status"><i class="pi pi-check" aria-hidden="true"></i> Conectado</span>
                            </div>

                            <div class="fz-conta-visitante__whatsapp">
                                <span class="fz-conta-visitante__whatsapp-icone"><i class="pi pi-whatsapp" aria-hidden="true"></i></span>
                                <div>
                                    <small>WhatsApp vinculado à conta</small>
                                    <strong>{{ whatsappVisitante }}</strong>
                                </div>
                                <span class="fz-conta-visitante__ponto-status" title="Conta ativa"></span>
                            </div>

                            <div class="fz-conta-visitante__acoes">
                                <template v-if="configsLoja.permitirCadastro">
                                    <a :href="configsLoja.urlMinhaConta" class="fz-conta-visitante__acao" @click="fechar">
                                        <span class="fz-conta-visitante__acao-icone"><i class="pi pi-shopping-bag" aria-hidden="true"></i></span>
                                        <span><strong>Meus pedidos</strong><small>Acompanhar compras</small></span>
                                    </a>
                                    <a :href="configsLoja.urlMinhaConta" class="fz-conta-visitante__acao" @click="fechar">
                                        <span class="fz-conta-visitante__acao-icone"><i class="pi pi-user" aria-hidden="true"></i></span>
                                        <span><strong>Meus dados</strong><small>Dados de cadastro</small></span>
                                    </a>
                                </template>
                                <template v-else>
                                    <template v-if="precisaValidarWhatsapp">
                                        <button type="button" class="fz-conta-visitante__acao" @click="abrirAcessoVisitante">
                                            <span class="fz-conta-visitante__acao-icone"><i class="pi pi-shopping-bag" aria-hidden="true"></i></span>
                                            <span><strong>Meus pedidos</strong><small>Valide sua conta para acessar</small></span>
                                        </button>
                                        <button type="button" class="fz-conta-visitante__acao" @click="abrirAcessoVisitante">
                                            <span class="fz-conta-visitante__acao-icone"><i class="pi pi-user" aria-hidden="true"></i></span>
                                            <span><strong>Meus dados</strong><small>Valide sua conta para acessar</small></span>
                                        </button>
                                    </template>
                                    <template v-else>
                                        <a :href="configsLoja.urlPedidosWhatsApp" class="fz-conta-visitante__acao" @click="fechar">
                                            <span class="fz-conta-visitante__acao-icone"><i class="pi pi-shopping-bag" aria-hidden="true"></i></span>
                                            <span><strong>Meus pedidos</strong><small>Acompanhar compras</small></span>
                                        </a>
                                        <a :href="configsLoja.urlPedidosWhatsApp" class="fz-conta-visitante__acao" @click="fechar">
                                            <span class="fz-conta-visitante__acao-icone"><i class="pi pi-user" aria-hidden="true"></i></span>
                                            <span><strong>Meus dados</strong><small>Dados de cadastro</small></span>
                                        </a>
                                    </template>
                                </template>
                            </div>

                            <footer class="fz-conta-visitante__rodape">
                                <button type="button" class="fz-conta-visitante__sair" :disabled="saindo" @click="sairDaConta">
                                    <i class="pi pi-sign-out" aria-hidden="true"></i>
                                    {{ saindo ? 'Encerrando sessão...' : 'Sair da conta' }}
                                </button>
                                <p>Seus dados são protegidos durante sua experiência de compra.</p>
                            </footer>
                        </section>

                        <section v-else class="fz-conta-visitante__saida-confirmada" aria-live="polite">
                            <span class="fz-conta-visitante__saida-icone"><i class="pi pi-check" aria-hidden="true"></i></span>
                            <h2>Você saiu da conta</h2>
                            <p>Sua sessão foi encerrada com segurança.</p>
                            <small>Atualizando sua sessão...</small>
                        </section>
                    </section>
                </transition>
            </teleport>
        `}})();

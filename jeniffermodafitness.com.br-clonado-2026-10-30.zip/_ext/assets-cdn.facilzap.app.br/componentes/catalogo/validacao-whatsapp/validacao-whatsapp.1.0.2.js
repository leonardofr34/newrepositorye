if(typeof FZComponents=="undefined")var FZComponents={};const ValidacaoWhatsAppStore=Vue.reactive({visivel:!1}),MENSAGEM_EMAIL_CADASTRO_NECESSARIO="Entre em contato com a loja e solicite o cadastro do seu e-mail na sua conta para validar o acesso.";FZComponents.ValidacaoWhatsApp={components:{"p-button":PrimeVue.Button,"p-drawer":PrimeVue.Drawer,"p-inputotp":PrimeVue.InputOtp,"p-message":PrimeVue.Message},data(){return{store:ValidacaoWhatsAppStore,dados:window.FZValidacaoWhatsAppDados||{},codigo:"",whatsapp:"",email:"",retorno:"",enviando:!1,validando:!1,sucesso:!1,erroCodigo:!1,whatsappEnviado:!1,emailEnviado:!1,mensagem:"",mensagemSeveridade:"error"}},computed:{drawerVisivel:{get(){return this.store.visivel},set(valor){this.store.visivel=!!valor}},carregando(){return this.enviando||this.validando},textoIntroducao(){return this.whatsappEnviado&&this.emailEnviado?"Enviamos um código de 5 dígitos para seu WhatsApp e e-mail para confirmar sua conta.":this.whatsappEnviado?"Enviamos um código de 5 dígitos para seu WhatsApp para confirmar sua conta.":"Enviamos um código de 5 dígitos para seu e-mail para confirmar sua conta."}},watch:{codigo(){this.erroCodigo=!1,this.mensagem=""},"store.visivel"(visivel){!visivel||this.enviando||this.sucesso||this.focarCodigo()}},methods:{async abrir(retorno){var _a,_b;if(this.carregando)return!1;this.mensagem="",this.mensagemSeveridade="error",this.retorno=retorno||"",this.codigo="",this.email="",this.whatsapp="",this.whatsappEnviado=!1,this.emailEnviado=!1,this.erroCodigo=!1,this.sucesso=!1,this.enviando=!0;try{const resposta=await this.requisitar(this.dados.enviarUrl);return this.whatsapp=this.textoSeguro(resposta==null?void 0:resposta.whatsapp),this.email=this.textoSeguro(resposta==null?void 0:resposta.email),this.whatsappEnviado=((_a=resposta==null?void 0:resposta.canais)==null?void 0:_a.whatsapp)===!0,this.emailEnviado=((_b=resposta==null?void 0:resposta.canais)==null?void 0:_b.email)===!0,this.store.visivel=!0,this.focarCodigo(),!0}catch(error){return error.message===MENSAGEM_EMAIL_CADASTRO_NECESSARIO?(this.fechar(!0),this.notificar("Ops!",error.message,"info"),!1):(this.store.visivel=!0,this.mostrarMensagem(error.message||"Não foi possível enviar o código de verificação! Atualize a página e tente novamente."),!1)}finally{this.enviando=!1}},fechar(forcar){this.carregando&&!forcar||(this.store.visivel=!1)},async validar(){if(!(this.carregando||this.sucesso)){if(String(this.codigo||"").length!==5){this.erroCodigo=!0,this.mostrarMensagem("Código de verificação inválido!"),this.focarCodigo();return}this.mensagem="",this.validando=!0;try{await this.requisitar(this.dados.validarUrl,{codigo:this.codigo}),this.sucesso=!0,window.visitanteWhatsAppValidado=!0,window.clienteLogado=!0,window.usuarioLogado=!0,typeof sessionStorage!="undefined"&&sessionStorage.setItem("finalizacao_pedido_aproveitar_dados","true"),window.setTimeout(()=>this.concluir(),2e3)}catch(error){this.mostrarMensagem(error.message||"Não foi possível validar o código de verificação! Atualize a página e tente novamente.")}finally{this.validando=!1}}},async requisitar(url,dados){var _a;if(!url)throw new Error("Não foi possível iniciar a validação da conta. Atualize a página e tente novamente.");const opcoes={method:"POST"};dados&&(opcoes.headers={"Content-Type":"application/x-www-form-urlencoded"},opcoes.body=new URLSearchParams(dados));const response=await fetch(url,opcoes);let resposta=null;try{resposta=await response.json()}catch(error){if(!response.ok)throw new Error("Não foi possível concluir a solicitação. Tente novamente.")}if(!response.ok)throw new Error(((_a=resposta==null?void 0:resposta.messages)==null?void 0:_a.error)||"Não foi possível concluir a solicitação. Tente novamente.");return resposta},focarCodigo(){this.$nextTick(()=>{window.setTimeout(()=>{const primeiroCampo=document.querySelector(".fz-validacao-whatsapp-drawer .fz-validacao-whatsapp__codigo input");primeiroCampo&&primeiroCampo.focus()},100)})},textoSeguro(valor){return String(valor||"").replace(/<[^>]*>/g,"").trim()},mostrarMensagem(mensagem,severidade="error"){this.mensagem=mensagem,this.mensagemSeveridade=severidade},concluir(){if(this.retorno==="minha_conta"&&this.dados.urlMinhaConta){window.location.href=this.dados.urlMinhaConta;return}if(this.retorno==="seguir"&&typeof window.abrirModalSeguir=="function"){this.fechar(),window.abrirModalSeguir();return}window.location.reload()},notificar(titulo,mensagem,tipo){typeof window.showNotification=="function"&&window.showNotification(titulo,mensagem,tipo)}},template:`
        <p-drawer
            v-model:visible="drawerVisivel"
            position="right"
            :dismissable="!carregando"
            :closable="false"
            :block-scroll="true"
            :base-z-index="1000004"
            :style="{ width: 'min(520px, 100vw)' }"
            class="fz-validacao-whatsapp-drawer"
        >
            <template #container>
                <section class="fz-validacao-whatsapp" aria-labelledby="fz-validacao-whatsapp-titulo">
                    <header class="fz-validacao-whatsapp__cabecalho">
                        <div class="fz-validacao-whatsapp__titulo-wrap">
                            <span class="fz-validacao-whatsapp__icone-titulo" aria-hidden="true"><i class="pi pi-shield"></i></span>
                            <div>
                                <h2 id="fz-validacao-whatsapp-titulo">Validar conta</h2>
                                <span>Proteção e acesso à sua conta</span>
                            </div>
                        </div>
                        <button type="button" class="fz-validacao-whatsapp__fechar" :disabled="carregando" aria-label="Fechar validação da conta" @click="fechar">
                            <i class="pi pi-times" aria-hidden="true"></i>
                        </button>
                    </header>

                    <main class="fz-validacao-whatsapp__corpo">
                        <p-message
                            v-if="mensagem"
                            :severity="mensagemSeveridade"
                            size="small"
                            :closable="false"
                            class="mb-3"
                            aria-live="polite"
                        >
                            {{ mensagem }}
                        </p-message>

                        <div v-if="enviando" class="fz-validacao-whatsapp__carregamento" aria-live="polite" aria-busy="true">
                            <span class="fz-validacao-whatsapp__spinner" aria-hidden="true"></span>
                            <strong>Enviando código de verificação</strong>
                            <span>Aguarde um instante.</span>
                        </div>

                        <section v-else-if="sucesso" class="fz-validacao-whatsapp__sucesso" aria-live="polite">
                            <span class="fz-validacao-whatsapp__sucesso-icone" aria-hidden="true"><i class="pi pi-check"></i></span>
                            <h3>Conta validada!</h3>
                            <p>Sua conta foi confirmada com sucesso. Agora você pode acessar seus pedidos e dados de cadastro.</p>
                        </section>

                        <template v-else>
                            <p class="fz-validacao-whatsapp__introducao">{{ textoIntroducao }}</p>

                            <div v-if="whatsappEnviado" class="fz-validacao-whatsapp__telefone">
                                <span class="fz-validacao-whatsapp__telefone-icone" aria-hidden="true"><i class="pi pi-whatsapp"></i></span>
                                <div>
                                    <span>Código enviado para</span>
                                    <strong>{{ whatsapp || 'seu WhatsApp' }}</strong>
                                </div>
                            </div>

                            <div v-if="emailEnviado" class="fz-validacao-whatsapp__telefone">
                                <span class="fz-validacao-whatsapp__telefone-icone" aria-hidden="true"><i class="pi pi-envelope"></i></span>
                                <div>
                                    <span>Código enviado para</span>
                                    <strong>{{ email }}</strong>
                                </div>
                            </div>

                            <div class="fz-validacao-whatsapp__codigo-label">
                                <strong>Digite o código</strong>
                                <span>5 dígitos</span>
                            </div>
                            <p-inputotp
                                ref="codigo"
                                v-model="codigo"
                                :length="5"
                                integer-only
                                :class="{ 'is-invalid': erroCodigo }"
                                class="fz-validacao-whatsapp__codigo"
                                aria-label="Código de verificação de cinco dígitos"
                                @keyup.enter="validar"
                            ></p-inputotp>

                            <p class="fz-validacao-whatsapp__aviso"><i class="pi pi-info-circle" aria-hidden="true"></i><span>Você pode continuar comprando e enviar seu pedido mesmo sem validar sua conta.</span></p>

                            <section class="fz-validacao-whatsapp__beneficios">
                                <h3>Por que validar?</h3>
                                <ul>
                                    <li><i class="pi pi-check" aria-hidden="true"></i><span>Acesse seu histórico de pedidos</span></li>
                                    <li><i class="pi pi-check" aria-hidden="true"></i><span>Altere seus dados de cadastro</span></li>
                                    <li><i class="pi pi-check" aria-hidden="true"></i><span>Faça recompra de pedidos anteriores</span></li>
                                </ul>
                            </section>

                            <p class="fz-validacao-whatsapp__seguranca"><i class="pi pi-lock" aria-hidden="true"></i>Seus dados são usados apenas para identificação da sua conta.</p>
                        </template>
                    </main>

                    <footer v-if="!sucesso" class="fz-validacao-whatsapp__rodape">
                        <div class="fz-validacao-whatsapp__acoes">
                            <p-button label="Cancelar" severity="secondary" class="fz-validacao-whatsapp__cancelar" :disabled="carregando" @click="fechar"></p-button>
                            <p-button label="Validar código" severity="primary" class="fz-validacao-whatsapp__validar" :loading="validando" :disabled="enviando" @click="validar"></p-button>
                        </div>
                    </footer>
                </section>
            </template>
        </p-drawer>
    `},(function(){function montar(){const root=document.getElementById("catalogo-validacao-whatsapp-app");if(!root||window.FZValidacaoWhatsAppAppInstance||typeof Vue=="undefined"||typeof PrimeVue=="undefined")return;const app=Vue.createApp({components:{"fz-validacao-whatsapp":FZComponents.ValidacaoWhatsApp}});app.use(PrimeVue.Config,{theme:{preset:typeof lojaPreset!="undefined"?lojaPreset:PrimeVue.Themes&&PrimeVue.Themes.FacilZap,options:{darkModeSelector:!1}}}),window.FZValidacaoWhatsAppAppInstance=app.mount(root),window.FacilZapValidacaoWhatsApp={abrir:function(retorno){var _a;const validacao=(_a=window.FZValidacaoWhatsAppAppInstance)==null?void 0:_a.$refs.validacaoWhatsApp;return validacao?validacao.abrir(retorno):!1},fechar:function(){var _a;const validacao=(_a=window.FZValidacaoWhatsAppAppInstance)==null?void 0:_a.$refs.validacaoWhatsApp;validacao&&validacao.fechar()}}}if(document.readyState==="loading"){document.addEventListener("DOMContentLoaded",montar,{once:!0});return}montar()})();

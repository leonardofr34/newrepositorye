if(typeof FZComponents=="undefined")var FZComponents={};FZComponents.ProdutosCarrossel={components:{"fz-titulo-secao":FZComponents.TituloSecao,"fz-produto":FZComponents.Produto,"fz-produto-skeleton":FZComponents.ProdutoSkeleton},props:["titulo","corTitulo","tipo","produtos","modoExibicao","carregando","categoriaId","margemSuperior","margemInferior"],inject:["configsLoja","baseUrlCatalogo"],data(){return{swiperInstance:null,componentId:"produtos-carrossel-"+Math.random().toString(36).substr(2,9)}},computed:{estiloMargens(){var _a,_b;const margemSup=(_a=this.margemSuperior)!=null?_a:20,margemInf=(_b=this.margemInferior)!=null?_b:20;return`margin-top: ${margemSup}px; margin-bottom: ${margemInf}px;`},temProdutos(){return this.produtos&&this.produtos.length>0},exibirBotaoVerMais(){return this.tipo==="campanha-produtos"?!0:this.tipo==="produtos-carrossel-categoria"&&this.categoriaId},layoutProduto(){return["clean","clean_2","color","grid_novo","grid_2","fancy","video"].includes(this.modoExibicao)?this.modoExibicao:"grid_novo"},breakpointsSwiper(){return this.layoutProduto==="clean"?{320:{slidesPerView:1.5},768:{slidesPerView:2.1},992:{slidesPerView:3.1},1200:{slidesPerView:4.1}}:this.layoutProduto==="video"?{320:{slidesPerView:1.75},768:{slidesPerView:2.5},992:{slidesPerView:3.5},1200:{slidesPerView:4.8}}:{320:{slidesPerView:2.1},768:{slidesPerView:3.1},992:{slidesPerView:4.1},1200:{slidesPerView:6.1}}}},mounted(){this.temProdutos&&this.$nextTick(()=>{this.initSwiper()})},watch:{produtos(newValue){newValue&&newValue.length>0&&this.$nextTick(()=>{this.initSwiper()})}},methods:{initSwiper(){typeof Swiper!="undefined"&&this.temProdutos&&(this.swiperInstance&&this.swiperInstance.destroy(!0,!0),this.swiperInstance=new Swiper(`#${this.componentId}`,{slidesPerView:4.1,centeredSlides:!1,touchAngle:20,centerInsufficientSlides:!0,observer:!0,observeSlideChildren:!0,spaceBetween:0,autoHeight:!0,autoplay:{delay:4e3,disableOnInteraction:!0},pagination:{el:`#${this.componentId} .swiper-pagination.carrossel`},navigation:{nextEl:`#${this.componentId} .swiper-button-next.carrossel`,prevEl:`#${this.componentId} .swiper-button-prev.carrossel`},breakpoints:this.breakpointsSwiper}))},getLinkVerMais(){return this.tipo==="campanha-produtos"?this.baseUrlCatalogo.replace("{PATH}","campanha"):this.baseUrlCatalogo.replace("{PATH}","categoria/"+this.categoriaId)}},beforeUnmount(){this.swiperInstance&&this.swiperInstance.destroy(!0,!0)},template:`
    <div class="fz-produtos-carrossel px-1" :style="estiloMargens">
        <fz-titulo-secao :titulo="titulo" :cor="corTitulo"></fz-titulo-secao>
        
        <!-- Loading com Skeletons -->
        <div v-if="carregando" class="row">
            <div class="col-6 col-md-4 col-lg-2 px-0" v-for="n in 6" :key="'skeleton-' + n">
                <fz-produto-skeleton></fz-produto-skeleton>
            </div>
        </div>
        
        <!-- Produtos -->
        <div v-else-if="temProdutos" class="swiper mb-4 pb-3 px-0 px-lg-2 pl-md-4" :id="componentId" style="margin-left: -15px; margin-right: -15px;">
            <div class="swiper-wrapper">
                <div v-for="produto in produtos" :key="produto.id" class="swiper-slide">
                    <fz-produto 
                        :produto="produto"
                        :layout="layoutProduto"
                        :prefixo-slider="componentId + '-'"
                        :ocultar-destaque="false"
                        :precos-restritos="configsLoja.precosRestritos"
                        :preco-destaque="configsLoja.precoDestaque"
                        :catalogo-url="baseUrlCatalogo"
                        :somente-orcamentos="configsLoja.somenteOrcamentos"
                        :mostrar-quantidade-venda="configsLoja.mostrarQuantidadeVenda"
                        :habilitar-curtidas="configsLoja.habilitarCurtidas"
                        :habilitar-perguntas="configsLoja.habilitarPerguntas"
                        :permitir-compartilhar-produto="configsLoja.permitirCompartilharProduto"
                        :ativar-simulador-parcelas="configsLoja.ativarSimuladorParcelas"
                        :texto-botao-acao-produtos="configsLoja.textoBotaoAcaoProdutos"
                        :icone-botao-acao-produtos="configsLoja.iconeBotaoAcaoProdutos"
                        :habilitar-avise-me-quando-chegar="configsLoja.habilitarAviseMeQuandoChegar"
                        :grid-formato-imagem="configsLoja.gridFormatoImagem"
                        :exibir-variacoes-direto-pagina="false"
                        :campanha-promocional-ativa-no-momento="configsLoja.campanhaPromocionalAtivaNoMomento"
                        :campanha-promocional-tag-produtos-ativada="configsLoja.campanhaPromocionalTagProdutosAtivada"
                        :campanha-promocional-tag-produtos-texto="configsLoja.campanhaPromocionalTagProdutosTexto"
                        :campanha-promocional-tag-produtos-cor-fundo="configsLoja.campanhaPromocionalTagProdutosCorFundo"
                        :campanha-promocional-tag-produtos-cor-texto="configsLoja.campanhaPromocionalTagProdutosCorTexto"
                    >
                    </fz-produto>
                </div>
                
                <!-- Slide Ver Mais -->
                <div v-if="exibirBotaoVerMais" class="swiper-slide d-flex align-items-center justify-content-start align-self-center">
                    <a :href="getLinkVerMais()" class="ver-mais-box d-flex flex-column align-items-center justify-content-center text-decoration-none">
                        <div class="ver-mais-conteudo text-center p-3">
                            <i class="fa fa-arrow-right mb-2 ver-mais-icone"></i>
                            <p class="mb-0 font-weight-bold ver-mais-texto">
                                Ver Mais<br>Produtos
                            </p>
                        </div>
                    </a>
                </div>
            </div>
            <div class="swiper-pagination carrossel d-block d-lg-none"></div>
            <div class="swiper-button-prev fz-seta-slider carrossel slider-produto d-none d-lg-flex"></div>
            <div class="swiper-button-next fz-seta-slider carrossel slider-produto d-none d-lg-flex"></div>
        </div>
    </div>
    `};

if(typeof FZComponents=="undefined")var FZComponents={};FZComponents.TituloSecao={props:{titulo:{type:String,default:""},alinhamento:{type:String,default:"center",validator:value=>["center","left","right"].includes(value)},tamanho:{type:String,default:"h3",validator:value=>["h1","h2","h3","h4","h5","h6"].includes(value)},cor:{type:String,default:""},"margem-inferior":{type:String,default:"mb-3"},icone:{type:String,default:""},class:{type:String,default:""}},computed:{classesTexto(){const classes=["font-weight-bold",this.margemInferior];return this.alinhamento==="center"?classes.push("text-center"):this.alinhamento==="left"?classes.push("text-left"):this.alinhamento==="right"&&classes.push("text-right"),this.class&&classes.push(this.class),classes.join(" ")},estiloTitulo(){return this.cor?{"--cor-fz-titulo":this.cor}:{"--cor-fz-titulo":"var(--cor-detalhes-gerais)"}}},template:`
    <div v-if="titulo" :class="classesTexto">
        <component 
            :is="tamanho" 
            :style="estiloTitulo"
            class="titulo-secao-inicio">
            <i v-if="icone" :class="icone" class="mr-2"></i>
            {{ titulo }}
        </component>
    </div>
    `};

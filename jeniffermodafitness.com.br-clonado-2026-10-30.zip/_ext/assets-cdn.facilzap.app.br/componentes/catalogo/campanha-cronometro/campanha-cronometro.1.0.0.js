if(typeof FZComponents=="undefined")var FZComponents={};FZComponents.CampanhaCronometro={props:["titulo","corTitulo","margemSuperior","margemInferior"],inject:["configsLoja"],data(){return{tempoRestante:{dias:0,horas:"00",minutos:"00",segundos:"00"},tituloContador:"",intervalo:null,campanhaEncerrada:!1}},computed:{estiloMargens(){var _a,_b;const margemSup=(_a=this.margemSuperior)!=null?_a:20,margemInf=(_b=this.margemInferior)!=null?_b:20;return`margin-top: ${margemSup}px; margin-bottom: ${margemInf}px;`},campanhaAtiva(){return this.configsLoja.campanhaPromocionalCronometroAtivo},imagemCampanha(){return this.configsLoja.campanhaPromocionalCronometroImagem},nomeCampanha(){return this.configsLoja.campanhaPromocionalNome}},mounted(){this.campanhaAtiva&&this.iniciarContador()},beforeUnmount(){this.intervalo&&clearInterval(this.intervalo)},methods:{iniciarContador(){this.atualizarContador(),this.intervalo=setInterval(()=>{this.atualizarContador()},1e3)},atualizarContador(){const dataAtual=new Date().getTime(),dataInicio=new Date(this.configsLoja.campanhaPromocionalCronogramaInicio).getTime(),dataTermino=new Date(this.configsLoja.campanhaPromocionalCronogramaTermino).getTime();let duration;if(dataAtual<=dataInicio)this.tituloContador=`${this.nomeCampanha} inicia em`,duration=(dataInicio-dataAtual)/1e3;else if(dataAtual<=dataTermino)this.tituloContador=`${this.nomeCampanha} iniciada! Termina em`,duration=(dataTermino-dataAtual)/1e3;else{this.tituloContador=`${this.nomeCampanha} encerrada!`,this.campanhaEncerrada=!0,this.intervalo&&clearInterval(this.intervalo);return}let dias=Math.floor(duration%2592e3/86400),horas=Math.floor(duration%86400/3600),minutos=Math.floor(duration%3600/60),segundos=Math.floor(duration%60);dias=dias<=9?"0"+dias:dias.toString(),horas=horas<=9?"0"+horas:horas.toString(),minutos=minutos<=9?"0"+minutos:minutos.toString(),segundos=segundos<=9?"0"+segundos:segundos.toString(),this.tempoRestante={dias,horas,minutos,segundos}}},template:`
    <div class="fz-campanha-cronometro" :style="estiloMargens" v-if="campanhaAtiva">
        <div class="card campanha-card">
            <div class="row justify-content-center align-items-center">
                <div class="col-10 col-md-8 col-lg-5" v-if="imagemCampanha">
                    <div class="campanha-imagem" :style="{ backgroundImage: 'url(' + imagemCampanha + ')' }"></div>
                </div>
                <div :class="imagemCampanha ? 'col-12 col-lg-7' : 'col-12'">
                    <h3 class="campanha-titulo mt-3">
                        <i class="pi pi-stopwatch"></i> 
                        {{ tituloContador }}
                    </h3>
                    <div class="cronometro-container mb-3" v-if="!campanhaEncerrada">
                        <!-- Contador de Dias (quando houver) -->
                        <template v-if="parseInt(tempoRestante.dias) > 0">
                            <div class="cronometro-bloco">
                                <div class="cronometro-digitos">
                                    <div class="cronometro-numero">{{ tempoRestante.dias.charAt(0) }}</div>
                                    <div class="cronometro-numero">{{ tempoRestante.dias.charAt(1) }}</div>
                                </div>
                                <div class="cronometro-label">DIAS</div>
                            </div>
                            <div class="cronometro-separador">:</div>
                        </template>
                        
                        <!-- Contador de Horas -->
                        <div class="cronometro-bloco">
                            <div class="cronometro-digitos">
                                <div class="cronometro-numero">{{ tempoRestante.horas.charAt(0) }}</div>
                                <div class="cronometro-numero">{{ tempoRestante.horas.charAt(1) }}</div>
                            </div>
                            <div class="cronometro-label">HORAS</div>
                        </div>
                        
                        <div class="cronometro-separador">:</div>
                        
                        <!-- Contador de Minutos -->
                        <div class="cronometro-bloco">
                            <div class="cronometro-digitos">
                                <div class="cronometro-numero">{{ tempoRestante.minutos.charAt(0) }}</div>
                                <div class="cronometro-numero">{{ tempoRestante.minutos.charAt(1) }}</div>
                            </div>
                            <div class="cronometro-label">MINUTOS</div>
                        </div>
                        
                        <div class="cronometro-separador">:</div>
                        
                        <!-- Contador de Segundos -->
                        <div class="cronometro-bloco">
                            <div class="cronometro-digitos">
                                <div class="cronometro-numero">{{ tempoRestante.segundos.charAt(0) }}</div>
                                <div class="cronometro-numero">{{ tempoRestante.segundos.charAt(1) }}</div>
                            </div>
                            <div class="cronometro-label">SEGUNDOS</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    `};

if(typeof FZComponents=="undefined")var FZComponents={};const SimuladorFreteStore=Vue.reactive({dialogOpen:!1,carregando:!1,cepAtual:"",paisAtual:"BR",elegivelFreteGratis:!1,entregaBrasil:!0,produtoId:null,quantidade:0,precoTotal:0,resultados:{cotacoesPorModulo:[],formasEntregaManuais:[],uf:null,cidade:null}}),logosGatewaysEntrega={fretefacil:"https://assets.facilzap.app.br/facilzap_envios-logo.png",correios:"https://assets.facilzap.app.br/correios-logo.png",total_express:"https://assets.facilzap.app.br/total_express-logo.png",jadlog:"https://assets.facilzap.app.br/jadlog-logo.png",melhorenvio:"https://assets.facilzap.app.br/melhorenvio-logo.png",frenet:"https://assets.facilzap.app.br/frenet-logo.png",enviamais:"https://assets.facilzap.app.br/enviamais-logo2.png",braspress:"https://assets.facilzap.app.br/braspress-logo.png",kangu:"https://assets.facilzap.app.br/kangu-logo.png",clube_envios:"https://assets.facilzap.app.br/clube_envios-logo.png",frete_rapido:"https://assets.facilzap.app.br/frete_rapido-logo.png",superfrete:"https://assets.facilzap.app.br/superfrete-logo.png",conectenvios:"https://assets.facilzap.app.br/conectenvios-logo.png",manda_bem:"https://assets.facilzap.app.br/manda_bem-logo.png",flex_envios:"https://assets.facilzap.app.br/flex_envios-logo.jpg",dyzon:"https://assets.facilzap.app.br/dyzon-logo.png",mandar:"https://assets.facilzap.app.br/mandar-logo.png",uber_direct:window.FZCatalogoAssetConfig.uberDirectLogo,nove_nove:"https://assets.facilzap.app.br/nove_nove-logo.png",raio:"https://assets.facilzap.app.br/entrega_raio.png"},SimuladorFreteMixin={inject:["configsLoja"],data(){return{simuladorStore:SimuladorFreteStore}},methods:{formatarPreco(valor){if(!valor)return"0,00";const num=parseFloat(valor);return isNaN(num)?"0,00":num.toFixed(2).replace(".",",")},normalizeClassName(str){return str?str.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g,"").replace(/[^a-z0-9]/g,"_"):""},validarFaixasCep(cep,faixasCep){if(typeof faixasCep=="object"&&faixasCep!==null&&!Array.isArray(faixasCep)){let cepNaFaixa=!1;return Object.values(faixasCep).forEach(faixa=>{const inicio=Number(faixa.inicio.replace(/\D/g,"")),termino=Number(faixa.termino.replace(/\D/g,"")),cepNum=Number(cep);cepNum>=inicio&&cepNum<=termino&&(cepNaFaixa=!0)}),cepNaFaixa}return!0},obterCEPLocalStorage(){const cepSessao=localStorage.getItem("cliente_cep");return cepSessao||this.configsLoja.cepClienteLogado||""},salvarCEPLocalStorage(cep){localStorage.setItem("cliente_cep",cep)}}};FZComponents.SimuladorFreteFormulario={components:{"p-inputmask":PrimeVue.InputMask,"p-inputtext":PrimeVue.InputText,"p-button":PrimeVue.Button,"fz-select-pais":FZComponents.SelectPais},mixins:[SimuladorFreteMixin],props:{produtoId:{type:[String,Number],default:null},quantidades:{type:Object,default:()=>({})}},data(){return{cep:"",pais:"BR",estimativaRef:null,estimativaPadrao:{dados:null,visivel:!1,local:"Estimativa para sua cidade",prazo:"Calculando estimativa...",observacao:"Aguarde enquanto calculamos o prazo de entrega."}}},computed:{cepMask(){return this.pais==="BR"?"99999-999":null},cepPlaceholder(){return this.pais==="BR"?"00000-000":"Código Postal"},estimativaIdContainer(){return this.produtoId!==null&&this.produtoId!==void 0?"produto-"+this.produtoId:"produto"},estimativaContexto(){return this.produtoId===null||this.produtoId===void 0?{tipo:"carrinho",assinatura:""}:{tipo:"produto",produto_id:this.produtoId,quantidades:{...this.quantidades||{}}}},estimativa(){return this.estimativaRef||this.estimativaPadrao}},watch:{cep(novoCep){if(this.pais!=="BR"||!this.configsLoja.freteFacilAtivado)return;const cepLimpo=String(novoCep||"").replace(/\D/g,"");cepLimpo.length===8&&window.FacilZapEstimativaPrazo&&window.FacilZapEstimativaPrazo.notificarCep(cepLimpo,this.estimativaIdContainer)},quantidades:{deep:!0,handler(){this.estimativaRef&&typeof window.FacilZapEstimativaPrazo!="undefined"&&typeof window.FacilZapEstimativaPrazo.atualizarContexto=="function"&&window.FacilZapEstimativaPrazo.atualizarContexto(this.estimativaIdContainer,this.estimativaContexto)}}},mounted(){this.cep=this.obterCEPLocalStorage(),this.$nextTick(()=>{this.configsLoja.freteFacilAtivado&&typeof window.FacilZapEstimativaPrazo!="undefined"&&(this.estimativaRef=window.FacilZapEstimativaPrazo.iniciar(this.estimativaIdContainer,this.configsLoja,this.estimativaContexto))})},methods:{simular(){const cepLimpo=this.cep.replace(/\D/g,"");if(this.pais==="BR"&&cepLimpo.length<8){typeof showNotification=="function"&&showNotification("Atenção","Por favor, informe um CEP válido.","warning");return}if(!this.cep){typeof showNotification=="function"&&showNotification("Atenção","Por favor, informe o código postal.","warning");return}typeof window.abrirSimuladorFrete=="function"?window.abrirSimuladorFrete(cepLimpo,this.pais,this.produtoId,0,0):this.$emit("simular",{cep:cepLimpo,pais:this.pais,produtoId:this.produtoId})}},template:`
    <div class="fz-simulador-frete-formulario">
        <div class="fz-simulador-frete-formulario__campos d-flex gap-1 align-items-center justify-content-center">
            <div v-if="configsLoja.permitirEntregaInternacional" class="fz-simulador-frete-formulario__pais">
                <fz-select-pais
                    v-model="pais"
                    select-type="reduced"
                ></fz-select-pais>
            </div>

            <div class="fz-simulador-frete-formulario__cep-grupo d-flex gap-1">
                <p-inputmask
                    v-if="pais === 'BR'"
                    v-model="cep"
                    :mask="cepMask"
                    :placeholder="cepPlaceholder"
                    class="fz-simulador-frete-formulario__cep-input"
                    size="small"
                    inputmode="numeric"
                    @keydown.enter="simular"
                ></p-inputmask>
                <p-inputtext
                    v-else
                    v-model="cep"
                    :placeholder="cepPlaceholder"
                    class="fz-simulador-frete-formulario__cep-input"
                    size="small"
                    @keydown.enter="simular"
                ></p-inputtext>
                <p-button
                    icon="ti-truck"
                    label="Calcular"
                    size="small"
                    severity="primary"
                    @click="simular"
                    :disabled="!cep"
                ></p-button>
            </div>
        </div>

        <div v-if="pais === 'BR' && configsLoja.freteFacilAtivado"
             class="fz-estimativa-prazo"
             v-show="estimativa.visivel"
             :data-fz-estimativa-prazo="estimativaIdContainer">
            <div class="fz-estimativa-prazo__icone" aria-hidden="true">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
                    <circle cx="12" cy="12" r="8.5"/>
                    <path d="M12 7.5v5"/>
                    <path d="M12 12.5l3 2"/>
                </svg>
            </div>
            <div>
                <span class="fz-estimativa-prazo__local" v-text="estimativa.local"></span>
                <p class="fz-estimativa-prazo__prazo" v-text="estimativa.prazo"></p>
                <p class="fz-estimativa-prazo__observacao" v-text="estimativa.observacao"></p>
            </div>
        </div>
    </div>
    `},FZComponents.SimuladorFreteDialog={components:{"p-dialog":PrimeVue.Dialog,"p-button":PrimeVue.Button,"p-inputmask":PrimeVue.InputMask,"p-inputtext":PrimeVue.InputText,"p-radiobutton":PrimeVue.RadioButton},mixins:[SimuladorFreteMixin],props:{produtoId:{type:[String,Number],default:null}},data(){return{quantidade:0,precoTotal:0,cepEdicao:"",exibirEdicaoCep:!1,opcaoSelecionada:null,tabelaSelecionada:{},campoExtra:{}}},watch:{"simuladorStore.dialogOpen"(newValue){if(newValue){if(this.simuladorStore.produtoId&&this.simuladorStore.quantidade<=0)return this.simuladorStore.dialogOpen=!1,showNotification("Ops!","Informe a quantidade desejada do produto.","warning"),!1;this.quantidade=this.simuladorStore.quantidade,this.precoTotal=this.simuladorStore.precoTotal,this.resetarSelecao(),this.iniciarSimulacao()}}},computed:{visible:{get(){return this.simuladorStore.dialogOpen},set(value){this.simuladorStore.dialogOpen=value}},exibirFreteGratis(){if(!this.configsLoja.freteGratisAtivado||!this.simuladorStore.entregaBrasil)return!1;const cep=this.simuladorStore.cepAtual;if(!this.validarFaixasCep(cep,this.configsLoja.faixasCepGratis))return!1;let valorCondicao=this.precoTotal;return this.configsLoja.freteGratisCondicao==="qtd_itens"&&(valorCondicao=this.quantidade),!(valorCondicao<this.configsLoja.freteGratisValorMinimo||this.configsLoja.freteGratisSomentePrimeiraCompra&&!this.simuladorStore.elegivelFreteGratis)},exibirFreteFixo(){if(!this.configsLoja.freteFixoAtivado||!this.simuladorStore.entregaBrasil)return!1;const cep=this.simuladorStore.cepAtual;return this.validarFaixasCep(cep,this.configsLoja.faixasCepFreteFixo)?this.precoTotal>=this.configsLoja.freteFixoValorMinimo:!1},formasEntregaFiltradas(){const uf=this.simuladorStore.resultados.uf,cidade=this.simuladorStore.resultados.cidade,cep=String(this.simuladorStore.cepAtual||"").replace(/\D/g,""),formas=this.simuladorStore.resultados.formasEntregaManuais||[],formasAtivas=Array.isArray(this.configsLoja.formasEntregaAtivas)?this.configsLoja.formasEntregaAtivas:Object.values(this.configsLoja.formasEntregaAtivas||{}),ufNorm=this.normalizeClassName(uf),cidadeNorm=this.normalizeClassName(cidade),somenteDigitos=value=>String(value||"").replace(/\D/g,""),cepNaFaixa=(cepAtual,inicio,fim)=>{const ini=somenteDigitos(inicio),fimDig=somenteDigitos(fim);return!ini||!fimDig?!0:cepAtual?Number(cepAtual)>=Number(ini)&&Number(cepAtual)<=Number(fimDig):!1},matchLocalidade=lista=>{const arr=Array.isArray(lista)?lista:Object.values(lista||{});return arr.length?arr.some(item=>{if(!item||typeof item!="object"||this.normalizeClassName(item.estado||"")!==ufNorm)return!1;const cidadeItem=String(item.cidade||"").toLowerCase();return cidadeItem!=="todas"&&cidadeItem!=="todos"&&this.normalizeClassName(item.cidade||"")!==cidadeNorm?!1:cepNaFaixa(cep,item.cep_inicio,item.cep_fim)}):!0};return formas.filter(forma=>{if(this.configsLoja.multiplosCatalogos&&formasAtivas.length&&!formasAtivas.some(id=>String(id)===String(forma.id)))return!1;const disp=Array.isArray(forma.localidades_disponiveis)?forma.localidades_disponiveis:Object.values(forma.localidades_disponiveis||{}),indisp=Array.isArray(forma.localidades_indisponiveis)?forma.localidades_indisponiveis:Object.values(forma.localidades_indisponiveis||{});return disp.length||indisp.length?!(!uf||!cidade||disp.length&&!matchLocalidade(disp)||indisp.length&&matchLocalidade(indisp)):forma.localidades_disponiveis_classes?!uf||!cidade?!1:forma.localidades_disponiveis_classes.split(" ").some(cls=>cls===`localidade_disponivel_${ufNorm}`||cls===`localidade_disponivel_${ufNorm}_${cidadeNorm}`):!0})},modulosOrdenados(){return[...this.simuladorStore.resultados.cotacoesPorModulo||[]].sort((a,b)=>a.codigo==="fretefacil"?-1:b.codigo==="fretefacil"?1:0).map(modulo=>({...modulo,cotacoes:[...modulo.cotacoes||[]].sort((a,b)=>{const aTemTag=this.tagsCotacao(a).length>0,bTemTag=this.tagsCotacao(b).length>0;return aTemTag!==bTemTag?aTemTag?-1:1:Number(a.valor)-Number(b.valor)})}))},cotacoesAutomaticas(){return(this.simuladorStore.resultados.cotacoesPorModulo||[]).flatMap(modulo=>modulo.cotacoes||[]).filter(cotacao=>cotacao.disponivel!==!1)},menorPrecoAutomatico(){const cotacoesPagas=this.cotacoesAutomaticas.filter(cotacao=>Number(cotacao.valor)>0);return cotacoesPagas.length?Math.min(...cotacoesPagas.map(cotacao=>Number(cotacao.valor))):null},menorPrazoAutomatico(){const cotacoesComPrazo=this.cotacoesAutomaticas.filter(cotacao=>Number(cotacao.prazo)>0);return cotacoesComPrazo.length?Math.min(...cotacoesComPrazo.map(cotacao=>Number(cotacao.prazo))):null},localizacaoAtual(){const{cidade,uf}=this.simuladorStore.resultados;return cidade&&uf?`${cidade}/${uf}`:this.simuladorStore.paisAtual==="BR"?"Localização informada":this.simuladorStore.paisAtual},cepFormatado(){const cep=this.simuladorStore.cepAtual;return this.simuladorStore.paisAtual==="BR"&&cep.length===8?`${cep.substring(0,5)}-${cep.substring(5)}`:cep},chaveSelecaoLocal(){return`forma_entrega_pre_selecionada_${this.configsLoja.catalogoId}`},opcaoManualSelecionada(){return this.opcaoSelecionada&&this.opcaoSelecionada.tipo==="manual"?this.opcaoSelecionada.forma:null},selecaoValida(){if(!this.opcaoSelecionada||this.opcaoSelecionada.disponivel===!1)return!1;const forma=this.opcaoManualSelecionada;if(!forma)return!0;const tabelaSelecionada=this.tabelaSelecionada[forma.id];return!(forma.tipo_valor==="tabela"&&(tabelaSelecionada==null||tabelaSelecionada==="")||forma.campo_extra=="1"&&forma.campo_extra_obrigatorio=="1"&&!String(this.campoExtra[forma.id]||"").trim())},resumoSelecao(){return this.opcaoSelecionada?this.opcaoSelecionada.nome:"Nenhuma"}},methods:{async iniciarSimulacao(){const cep=this.simuladorStore.cepAtual,pais=this.simuladorStore.paisAtual,produtoId=this.simuladorStore.produtoId;this.simuladorStore.carregando=!0,this.cepEdicao=this.cepFormatado,this.exibirEdicaoCep=!1,this.resetarSelecao(),await this.validarCEP(cep),this.configsLoja.calculoFreteAutomaticoAtivado&&await this.calcularFreteAutomatico(cep,pais,produtoId,this.quantidade),this.simuladorStore.carregando=!1,this.notificarAtualizacaoFrete()},async simular({cep,pais,produtoId,quantidade,precoTotal}){this.quantidade=quantidade||0,this.precoTotal=precoTotal||0,cep=cep.replace(/\D/g,"");const entregaBrasil=pais==="BR"||pais===""||!pais;this.simuladorStore.quantidade=this.quantidade,this.simuladorStore.precoTotal=this.precoTotal,this.simuladorStore.cepAtual=cep,this.simuladorStore.paisAtual=pais||"BR",this.simuladorStore.entregaBrasil=entregaBrasil,this.simuladorStore.carregando=!0,this.salvarCEPLocalStorage(cep),localStorage.setItem("entrega_brasil",entregaBrasil),this.simuladorStore.elegivelFreteGratis=!1,this.configsLoja.freteGratisAtivado&&entregaBrasil&&this.validarFaixasCep(cep,this.configsLoja.faixasCepGratis)&&(this.simuladorStore.elegivelFreteGratis=!0),this.configsLoja.freteGratisSomentePrimeiraCompra&&(sessionStorage.getItem("finalizacao_pedido_cliente_whatsapp_e164")||(this.simuladorStore.elegivelFreteGratis=!1)),sessionStorage.setItem("frete_gratis_elegivel",this.simuladorStore.elegivelFreteGratis?"1":"0"),typeof atualizarProgressoFreteGratis=="function"&&atualizarProgressoFreteGratis(),await this.validarCEP(cep),this.configsLoja.calculoFreteAutomaticoAtivado&&await this.calcularFreteAutomatico(cep,pais,produtoId,quantidade),this.simuladorStore.dialogOpen=!0,this.simuladorStore.carregando=!1,this.notificarAtualizacaoFrete()},async validarCEP(cep){if(!/^[0-9]{8}$/.test(cep)){this.simuladorStore.resultados.uf=null,this.simuladorStore.resultados.cidade=null;return}try{const dados=await(await fetch(`${this.configsLoja.apiBaseUri}bureau_interno/cep/${cep}`)).json();dados.erro?(this.simuladorStore.resultados.uf=null,this.simuladorStore.resultados.cidade=null):(this.simuladorStore.resultados.uf=dados.uf,this.simuladorStore.resultados.cidade=dados.localidade)}catch(error){console.error("Erro ao validar CEP:",error),this.simuladorStore.resultados.uf=null,this.simuladorStore.resultados.cidade=null}},async calcularFreteAutomatico(cep,pais,produtoId,quantidade){try{if(typeof CarrinhoManager!="undefined"&&typeof CarrinhoManager.flush=="function")try{await CarrinhoManager.flush(this.configsLoja)}catch(e){console.error("Erro ao sincronizar carrinho antes de calcular frete:",e)}var cliente_whatsapp_e164=sessionStorage.getItem("finalizacao_pedido_cliente_whatsapp_e164")||"",cliente_cpf_cnpj="";typeof window.FacilZapDocumento!="undefined"&&$("#cliente_cpf_cnpj").length&&(cliente_cpf_cnpj=window.FacilZapDocumento.normalizarDocumento($("#cliente_cpf_cnpj").val()));const dados={acao:produtoId?"calculo_frete_produto":"calculo_frete",formato:"json",cep,pais:pais||"BR",cliente_cpf_cnpj,cliente_whatsapp_e164};if(produtoId&&(dados.produto_id=produtoId,dados.qtd=quantidade||0,dados.qtd==0))return showNotification("Ops!","Informe a quantidade desejada do produto.","warning"),!1;const data=await(await fetch(this.configsLoja.urlCatalogo,{method:"POST",headers:{"Content-Type":"application/x-www-form-urlencoded"},body:new URLSearchParams(dados)})).json();data.sucesso=="1"?(this.simuladorStore.resultados.cotacoesPorModulo=data.cotacoes_por_modulo||[],data.frete_gratis_elegivel===!0||data.frete_gratis_elegivel=="1"?this.simuladorStore.elegivelFreteGratis=!0:this.simuladorStore.elegivelFreteGratis=!1,sessionStorage.setItem("frete_gratis_elegivel",this.simuladorStore.elegivelFreteGratis?"1":"0")):this.limparEstadoErro(data.erro||"Não foi possível calcular o frete.")}catch(error){console.error("Erro ao calcular frete:",error),this.limparEstadoErro("Não foi possível calcular o frete.")}},async recalcularCep(){const cep=this.simuladorStore.paisAtual==="BR"?this.cepEdicao.replace(/\D/g,""):this.cepEdicao.trim();if(this.simuladorStore.paisAtual==="BR"&&cep.length!==8){typeof showNotification=="function"&&showNotification("Atenção","Por favor, informe um CEP válido.","warning");return}if(!cep){typeof showNotification=="function"&&showNotification("Atenção","Por favor, informe o código postal.","warning");return}this.simuladorStore.carregando=!0,this.resetarSelecao(),this.simuladorStore.cepAtual=cep,this.salvarCEPLocalStorage(cep);const entregaBrasil=this.simuladorStore.paisAtual==="BR"||!this.simuladorStore.paisAtual;this.simuladorStore.entregaBrasil=entregaBrasil,localStorage.setItem("entrega_brasil",entregaBrasil),await this.validarCEP(cep),this.configsLoja.calculoFreteAutomaticoAtivado&&await this.calcularFreteAutomatico(cep,this.simuladorStore.paisAtual,this.simuladorStore.produtoId,this.quantidade),this.cepEdicao=this.cepFormatado,this.exibirEdicaoCep=!1,this.simuladorStore.carregando=!1,this.notificarAtualizacaoFrete()},resetarSelecao(){this.opcaoSelecionada=null,this.tabelaSelecionada={},this.campoExtra={}},limparEstadoErro(mensagem){this.simuladorStore.resultados.cotacoesPorModulo=[],this.simuladorStore.elegivelFreteGratis=!1,sessionStorage.setItem("frete_gratis_elegivel","0");const chaveSelecao=this.chaveSelecaoLocal;chaveSelecao&&localStorage.removeItem(chaveSelecao),mensagem&&typeof showNotification=="function"&&showNotification("Atenção",mensagem,"warning"),this.notificarAtualizacaoFrete()},logoGateway(codigo){return logosGatewaysEntrega[codigo]||""},temDescricao(descricao){return!!String(descricao||"").trim()},temPrazoCotacao(cotacao){return Number(cotacao.prazo)>0},selecionarOpcao(opcao){opcao.disponivel!==!1&&(this.opcaoSelecionada=opcao)},opcaoEstaSelecionada(codigo){return this.opcaoSelecionada&&String(this.opcaoSelecionada.codigo)===String(codigo)},tagsCotacao(cotacao){const tags=[];return cotacao.disponivel===!1?["Em breve"]:(Number(cotacao.valor)===0&&tags.push("Frete grátis"),Number(cotacao.valor)>0&&Number(cotacao.valor)===this.menorPrecoAutomatico&&tags.push("Mais barato"),Number(cotacao.prazo)>0&&Number(cotacao.prazo)===this.menorPrazoAutomatico&&tags.push("Mais rápido"),tags)},prazoTexto(prazo){return prazo?`Em até ${prazo} ${Number(prazo)===1?"dia útil":"dias úteis"}`:"Prazo a confirmar"},precoTexto(valor,pendente=!1){return pendente?"A combinar":Number(valor)===0?"Grátis":`R$ ${this.formatarPreco(valor)}`},valorManual(forma){var _a;return forma.tipo_valor==="fixo"?Number(forma.frete_fixo||0):forma.tipo_valor==="tabela"&&this.tabelaSelecionada[forma.id]?Number(((_a=forma.tabela_valores[this.tabelaSelecionada[forma.id]])==null?void 0:_a.valor)||0):null},confirmarSelecao(){if(!this.selecaoValida)return;const forma=this.opcaoManualSelecionada,valor=forma?this.valorManual(forma):this.opcaoSelecionada.valor,valorNumerico=Number(valor),selecao={codigo:this.opcaoSelecionada.codigo,nome:this.opcaoSelecionada.nome,cep:this.simuladorStore.cepAtual,pais:this.simuladorStore.paisAtual,valor:valor!==null&&valor!==""&&Number.isFinite(valorNumerico)?valorNumerico:null,tabela_valor:(forma==null?void 0:forma.tipo_valor)==="tabela"?this.tabelaSelecionada[forma.id]:null,campo_extra:(forma==null?void 0:forma.campo_extra)=="1"?String(this.campoExtra[forma.id]||"").trim():null};localStorage.setItem(this.chaveSelecaoLocal,JSON.stringify(selecao)),this.notificarAtualizacaoFrete(selecao),this.fecharDialog()},notificarAtualizacaoFrete(selecao=null){window.dispatchEvent(new CustomEvent("fz-frete-atualizado",{detail:{cep:this.simuladorStore.cepAtual,pais:this.simuladorStore.paisAtual,elegivelFreteGratis:this.simuladorStore.elegivelFreteGratis,selecao}}))},fecharDialog(){this.simuladorStore.dialogOpen=!1}},template:`
    <p-dialog
        v-model:visible="visible"
        modal
        :style="{ width: '90vw', maxWidth: '760px' }"
        :breakpoints="{ '575px': '100vw' }"
        class="fz-simulador-frete-dialog"
        data-fz-simulador-frete-dialog
        :base-z-index="10100"
        :pt="{ content: { class: 'p-0' } }"
    >
        <template #header>
            <div class="fz-simulador-frete-dialog__cabecalho">
                <h2>Escolha sua forma de entrega</h2>
                <p>As opções abaixo foram calculadas para o CEP informado.</p>
            </div>
        </template>

        <div class="fz-simulador-frete-dialog__conteudo">
            <section class="fz-simulador-frete-dialog__card">
                <div class="fz-simulador-frete-dialog__localizacao">
                    <div>
                        <span>Entrega para</span>
                        <strong>{{ localizacaoAtual }}</strong>
                        <small>CEP {{ cepFormatado }}</small>
                    </div>
                    <button type="button" @click="exibirEdicaoCep = !exibirEdicaoCep">Alterar CEP</button>
                </div>

                <div v-if="exibirEdicaoCep" class="fz-simulador-frete-dialog__alterar-cep">
                    <strong>Alterar CEP</strong>
                    <small>Digite um novo CEP para recalcular as opções.</small>
                    <div class="fz-simulador-frete-dialog__alterar-cep-campos">
                        <p-inputmask
                            v-if="simuladorStore.paisAtual === 'BR'"
                            v-model="cepEdicao"
                            mask="99999-999"
                            placeholder="00000-000"
                            inputmode="numeric"
                            @keydown.enter="recalcularCep"
                        ></p-inputmask>
                        <p-inputtext
                            v-else
                            v-model="cepEdicao"
                            placeholder="Código Postal"
                            @keydown.enter="recalcularCep"
                        ></p-inputtext>
                        <p-button label="Recalcular" @click="recalcularCep"></p-button>
                    </div>
                </div>

                <div v-if="simuladorStore.carregando" class="fz-simulador-frete-dialog__carregando" aria-live="polite">
                    <div v-for="indice in 3" :key="indice" class="fz-simulador-frete-dialog__skeleton"></div>
                </div>

                <template v-else>
                    <div v-if="exibirFreteGratis || exibirFreteFixo" class="fz-simulador-frete-dialog__destaques">
                        <div
                            v-if="exibirFreteGratis"
                            class="fz-simulador-frete-dialog__opcao fz-simulador-frete-dialog__opcao--destaque"
                            :class="{ 'is-selected': opcaoEstaSelecionada('gratis'), 'fz-simulador-frete-dialog__opcao--sem-descricao': !temDescricao(configsLoja.freteGratisDescricao) }"
                            @click="selecionarOpcao({ tipo: 'especial', codigo: 'gratis', nome: 'Frete Grátis', valor: 0 })"
                        >
                            <div class="fz-simulador-frete-dialog__controle" @click.stop>
                                <p-radiobutton
                                    :modelValue="opcaoSelecionada ? opcaoSelecionada.codigo : null"
                                    inputId="simulador-forma-entrega-gratis"
                                    name="simulador-forma-entrega"
                                    value="gratis"
                                    aria-label="Selecionar Frete Grátis"
                                    @update:modelValue="selecionarOpcao({ tipo: 'especial', codigo: 'gratis', nome: 'Frete Grátis', valor: 0 })"
                                ></p-radiobutton>
                            </div>
                            <div class="fz-simulador-frete-dialog__icone"><i class="ti-gift"></i></div>
                            <div class="fz-simulador-frete-dialog__opcao-info">
                                <strong>Frete Grátis</strong>
                                <small v-if="temDescricao(configsLoja.freteGratisDescricao)">{{ configsLoja.freteGratisDescricao }}</small>
                                <span class="fz-simulador-frete-dialog__tag">Frete grátis</span>
                            </div>
                            <div class="fz-simulador-frete-dialog__preco is-gratis">Grátis</div>
                        </div>

                        <div
                            v-if="exibirFreteFixo"
                            class="fz-simulador-frete-dialog__opcao fz-simulador-frete-dialog__opcao--destaque"
                            :class="{ 'is-selected': opcaoEstaSelecionada('fixo'), 'fz-simulador-frete-dialog__opcao--sem-descricao': !temDescricao(configsLoja.freteFixoDescricao) }"
                            @click="selecionarOpcao({ tipo: 'especial', codigo: 'fixo', nome: 'Frete Fixo', valor: configsLoja.freteFixoValor })"
                        >
                            <div class="fz-simulador-frete-dialog__controle" @click.stop>
                                <p-radiobutton
                                    :modelValue="opcaoSelecionada ? opcaoSelecionada.codigo : null"
                                    inputId="simulador-forma-entrega-fixo"
                                    name="simulador-forma-entrega"
                                    value="fixo"
                                    aria-label="Selecionar Frete Fixo"
                                    @update:modelValue="selecionarOpcao({ tipo: 'especial', codigo: 'fixo', nome: 'Frete Fixo', valor: configsLoja.freteFixoValor })"
                                ></p-radiobutton>
                            </div>
                            <div class="fz-simulador-frete-dialog__icone"><i class="ti-truck"></i></div>
                            <div class="fz-simulador-frete-dialog__opcao-info">
                                <strong>Frete Fixo</strong>
                                <small v-if="temDescricao(configsLoja.freteFixoDescricao)">{{ configsLoja.freteFixoDescricao }}</small>
                            </div>
                            <div class="fz-simulador-frete-dialog__preco">{{ precoTexto(configsLoja.freteFixoValor) }}</div>
                        </div>
                    </div>

                    <div v-for="modulo in modulosOrdenados" :key="modulo.codigo" class="fz-simulador-frete-dialog__grupo">
                        <h3>{{ modulo.nome }}</h3>
                        <div class="fz-simulador-frete-dialog__lista">
                            <div
                                v-for="cotacao in modulo.cotacoes"
                                :key="cotacao.codigo"
                                class="fz-simulador-frete-dialog__opcao"
                                :class="{ 'is-selected': opcaoEstaSelecionada(cotacao.codigo), 'is-disabled': cotacao.disponivel === false, 'fz-simulador-frete-dialog__opcao--sem-descricao': !temPrazoCotacao(cotacao) }"
                                :aria-disabled="cotacao.disponivel === false"
                                @click="selecionarOpcao({ ...cotacao, tipo: 'automatica' })"
                            >
                                <div class="fz-simulador-frete-dialog__controle" @click.stop>
                                    <p-radiobutton
                                        :modelValue="opcaoSelecionada ? opcaoSelecionada.codigo : null"
                                        :inputId="'simulador-forma-entrega-' + cotacao.codigo"
                                        name="simulador-forma-entrega"
                                        :value="cotacao.codigo"
                                        :disabled="cotacao.disponivel === false"
                                        :aria-label="'Selecionar ' + cotacao.nome"
                                        @update:modelValue="selecionarOpcao({ ...cotacao, tipo: 'automatica' })"
                                    ></p-radiobutton>
                                </div>
                                <div class="fz-simulador-frete-dialog__icone">
                                    <img v-if="logoGateway(modulo.codigo)" :src="logoGateway(modulo.codigo)" :alt="modulo.nome">
                                    <i v-else class="ti-truck"></i>
                                </div>
                                <div class="fz-simulador-frete-dialog__opcao-info">
                                    <strong>{{ cotacao.nome }}</strong>
                                    <small v-if="temPrazoCotacao(cotacao)">{{ prazoTexto(cotacao.prazo) }}</small>
                                    <span v-if="tagsCotacao(cotacao).length" class="fz-simulador-frete-dialog__tags">
                                        <span v-for="tag in tagsCotacao(cotacao)" :key="tag" class="fz-simulador-frete-dialog__tag">{{ tag }}</span>
                                    </span>
                                </div>
                                <div class="fz-simulador-frete-dialog__preco" :class="{ 'is-gratis': Number(cotacao.valor) === 0 }">{{ precoTexto(cotacao.valor) }}</div>
                            </div>
                        </div>
                    </div>

                    <div v-if="formasEntregaFiltradas.length" class="fz-simulador-frete-dialog__grupo">
                        <h3>Outras formas de receber</h3>
                        <div class="fz-simulador-frete-dialog__lista">
                            <div
                                v-for="forma in formasEntregaFiltradas"
                                :key="forma.id"
                                class="fz-simulador-frete-dialog__opcao"
                                :class="{ 'is-selected': opcaoEstaSelecionada(forma.id), 'fz-simulador-frete-dialog__opcao--sem-descricao': !temDescricao(forma.descricao) }"
                                @click="selecionarOpcao({ tipo: 'manual', codigo: forma.id, nome: forma.nome, forma: forma })"
                            >
                                <div class="fz-simulador-frete-dialog__controle" @click.stop>
                                    <p-radiobutton
                                        :modelValue="opcaoSelecionada ? opcaoSelecionada.codigo : null"
                                        :inputId="'simulador-forma-entrega-manual-' + forma.id"
                                        name="simulador-forma-entrega"
                                        :value="forma.id"
                                        :aria-label="'Selecionar ' + forma.nome"
                                        @update:modelValue="selecionarOpcao({ tipo: 'manual', codigo: forma.id, nome: forma.nome, forma: forma })"
                                    ></p-radiobutton>
                                </div>
                                <div class="fz-simulador-frete-dialog__icone"><i class="ti-home"></i></div>
                                <div class="fz-simulador-frete-dialog__opcao-info">
                                    <strong>{{ forma.nome }}</strong>
                                    <small v-if="temDescricao(forma.descricao)">{{ forma.descricao }}</small>
                                    <span v-if="valorManual(forma) === 0" class="fz-simulador-frete-dialog__tag">Frete grátis</span>
                                </div>
                                <div class="fz-simulador-frete-dialog__preco" :class="{ 'is-gratis': valorManual(forma) === 0, 'is-pendente': valorManual(forma) === null }">{{ precoTexto(valorManual(forma), valorManual(forma) === null) }}</div>

                                <div v-if="opcaoEstaSelecionada(forma.id) && forma.tipo_valor === 'tabela'" class="fz-simulador-frete-dialog__detalhe" @click.stop>
                                    <span>Selecione a opção de entrega</span>
                                    <select :id="'tabela-entrega-' + forma.id" v-model="tabelaSelecionada[forma.id]">
                                        <option value="">Selecione</option>
                                        <option v-for="(opcao, codigo) in forma.tabela_valores" :key="codigo" :value="codigo">{{ opcao.nome }} - R$ {{ formatarPreco(opcao.valor) }}</option>
                                    </select>
                                </div>

                                <div v-if="opcaoEstaSelecionada(forma.id) && forma.campo_extra == '1'" class="fz-simulador-frete-dialog__detalhe" @click.stop>
                                    <span>{{ forma.nome_campo_extra || 'Informações adicionais para a entrega' }}</span>
                                    <p-inputtext :id="'campo-extra-entrega-' + forma.id" v-model="campoExtra[forma.id]"></p-inputtext>
                                </div>
                            </div>
                        </div>
                    </div>
                </template>
            </section>
        </div>

        <template #footer>
            <div class="fz-simulador-frete-dialog__rodape">
                <div class="fz-simulador-frete-dialog__rodape-selecao text-left">
                    <span>Entrega selecionada</span>
                    <strong>{{ resumoSelecao }}</strong>
                </div>
                <p-button label="Usar esta entrega" severity="primary" :disabled="!selecaoValida" @click="confirmarSelecao"></p-button>
            </div>
        </template>
    </p-dialog>
    `},window.abrirSimuladorFrete=function(cep,pais,produtoId,quantidade,precoTotal){var _a;if(typeof SimuladorFreteStore!="undefined"){const cepLimpo=cep.replace(/\D/g,""),simulandoProduto=produtoId!=null&&produtoId!=="",entregaBrasil=pais==="BR"||pais===""||!pais;if(SimuladorFreteStore.cepAtual=cepLimpo,SimuladorFreteStore.paisAtual=pais||"BR",SimuladorFreteStore.entregaBrasil=entregaBrasil,SimuladorFreteStore.produtoId=produtoId,SimuladorFreteStore.quantidade=0,SimuladorFreteStore.precoTotal=0,SimuladorFreteStore.resultados.cotacoesPorModulo=[],typeof configsLoja!="undefined"&&configsLoja.formasEntrega&&(SimuladorFreteStore.resultados.formasEntregaManuais=Array.isArray(configsLoja.formasEntrega)?configsLoja.formasEntrega:Object.values(configsLoja.formasEntrega)),simulandoProduto){const quantidades=typeof ProdutoConteudoStore!="undefined"?ProdutoConteudoStore.quantidadesSelecionadas[produtoId]||{}:{};let totalQtd=0;Object.values(quantidades).forEach(qtd=>{totalQtd+=Number(qtd)||0});const precoProduto=typeof ProdutoConteudoStore!="undefined"&&((_a=ProdutoConteudoStore.dadosCompletos)==null?void 0:_a.preco)||0,precoTotalSimulacao=Number(precoTotal)||precoProduto*totalQtd;SimuladorFreteStore.quantidade=totalQtd,SimuladorFreteStore.precoTotal=precoTotalSimulacao}else SimuladorFreteStore.quantidade=Number(quantidade)||0,SimuladorFreteStore.precoTotal=Number(precoTotal)||(typeof obterSubtotalCarrinho=="function"?obterSubtotalCarrinho():0);localStorage.setItem("cliente_cep",cepLimpo),localStorage.setItem("entrega_brasil",entregaBrasil),SimuladorFreteStore.elegivelFreteGratis=!1,sessionStorage.setItem("frete_gratis_elegivel","0"),typeof atualizarProgressoFreteGratis=="function"&&atualizarProgressoFreteGratis(),SimuladorFreteStore.dialogOpen=!0}};
